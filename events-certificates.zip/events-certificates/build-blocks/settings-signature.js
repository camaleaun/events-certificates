"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // package-external:@wordpress/api-fetch
  var require_api_fetch = __commonJS({
    "package-external:@wordpress/api-fetch"(exports, module) {
      module.exports = window.wp.apiFetch;
    }
  });

  // package-external:@wordpress/components
  var require_components = __commonJS({
    "package-external:@wordpress/components"(exports, module) {
      module.exports = window.wp.components;
    }
  });

  // package-external:@wordpress/element
  var require_element = __commonJS({
    "package-external:@wordpress/element"(exports, module) {
      module.exports = window.wp.element;
    }
  });

  // package-external:@wordpress/i18n
  var require_i18n = __commonJS({
    "package-external:@wordpress/i18n"(exports, module) {
      module.exports = window.wp.i18n;
    }
  });

  // package-external:@wordpress/primitives
  var require_primitives = __commonJS({
    "package-external:@wordpress/primitives"(exports, module) {
      module.exports = window.wp.primitives;
    }
  });

  // vendor-external:react/jsx-runtime
  var require_jsx_runtime = __commonJS({
    "vendor-external:react/jsx-runtime"(exports, module) {
      module.exports = window.ReactJSXRuntime;
    }
  });

  // src/settings-signature/index.tsx
  var import_api_fetch2 = __toESM(require_api_fetch());
  var import_components12 = __toESM(require_components());
  var import_element9 = __toESM(require_element());
  var import_i18n17 = __toESM(require_i18n());

  // src/editor/SvgSource.tsx
  var import_components10 = __toESM(require_components());
  var import_element7 = __toESM(require_element());
  var import_i18n14 = __toESM(require_i18n());

  // src/media-chooser/svg-code.ts
  var import_i18n2 = __toESM(require_i18n());

  // vendor/camaleaun/draw/packages/js/src/geometry.ts
  var SVG_LIMITS = { bytes: 524288, paths: 50, pathData: 2e4, viewBox: 5e3 };
  function svgCodeAllowed(code) {
    return code.length <= SVG_LIMITS.bytes && !/<!(DOCTYPE|ENTITY)|<\?xml-stylesheet|<\s*script|\son[a-z]+\s*=/i.test(code);
  }
  function isPathData(d) {
    return /^[MmLlHhVvCcSsQqTtAaZz0-9eE.,\s+-]*$/.test(d) && /^\s*[Mm]/.test(d);
  }
  function isFill(value) {
    return /^(none|currentcolor|#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\)|\$[a-z0-9_-]+)$/i.test(value.trim());
  }
  function sanitizeSvg(code) {
    const text2 = code.trim();
    if (!svgCodeAllowed(text2)) {
      return null;
    }
    const doc = new DOMParser().parseFromString(/^<svg[\s>]/i.test(text2) ? text2 : `<svg xmlns="http://www.w3.org/2000/svg">${text2}</svg>`, "image/svg+xml");
    const root2 = doc.documentElement;
    if (!root2 || root2.nodeName.toLowerCase() !== "svg" || doc.querySelector("parsererror")) {
      return null;
    }
    const inherited = (node, name) => {
      for (let n = node; n; n = n.parentElement) {
        if (n.getAttribute(name)) {
          return n.getAttribute(name);
        }
      }
      return null;
    };
    const paths = [];
    for (const node of Array.from(root2.getElementsByTagName("path"))) {
      if (paths.length >= SVG_LIMITS.paths) {
        break;
      }
      const d = (node.getAttribute("d") || "").trim().replace(/\s+/g, " ");
      if (!d || d.length > SVG_LIMITS.pathData || !isPathData(d)) {
        continue;
      }
      const fill = inherited(node, "fill");
      const rule = inherited(node, "fill-rule");
      paths.push({ d, ...fill && isFill(fill) && fill.toLowerCase() !== "currentcolor" ? { fill } : {}, ...rule === "evenodd" ? { rule: "evenodd" } : {} });
    }
    if (!paths.length) {
      return null;
    }
    const box2 = (root2.getAttribute("viewBox") || "").split(/[\s,]+/).map(Number);
    const vw = box2.length === 4 && box2[2] > 0 ? box2[2] : Number(root2.getAttribute("width")) || 100;
    const vh = box2.length === 4 && box2[3] > 0 ? box2[3] : Number(root2.getAttribute("height")) || 100;
    if (!(vw > 0 && vh > 0 && vw <= SVG_LIMITS.viewBox && vh <= SVG_LIMITS.viewBox)) {
      return null;
    }
    const size = (name) => {
      const given = /^\s*([\d.]+)(px)?\s*$/.exec(root2.getAttribute(name) || "");
      return given ? Number(given[1]) : 0;
    };
    const w = size("width");
    const h = size("height");
    const shown2 = w > 0 && h > 0 && w <= SVG_LIMITS.viewBox && h <= SVG_LIMITS.viewBox && (w !== vw || h !== vh);
    return { vw, vh, ...shown2 ? { w, h } : {}, paths };
  }

  // src/editor/svg-draft.ts
  var INFO_ICON = "M5.5 12a6.5 6.5 0 1 1 13 0 6.5 6.5 0 0 1-13 0ZM12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm.75 4v1.5h-1.5V8h1.5Zm0 8v-5h-1.5v5h1.5Z";
  var INFO_VIEWBOX = 24;
  var INFO_SIZE = 96;
  var infoSvg = () => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${INFO_VIEWBOX} ${INFO_VIEWBOX}">
  <path d="${INFO_ICON}"/>
</svg>`;
  var defaultDrawing = () => ({ title: "", vw: INFO_VIEWBOX, vh: INFO_VIEWBOX, w: INFO_SIZE, h: INFO_SIZE, paths: [{ d: INFO_ICON }] });
  var emptiedElement = () => ({ vw: INFO_VIEWBOX, vh: INFO_VIEWBOX, paths: [{ d: INFO_ICON }], markup: void 0, fill: void 0 });
  function refilled(draft, element) {
    if (element) {
      const { vw, vh, paths } = emptiedElement();
      return { ...draft, vw, vh, paths };
    }
    return { ...defaultDrawing(), title: draft.title };
  }
  var taken = (pasted, base, element) => element ? { ...pasted, title: base.title, w: base.w, h: base.h } : pasted;
  function inkOn(color2) {
    const c = String(color2 || "").trim().toLowerCase();
    let rgb = null;
    const hex = /^#([0-9a-f]{3,8})$/.exec(c);
    if (hex) {
      const h = hex[1];
      if (h.length === 3 || h.length === 4) {
        rgb = [0, 1, 2].map((i) => parseInt(h[i] + h[i], 16));
      } else if (h.length === 6 || h.length === 8) {
        rgb = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
      }
    }
    const fn = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/.exec(c);
    if (!rgb && fn) {
      rgb = [Number(fn[1]), Number(fn[2]), Number(fn[3])];
    }
    if (!rgb || rgb.some((n) => Number.isNaN(n))) {
      return "#fff";
    }
    const [r, g, b] = rgb.map((n) => {
      const s = n / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.4 ? "#1e1e1e" : "#fff";
  }

  // src/editor/model.ts
  var import_i18n = __toESM(require_i18n());
  function colorOf(v, mode) {
    return mode === "dark" && v.dark ? v.dark : v.light;
  }
  function builtinColor(key, mode) {
    const dark = mode === "dark";
    switch (key) {
      case "text":
      case "muted":
      case "line":
        return dark ? "#ffffff" : "#000000";
      case "background":
        return "transparent";
      case "primary":
        return "#3858e9";
    }
    return "";
  }
  function colorGroups(design) {
    const keys = Object.keys(design.colors).filter((k) => design.colors[k].light && design.colors[k].light !== "none");
    return keys.length ? [{ name: "elements", keys }] : [];
  }
  function color(design, value, mode, depth = 0) {
    if (!value) {
      return "none";
    }
    if (value.startsWith("$")) {
      const key = value.slice(1);
      const v = design.colors[key];
      if (v) {
        const own = colorOf(v, mode);
        if (own.startsWith("$")) {
          return depth < 5 ? color(design, own, mode, depth + 1) : "none";
        }
        return own || "none";
      }
      const swatch = (design.palette || []).find((s) => s.slug === key);
      return swatch ? swatch.color : builtinColor(key, mode) || "none";
    }
    return value;
  }
  function colorIn(design, v, mode) {
    return color(design, colorOf(v, mode), mode);
  }
  var REQUIRED_SLOTS = [];

  // src/media-chooser/svg-code.ts
  var bareSvg = (text2) => text2.replace(/<\?xml[^>]*\?>/gi, "").replace(/<!--[\s\S]*?-->/g, "").trim();
  var SVG_EXAMPLE = infoSvg();
  function problemText(problem) {
    switch (problem) {
      case "not-svg":
        return (0, import_i18n2.__)("That is not SVG code: it should start with <svg>.", "events-certificates");
      case "forbidden":
        return (0, import_i18n2.__)("That SVG has parts that are not allowed (a script, an event handler, a DOCTYPE or an entity).", "events-certificates");
      case "too-big":
        return (0, import_i18n2.__)("That SVG is too big.", "events-certificates");
      case "no-paths":
        return (0, import_i18n2.__)("That SVG has no paths: only its <path> elements are read, so shapes and text must be converted to paths first.", "events-certificates");
      default:
        return "";
    }
  }
  function parseSvgText(text2, title = "") {
    const code = bareSvg(text2);
    if (!code) {
      return { problem: "empty" };
    }
    if (!/^<svg[\s>]/i.test(code)) {
      return { problem: "not-svg" };
    }
    if (code.length > SVG_LIMITS.bytes) {
      return { problem: "too-big" };
    }
    if (!svgCodeAllowed(code)) {
      return { problem: "forbidden" };
    }
    const svg = sanitizeSvg(code);
    return svg ? { draft: { title, ...svg } } : { problem: "no-paths" };
  }
  function offerFor(clip, handled) {
    const code = clip ? bareSvg(clip) : "";
    return code && code !== handled && "draft" in parseSvgText(code) ? code : null;
  }

  // src/editor/SvgFields.tsx
  var import_element6 = __toESM(require_element());
  var import_i18n13 = __toESM(require_i18n());

  // src/editor/SizeRow.tsx
  var import_components9 = __toESM(require_components());
  var import_i18n12 = __toESM(require_i18n());

  // src/editor/DesignPanel.tsx
  var import_components8 = __toESM(require_components());
  var import_i18n11 = __toESM(require_i18n());

  // node_modules/@wordpress/icons/build-module/library/chevron-down.mjs
  var import_primitives = __toESM(require_primitives(), 1);
  var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
  var chevron_down_default = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.Path, { d: "M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z" }) });

  // node_modules/@wordpress/icons/build-module/library/chevron-up.mjs
  var import_primitives2 = __toESM(require_primitives(), 1);
  var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
  var chevron_up_default = /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.Path, { d: "M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z" }) });

  // node_modules/@wordpress/icons/build-module/library/copy.mjs
  var import_primitives3 = __toESM(require_primitives(), 1);
  var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
  var copy_default = /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M5 4.5h11a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V5a.5.5 0 0 1 .5-.5ZM3 5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5Zm17 3v10.75c0 .69-.56 1.25-1.25 1.25H6v1.5h12.75a2.75 2.75 0 0 0 2.75-2.75V8H20Z" }) });

  // node_modules/@wordpress/icons/build-module/library/more-vertical.mjs
  var import_primitives4 = __toESM(require_primitives(), 1);
  var import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
  var more_vertical_default = /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.Path, { d: "M13 19h-2v-2h2v2zm0-6h-2v-2h2v2zm0-6h-2V5h2v2z" }) });

  // node_modules/@wordpress/icons/build-module/library/plus.mjs
  var import_primitives5 = __toESM(require_primitives(), 1);
  var import_jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
  var plus_default = /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.Path, { d: "M11 12.5V17.5H12.5V12.5H17.5V11H12.5V6H11V11H6V12.5H11Z" }) });

  // node_modules/@wordpress/icons/build-module/library/trash.mjs
  var import_primitives6 = __toESM(require_primitives(), 1);
  var import_jsx_runtime6 = __toESM(require_jsx_runtime(), 1);
  var trash_default = /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_primitives6.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_primitives6.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M12 5.5A2.25 2.25 0 0 0 9.878 7h4.244A2.251 2.251 0 0 0 12 5.5ZM12 4a3.751 3.751 0 0 0-3.675 3H5v1.5h1.27l.818 8.997a2.75 2.75 0 0 0 2.739 2.501h4.347a2.75 2.75 0 0 0 2.738-2.5L17.73 8.5H19V7h-3.325A3.751 3.751 0 0 0 12 4Zm4.224 4.5H7.776l.806 8.861a1.25 1.25 0 0 0 1.245 1.137h4.347a1.25 1.25 0 0 0 1.245-1.137l.805-8.861Z" }) });

  // src/editor/ColorsSection.tsx
  var import_components = __toESM(require_components());
  var import_element = __toESM(require_element());
  var import_i18n4 = __toESM(require_i18n());

  // src/editor/base.ts
  var import_i18n3 = __toESM(require_i18n());
  var KEPT_SLOTS = Array.from(new Set(REQUIRED_SLOTS));

  // src/editor/ColorsSection.tsx
  var import_jsx_runtime7 = __toESM(require_jsx_runtime());

  // src/editor/Inspector.tsx
  var import_components7 = __toESM(require_components());
  var import_element5 = __toESM(require_element());
  var import_i18n10 = __toESM(require_i18n());

  // src/editor/icons.tsx
  var import_components2 = __toESM(require_components());
  var import_jsx_runtime8 = __toESM(require_jsx_runtime());
  var stroke = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" };
  var solid = { fill: "currentColor" };
  var icon = (...children) => /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", children });
  var text = icon(/* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M5.5 6.75h13M12 6.75v10.5M9.5 17.25h5", ...stroke }, "a"));
  var line = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M6.5 17.5l11-11", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Circle, { cx: "5.5", cy: "18.5", r: "1.75", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Circle, { cx: "18.5", cy: "5.5", r: "1.75", ...solid }, "c")
  );
  var rect = icon(/* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "4.75", y: "6.75", width: "14.5", height: "10.5", rx: "1.5", ...stroke }, "a"));
  var ellipse = icon(/* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M4.75 12a7.25 5.25 0 1 0 14.5 0 7.25 5.25 0 1 0-14.5 0z", ...stroke }, "a"));
  var shape = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M6 16.5c0-6.5 5.5-9 12-9", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "3.75", y: "15", width: "3", height: "3", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "17.25", y: "6", width: "3", height: "3", ...solid }, "c")
  );
  var picture = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "4.75", y: "5.75", width: "14.5", height: "12.5", rx: "1.5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M5.5 16.5l3.75-4.25 2.75 2.75 2-2 4.5 4", ...stroke }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Circle, { cx: "15.25", cy: "9.75", r: "1.25", ...solid }, "c")
  );
  var drawing = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M7.5 7L2.75 12l4.75 5M16.5 7l4.75 5-4.75 5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M12 8.25l3 3.75-3 3.75L9 12z", ...solid }, "b")
  );
  var signature = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M4 19.25h16", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M4.5 15c1.6-3.4 2.9-8.5 4.2-8.5.9 0 .3 3.7-.2 6.2-.3 1.5.4 1.6 1.2.4 1-1.5 1.8-3.4 2.9-3.4.8 0 .1 2.3.9 2.3 1.2 0 1.8-1.9 3.3-1.9 1 0 .6 1.5 1.5 1.5.9 0 1.5-1 2.2-1.6", ...stroke }, "b")
  );
  var qr = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "4.75", y: "4.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "13.75", y: "4.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "4.75", y: "13.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "c"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M7 7h1.25v1.25H7zM16 7h1.25v1.25H16zM7 16h1.25v1.25H7zM13.75 13.75H16v2.25h-2.25zM17.5 13.75h1.75V15.5H17.5zM13.75 17.5h1.75v1.75h-1.75zM17.25 17.25h2v2h-2z", ...solid }, "d")
  );
  var verification = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Rect, { x: "4.75", y: "6.75", width: "6.5", height: "6.5", rx: ".75", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M7.25 9.25h1.5v1.5h-1.5z", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M14 8h5.25M14 12h5.25M4.75 17h14.5", ...stroke }, "c")
  );
  var logo = icon(
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Circle, { cx: "12", cy: "9.5", r: "5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_components2.Path, { d: "M9 13.75l-1.75 5.5 4.75-2 4.75 2-1.75-5.5", ...stroke }, "b")
  );

  // src/editor/media.ts
  var import_api_fetch = __toESM(require_api_fetch());
  var import_i18n5 = __toESM(require_i18n());

  // src/editor/SvgPanel.tsx
  var import_components4 = __toESM(require_components());
  var import_element2 = __toESM(require_element());
  var import_i18n7 = __toESM(require_i18n());

  // src/editor/SvgGroups.tsx
  var import_components3 = __toESM(require_components());
  var import_i18n6 = __toESM(require_i18n());
  var import_jsx_runtime9 = __toESM(require_jsx_runtime());
  function ViewBoxRow({ vw, vh, onChange }) {
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(DropdownRow, { label: (0, import_i18n6.__)("ViewBox", "events-certificates"), value: `${vw} \xD7 ${vh}`, children: () => /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(import_components3.__experimentalHStack, { alignment: "top", children: [
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_components3.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n6.__)("Width", "events-certificates"), min: 1, value: vw, onChange: (v) => Number(v) > 0 && onChange({ vw: Number(v) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_components3.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n6.__)("Height", "events-certificates"), min: 1, value: vh, onChange: (v) => Number(v) > 0 && onChange({ vh: Number(v) }) })
    ] }) });
  }
  function SvgGroups({ viewBox, size, paths }) {
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "evcert-svg-panel", children: [
      /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "evcert-inspector__section", children: [
        viewBox,
        size
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "evcert-inspector__section", children: paths })
    ] });
  }

  // src/editor/SvgPanel.tsx
  var import_jsx_runtime10 = __toESM(require_jsx_runtime());
  var TRANSPARENT = "#ffffff00";
  function FillSwatch({ value, current, design, mode, onChange }) {
    const variable = (value == null ? void 0 : value.startsWith("$")) ? design.colors[value.slice(1)] : null;
    const shown2 = value ? color(design, value, mode) : color(design, current, mode);
    const palette = Object.entries(design.colors).map(([slug, v]) => ({ slug, name: v.name, color: colorIn(design, v, mode) === "transparent" ? TRANSPARENT : colorIn(design, v, mode) }));
    return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
      import_components4.Dropdown,
      {
        popoverProps: { placement: "left-start", offset: 36, shift: true, className: "evcert-colors__popover-wrap" },
        renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          import_components4.Button,
          {
            className: "evcert-svg-path__swatch",
            onClick: onToggle,
            "aria-expanded": isOpen,
            label: (0, import_i18n7.sprintf)(
              /* translators: %s: color name. */
              (0, import_i18n7.__)("Fill: %s", "events-certificates"),
              value ? (variable == null ? void 0 : variable.name) || value : (0, import_i18n7.__)("Current color", "events-certificates")
            ),
            showTooltip: true,
            children: value ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.ColorIndicator, { colorValue: shown2 === "none" ? void 0 : shown2 }) : (
              // The current color is a circle in that color cut across by a stroke that shows on it: as the "no color" of the palette,
              // which is an empty circle with a slash (the style of .is-current has it).
              /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.ColorIndicator, { colorValue: "", className: "is-current", style: { "--evcert-fill": shown2 === "none" ? "#fff" : shown2, "--evcert-ink": shown2 === "none" ? "#949494" : inkOn(shown2) } })
            )
          }
        ),
        renderContent: () => /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "evcert-color-popover", children: [
          colorGroups(design).map((group) => {
            var _a;
            return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("p", { className: "evcert-color-popover__label", children: (0, import_i18n7.__)("Elements", "events-certificates") }),
              /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
                import_components4.ColorPalette,
                {
                  colors: group.keys.map((key) => palette.find((c) => c.slug === key)),
                  value: variable ? (_a = group.keys.map((key) => palette.find((c) => c.slug === key)).find((c) => `$${c == null ? void 0 : c.slug}` === value)) == null ? void 0 : _a.color : void 0,
                  disableCustomColors: true,
                  clearable: false,
                  onChange: (picked, index) => {
                    const key = index === void 0 ? void 0 : group.keys[index];
                    onChange(key ? `$${key}` : picked || void 0);
                  }
                }
              )
            ] }, group.name);
          }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("p", { className: "evcert-color-popover__label", children: (0, import_i18n7.__)("Custom", "events-certificates") }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.ColorPalette, { value: value && !variable ? value : void 0, clearable: false, onChange: (c) => onChange(c || void 0) }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "evcert-color-popover__footer", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.Button, { variant: "tertiary", size: "small", disabled: !value, accessibleWhenDisabled: true, onClick: () => onChange(void 0), children: (0, import_i18n7.__)("Clear", "events-certificates") }) })
        ] })
      }
    );
  }
  function PathData({ index, value, multiline, onChange, onImport, onFocus }) {
    const [text2, setText] = (0, import_element2.useState)(value);
    const valid = !text2 || isPathData(text2);
    const props = {
      __nextHasNoMarginBottom: true,
      className: `evcert-svg-path__d${valid ? "" : " is-invalid"}`,
      label: (0, import_i18n7.sprintf)(
        /* translators: %d: path number. */
        (0, import_i18n7.__)("Path %d data (d)", "events-certificates"),
        index + 1
      ),
      hideLabelFromVision: !multiline,
      placeholder: "M0 0h24v24H0z",
      value: text2,
      onFocus,
      onPaste: (event) => {
        const pasted = event.clipboardData.getData("text/plain");
        const svg = /^\s*</.test(pasted) ? sanitizeSvg(pasted) : null;
        if (svg) {
          event.preventDefault();
          onImport(svg);
        }
      },
      onChange: (d) => {
        setText(d);
        if (isPathData(d)) {
          onChange(d.trim());
        }
      }
    };
    return multiline ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.TextareaControl, { ...props, rows: 3, help: valid ? void 0 : (0, import_i18n7.__)("Only path commands and numbers, starting with M.", "events-certificates") }) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.TextControl, { __next40pxDefaultSize: true, ...props });
  }
  var short = (d) => d.length > 28 ? `${d.slice(0, 28).trim()}\u2026` : d;
  function PathList({ paths, current, design, mode, onPaths, onImport, onFocus, onEmpty, placement = "left-start" }) {
    const [version, setVersion] = (0, import_element2.useState)(0);
    const replace = (next) => {
      onPaths(next);
      setVersion(version + 1);
    };
    const setPath = (i, patch) => onPaths(paths.map((p, j) => j === i ? { ...p, ...patch } : p));
    const move = (i, to) => {
      const next = [...paths];
      const [p] = next.splice(i, 1);
      next.splice(to, 0, p);
      replace(next);
    };
    const remove = (i) => {
      const next = paths.filter((_, j) => j !== i);
      if (onEmpty && !next.some((p) => p.d)) {
        onEmpty();
        setVersion(version + 1);
        return;
      }
      replace(next);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_components4.__experimentalHStack, { className: "evcert-svg-panel__header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("h2", { className: "evcert-section-heading", children: (0, import_i18n7.__)("Paths", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.Button, { className: "evcert-appender", icon: plus_default, label: (0, import_i18n7.__)("Add path", "events-certificates"), onClick: () => replace([...paths, { d: "" }]) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.__experimentalItemGroup, { isBordered: true, isSeparated: true, className: "evcert-svg-paths", children: paths.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.__experimentalItem, { className: "evcert-svg-path", onMouseEnter: () => onFocus == null ? void 0 : onFocus(i), onMouseLeave: () => onFocus == null ? void 0 : onFocus(null), children: /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_components4.__experimentalHStack, { spacing: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(FillSwatch, { value: p.fill, current, design, mode, onChange: (fill) => setPath(i, { fill }) }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          import_components4.Dropdown,
          {
            className: "evcert-svg-path__link",
            popoverProps: { placement, offset: placement === "left-start" ? 36 : 8, shift: true },
            onToggle: (open) => onFocus == null ? void 0 : onFocus(open ? i : null),
            renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.Button, { variant: "link", className: "evcert-svg-path__d-link", onClick: onToggle, "aria-expanded": isOpen, title: p.d, children: p.d ? short(p.d) : (0, import_i18n7.__)("Add path data", "events-certificates") }),
            renderContent: () => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "evcert-svg-path__popover", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(PathData, { multiline: true, index: i, value: p.d, onChange: (d) => setPath(i, { d }), onImport }) })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "evcert-mover evcert-mover--inline", children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.Button, { size: "small", icon: chevron_up_default, label: (0, import_i18n7.__)("Move up", "events-certificates"), disabled: i === 0, accessibleWhenDisabled: true, onClick: () => move(i, i - 1) }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.Button, { size: "small", icon: chevron_down_default, label: (0, import_i18n7.__)("Move down", "events-certificates"), disabled: i === paths.length - 1, accessibleWhenDisabled: true, onClick: () => move(i, i + 1) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.DropdownMenu, { icon: more_vertical_default, label: (0, import_i18n7.__)("Path options", "events-certificates"), toggleProps: { size: "small" }, popoverProps: { placement: "bottom-end" }, children: ({ onClose }) => /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_components4.MenuGroup, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.MenuItem, { onClick: () => {
              move(i, 0);
              onClose();
            }, disabled: i === 0, children: (0, import_i18n7.__)("Move to bottom (behind)", "events-certificates") }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.MenuItem, { onClick: () => {
              move(i, paths.length - 1);
              onClose();
            }, disabled: i === paths.length - 1, children: (0, import_i18n7.__)("Move to top (in front)", "events-certificates") }),
            /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.MenuItem, { icon: copy_default, onClick: () => {
              replace([...paths.slice(0, i + 1), { ...p }, ...paths.slice(i + 1)]);
              onClose();
            }, children: (0, import_i18n7.__)("Duplicate", "events-certificates") })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.MenuGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_components4.MenuItem, { icon: trash_default, disabled: paths.length === 1 && !onEmpty, onClick: () => {
            remove(i);
            onClose();
          }, children: (0, import_i18n7.__)("Delete", "events-certificates") }) })
        ] }) })
      ] }) }, `${version}-${i}`)) })
    ] });
  }

  // src/editor/FieldText.tsx
  var import_components5 = __toESM(require_components());
  var import_element3 = __toESM(require_element());
  var import_i18n8 = __toESM(require_i18n());
  var import_jsx_runtime11 = __toESM(require_jsx_runtime());

  // src/editor/TextByLanguage.tsx
  var import_components6 = __toESM(require_components());
  var import_element4 = __toESM(require_element());
  var import_i18n9 = __toESM(require_i18n());
  var import_jsx_runtime12 = __toESM(require_jsx_runtime());

  // src/editor/Inspector.tsx
  var import_jsx_runtime13 = __toESM(require_jsx_runtime());
  var FONT_SIZES = [8, 10, 12, 14, 16, 18, 24, 32, 42].map((size) => ({ name: `${size} pt`, slug: String(size), size }));

  // src/editor/DesignPanel.tsx
  var import_jsx_runtime14 = __toESM(require_jsx_runtime());
  function Row({ label, children }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)(import_components8.__experimentalHStack, { className: "evcert-panel-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "evcert-panel-row__label", children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "evcert-panel-row__control", children })
    ] });
  }
  function DropdownRow({ label, value, children, plain = false }) {
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Row, { label, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(
      import_components8.Dropdown,
      {
        popoverProps: { placement: "left-start", offset: 36, shift: true, ...plain ? { className: "evcert-colors__popover-wrap" } : {} },
        renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components8.Button, { size: "compact", variant: "tertiary", onClick: onToggle, "aria-expanded": isOpen, children: value }),
        renderContent: ({ onClose }) => plain ? /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_jsx_runtime14.Fragment, { children: children(onClose) }) : /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("div", { className: "evcert-row-popover", children: children(onClose) })
      }
    ) });
  }

  // src/editor/SizeRow.tsx
  var import_jsx_runtime15 = __toESM(require_jsx_runtime());
  function SizeRow({ w, h, placeholder, disabled, onChange, note }) {
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(DropdownRow, { label: (0, import_i18n12.__)("Size", "events-certificates"), value: w && h ? `${w} \xD7 ${h}` : "- \xD7 -", children: () => /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(import_jsx_runtime15.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(import_components9.__experimentalHStack, { alignment: "top", children: [
        /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(import_components9.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n12.__)("Width", "events-certificates"), min: 1, disabled: disabled == null ? void 0 : disabled.w, placeholder: placeholder ? String(placeholder[0]) : void 0, value: w != null ? w : "", onChange: (v) => onChange("w", v) }),
        /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(import_components9.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n12.__)("Height", "events-certificates"), min: 1, disabled: disabled == null ? void 0 : disabled.h, placeholder: placeholder ? String(placeholder[1]) : void 0, value: h != null ? h : "", onChange: (v) => onChange("h", v) })
      ] }),
      note && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("p", { className: "description", children: note })
    ] }) });
  }

  // src/editor/SvgFields.tsx
  var import_jsx_runtime16 = __toESM(require_jsx_runtime());
  function sized(draft, side, raw, element) {
    const value = Number(raw);
    if (!(value > 0)) {
      return element ? draft : { ...draft, w: void 0, h: void 0 };
    }
    const ratio = draft.vw / draft.vh;
    const other = "w" === side ? Math.round(value / ratio * 100) / 100 : Math.round(value * ratio * 100) / 100;
    const next = { ...draft, [side]: value };
    const opposite = "w" === side ? "h" : "w";
    return next[opposite] ? next : { ...next, [opposite]: other };
  }
  function SvgFields({ draft, onChange, design, mode, current = "$text", element, before }) {
    const [focus, setFocus] = (0, import_element6.useState)(null);
    const { title, vw, vh, paths } = draft;
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "evcert-svg-editor__body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { className: "evcert-svg-editor__preview", children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("svg", { viewBox: `0 0 ${vw} ${vh}`, role: "img", "aria-label": title.trim() || (0, import_i18n13.__)("Preview", "events-certificates"), style: { "--evcert-ratio": vw / vh }, children: paths.map(
        (p, i) => p.d ? /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("path", { d: p.d, fill: color(design, p.fill || current, mode), fillRule: p.rule, opacity: focus === null || focus === i ? 1 : 0.25 }, i) : null
      ) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "evcert-svg-editor__fields", children: [
        before,
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
          SvgGroups,
          {
            viewBox: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(ViewBoxRow, { vw, vh, onChange: (patch) => onChange({ ...draft, ...patch }) }),
            size: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
              SizeRow,
              {
                w: draft.w,
                h: draft.h,
                placeholder: [vw, vh],
                onChange: (side, value) => onChange(sized(draft, side, value, element)),
                note: element ? void 0 : (0, import_i18n13.__)("The size to show it at, e.g. an icon of 24 \xD7 24 shown at 512 \xD7 512. Empty, it is the viewBox\u2019s; the certificate fits it in its place with this proportion.", "events-certificates")
              }
            ),
            paths: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(PathList, { paths, current, design, mode, onPaths: (next) => onChange({ ...draft, paths: next }), onFocus: setFocus, onEmpty: () => {
              setFocus(null);
              onChange(refilled(draft, element));
            }, onImport: (svg) => onChange({ ...draft, vw: svg.vw, vh: svg.vh, w: element ? draft.w : svg.w, h: element ? draft.h : svg.h, paths: svg.paths }) })
          }
        )
      ] })
    ] });
  }

  // src/editor/SvgSource.tsx
  var import_jsx_runtime17 = __toESM(require_jsx_runtime());
  var isSvgFile = (file) => /^image\/svg/i.test(file.type) || /\.svg$/i.test(file.name);
  function SvgSource({ draft, onChange, design, mode, current, element, base, dropFiles }) {
    const [text2, setText] = (0, import_element7.useState)("");
    const [problem, setProblem] = (0, import_element7.useState)("");
    const has = !!draft;
    (0, import_element7.useEffect)(() => {
      if (has) {
        setText("");
        setProblem("");
      }
    }, [has]);
    const take = (value, say, title = "") => {
      const parsed = parseSvgText(value, title);
      if ("draft" in parsed) {
        onChange(taken(parsed.draft, base, element));
        return true;
      }
      setProblem(say ? problemText(parsed.problem) : "");
      return false;
    };
    if (draft) {
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
        SvgFields,
        {
          draft,
          onChange,
          design,
          mode,
          current,
          element,
          before: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("div", { className: "evcert-svg-tab__again", children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(import_components10.Button, { variant: "tertiary", size: "compact", onClick: () => onChange(null), children: (0, import_i18n14.__)("Paste another SVG", "events-certificates") }) })
        }
      );
    }
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "evcert-svg-editor__body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("div", { className: "evcert-svg-editor__preview", children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("svg", { viewBox: "0 0 120 44", role: "img", "aria-label": (0, import_i18n14.__)("Preview", "events-certificates"), style: { "--evcert-ratio": 120 / 44 } }) }),
      /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "evcert-svg-editor__fields evcert-svg-code", children: [
        /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
          import_components10.TextareaControl,
          {
            __nextHasNoMarginBottom: true,
            label: (0, import_i18n14.__)("SVG code", "events-certificates"),
            help: (0, import_i18n14.__)("Paste the code of an SVG here, or drop an .svg file on this window.", "events-certificates"),
            placeholder: SVG_EXAMPLE,
            rows: 12,
            value: text2,
            spellCheck: false,
            onChange: (value) => {
              setText(value);
              take(value, false);
            },
            onPaste: (event) => {
              if (take(event.clipboardData.getData("text"), false)) {
                event.preventDefault();
              } else {
                setProblem(problemText(parseSvgText(event.clipboardData.getData("text")).problem));
              }
            },
            onBlur: () => text2.trim() && take(text2, true)
          }
        ),
        problem && /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("p", { className: "evcert-svg-code__problem", role: "alert", children: problem })
      ] }),
      dropFiles && /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
        import_components10.DropZone,
        {
          label: (0, import_i18n14.__)("Drop an .svg file to read its paths", "events-certificates"),
          onFilesDrop: (files) => {
            const file = files.find(isSvgFile);
            if (file) {
              file.text().then((value) => take(value, true, file.name.replace(/\.svg$/i, "")));
            }
          }
        }
      )
    ] });
  }

  // src/media-chooser/index.tsx
  var import_components11 = __toESM(require_components());
  var import_element8 = __toESM(require_element());
  var import_i18n16 = __toESM(require_i18n());

  // src/media-chooser/shared.ts
  var import_i18n15 = __toESM(require_i18n());
  var PATH_DESIGN = { page: { w: 120, h: 44, bg: "transparent", safe: 0, bleed: 0 }, colors: { text: { name: (0, import_i18n15.__)("Text", "events-certificates"), light: "#1e1e1e", dark: "#f0f0f0" } }, elements: [] };
  var drawingJson = (draft, paths) => JSON.stringify({ vw: draft.vw, vh: draft.vh, ...draft.w && draft.h ? { w: draft.w, h: draft.h } : {}, paths });
  var readVector = (json) => {
    try {
      const parsed = JSON.parse(json);
      return parsed && parsed.vw > 0 && parsed.vh > 0 && Array.isArray(parsed.paths) ? parsed : { vw: 120, vh: 44, paths: [] };
    } catch (e) {
      return { vw: 120, vh: 44, paths: [] };
    }
  };

  // src/media-chooser/index.tsx
  var import_jsx_runtime18 = __toESM(require_jsx_runtime());
  var hasMedia = () => {
    var _a;
    return !!((_a = window.wp) == null ? void 0 : _a.media);
  };
  async function svgFile(file) {
    const parsed = parseSvgText(await file.text(), file.name.replace(/\.svg$/i, ""));
    return "draft" in parsed ? parsed.draft : null;
  }
  var isSvgFile2 = (file) => /^image\/svg/i.test(file.type) || /\.svg$/i.test(file.name);
  async function readClipboard() {
    var _a;
    const read = () => navigator.clipboard.readText().catch(() => null);
    return (_a = await read()) != null ? _a : await new Promise((resolve3) => window.setTimeout(() => read().then(resolve3), 150));
  }
  var OFFER_MS = 9e3;
  var ERROR_MS = 6e3;
  var LEAVE_MS = 200;
  function ClipboardToast({ onPaste, modal }) {
    const [toast, setToast] = (0, import_element8.useState)(null);
    const [leaving, setLeaving] = (0, import_element8.useState)(false);
    const [paused, setPaused] = (0, import_element8.useState)(false);
    const handled = (0, import_element8.useRef)("");
    const current = (0, import_element8.useRef)(null);
    const busy = (0, import_element8.useRef)(false);
    const when = (0, import_element8.useRef)(0);
    const show = (0, import_element8.useCallback)((next) => {
      current.current = next;
      setLeaving(false);
      setToast(next);
    }, []);
    const dismiss = (0, import_element8.useCallback)(() => {
      const gone = current.current;
      if (!gone) {
        return;
      }
      if (gone.kind === "offer") {
        handled.current = gone.text;
      }
      current.current = null;
      setLeaving(true);
      window.setTimeout(() => {
        if (!current.current) {
          setToast(null);
          setLeaving(false);
        }
      }, LEAVE_MS);
    }, []);
    const check = (0, import_element8.useCallback)(async () => {
      var _a, _b;
      if (busy.current) {
        return;
      }
      busy.current = true;
      const clip = await readClipboard();
      busy.current = false;
      if (clip === null) {
        return;
      }
      const code = offerFor(clip, handled.current);
      if (code && ((_a = current.current) == null ? void 0 : _a.text) !== code) {
        show({ kind: "offer", text: code });
      } else if (!code && ((_b = current.current) == null ? void 0 : _b.kind) === "offer") {
        dismiss();
      }
    }, [show, dismiss]);
    (0, import_element8.useEffect)(() => {
      const again = () => {
        if (Date.now() - when.current > 1e3) {
          when.current = Date.now();
          check();
        }
      };
      const visible = () => document.visibilityState === "visible" && again();
      const problem = (event) => show({ kind: "error", text: event.detail });
      check();
      window.addEventListener("focus", again);
      document.addEventListener("visibilitychange", visible);
      window.addEventListener("evcert:svg-problem", problem);
      modal == null ? void 0 : modal.addEventListener("pointerenter", again);
      return () => {
        window.removeEventListener("focus", again);
        document.removeEventListener("visibilitychange", visible);
        window.removeEventListener("evcert:svg-problem", problem);
        modal == null ? void 0 : modal.removeEventListener("pointerenter", again);
      };
    }, [check, show, modal]);
    (0, import_element8.useEffect)(() => {
      if (!toast || leaving || paused) {
        return void 0;
      }
      const timer = window.setTimeout(dismiss, toast.kind === "error" ? ERROR_MS : OFFER_MS);
      return () => window.clearTimeout(timer);
    }, [toast, leaving, paused, dismiss]);
    if (!toast) {
      return null;
    }
    const hold = { onMouseEnter: () => setPaused(true), onMouseLeave: () => setPaused(false), onFocus: () => setPaused(true), onBlur: () => setPaused(false) };
    return /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)("div", { className: `evcert-toast${toast.kind === "error" ? " is-error" : ""}${leaving ? " is-leaving" : ""}`, role: toast.kind === "error" ? "alert" : "status", ...hold, children: [
      /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("span", { children: toast.kind === "error" ? toast.text : (0, import_i18n16.__)("You have an SVG copied. Paste it as the signature?", "events-certificates") }),
      toast.kind === "offer" && /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(
        "button",
        {
          type: "button",
          className: "button-link",
          onClick: () => {
            const parsed = parseSvgText(toast.text);
            if ("draft" in parsed) {
              onPaste(parsed.draft);
            }
            dismiss();
          },
          children: (0, import_i18n16.__)("Paste", "events-certificates")
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("button", { type: "button", className: "evcert-toast__close", "aria-label": (0, import_i18n16.__)("Close", "events-certificates"), onClick: dismiss, children: "\xD7" })
    ] });
  }
  function SvgTab({ start, onChoose, onClose }) {
    const [draft, setDraft] = (0, import_element8.useState)(() => start.paths.length ? start : defaultDrawing());
    (0, import_element8.useEffect)(() => {
      const set = (event) => setDraft(event.detail);
      window.addEventListener("evcert:svg-draft", set);
      return () => window.removeEventListener("evcert:svg-draft", set);
    }, []);
    const usable = ((draft == null ? void 0 : draft.paths) || []).filter((p) => p.d);
    return /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)(import_jsx_runtime18.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("div", { className: "evcert-svg-tab__content", children: /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(SvgSource, { draft, onChange: setDraft, design: PATH_DESIGN, mode: "light", base: start }) }),
      /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)("div", { className: "evcert-actions evcert-svg-editor__footer", children: [
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(import_components11.Button, { variant: "tertiary", __next40pxDefaultSize: true, onClick: onClose, children: (0, import_i18n16.__)("Cancel", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(import_components11.Button, { variant: "primary", __next40pxDefaultSize: true, disabled: !usable.length, accessibleWhenDisabled: true, onClick: () => draft && onChoose({ image: "", attachment: 0, json: drawingJson(draft, usable) }), children: (0, import_i18n16.__)("Apply", "events-certificates") })
      ] })
    ] });
  }
  function openMediaChooser({ title, button, suggested, start, onChoose }) {
    const media = window.wp.media;
    const frame = media({
      title,
      button: { text: button, close: false },
      multiple: false,
      states: [
        new media.controller.Library({
          title,
          library: media.query({ type: ["image/png", "image/jpeg", "image/gif", "image/webp"] }),
          // Never an SVG file: drawings are paths.
          multiple: false,
          date: false,
          priority: 20,
          suggestedWidth: suggested[0],
          suggestedHeight: suggested[1]
        })
      ]
    });
    const roots = [];
    const mount = (node, element) => {
      const root2 = (0, import_element8.createRoot)(node);
      root2.render(element);
      roots.push(root2);
    };
    frame.on("select", () => {
      var _a, _b;
      const attachment = frame.state().get("selection").first().toJSON();
      onChoose({ image: ((_b = (_a = attachment.sizes) == null ? void 0 : _a.large) == null ? void 0 : _b.url) || attachment.url, json: "", attachment: attachment.id });
      frame.close();
    });
    frame.on("router:render:browse", (router) => {
      router.set({ "evcert-svg": { text: (0, import_i18n16.__)("SVG", "events-certificates"), priority: 60 } });
    });
    frame.on("content:create:evcert-svg", () => {
      const View = media.View.extend({
        className: "evcert-signature-svgtab",
        render() {
          mount(this.el, /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(SvgTab, { start, onChoose: (choice) => {
            onChoose(choice);
            frame.close();
          }, onClose: () => frame.close() }));
          return this;
        }
      });
      frame.content.set(new View());
    });
    frame.on("content:activate:evcert-svg", () => frame.$el.addClass("evcert-svg-mode"));
    frame.on("content:deactivate:evcert-svg", () => frame.$el.removeClass("evcert-svg-mode"));
    const showDraft = (draft) => {
      frame.content.mode("evcert-svg");
      window.setTimeout(() => window.dispatchEvent(new CustomEvent("evcert:svg-draft", { detail: draft })), 50);
    };
    const files = (event) => {
      var _a;
      const target = event.target;
      return Array.from(event.type === "drop" ? ((_a = event.dataTransfer) == null ? void 0 : _a.files) || [] : (target == null ? void 0 : target.type) === "file" ? target.files || [] : []);
    };
    const takeSvg = (event) => {
      if (!frame.$el.closest(".media-modal").is(":visible")) {
        return;
      }
      const svg = files(event).find(isSvgFile2);
      if (!svg) {
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      if (event.type === "change") {
        event.target.value = "";
      } else {
        frame.modal.$el.trigger("dropzone:leave").removeClass("drag-over");
      }
      svgFile(svg).then((draft) => {
        if (draft) {
          showDraft(draft);
        } else {
          window.dispatchEvent(new CustomEvent("evcert:svg-problem", { detail: (0, import_i18n16.__)("That SVG could not be used: only its paths are read, so shapes and text must be converted to paths first, and it must be a small file.", "events-certificates") }));
        }
      });
    };
    frame.on("open", () => {
      document.addEventListener("drop", takeSvg, true);
      document.addEventListener("change", takeSvg, true);
      const host = document.createElement("div");
      host.className = "evcert-toast-host";
      const box2 = frame.$el.closest(".media-modal");
      box2.append(host);
      mount(host, /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(ClipboardToast, { onPaste: showDraft, modal: box2[0] }));
    });
    frame.on("close", () => {
      document.removeEventListener("drop", takeSvg, true);
      document.removeEventListener("change", takeSvg, true);
      roots.splice(0).forEach((root2) => window.setTimeout(() => root2.unmount(), 0));
      frame.$el.closest(".media-modal").find(".evcert-toast-host").remove();
    });
    frame.open();
  }

  // src/settings-signature/index.tsx
  var import_jsx_runtime19 = __toESM(require_jsx_runtime());
  var config = window.evcertSignatureField;
  var EMPTY = { title: "", vw: 120, vh: 44, paths: [] };
  function Preview({ choice }) {
    const drawn = readVector(choice.json);
    if (choice.image) {
      return /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("img", { className: "evcert-signature-field__preview", src: choice.image, alt: (0, import_i18n17.__)("Current signature", "events-certificates") });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("svg", { className: "evcert-signature-field__preview", viewBox: `0 0 ${drawn.vw} ${drawn.vh}`, role: "img", "aria-label": (0, import_i18n17.__)("Current signature", "events-certificates"), children: drawn.paths.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("path", { d: p.d, fill: p.fill && !p.fill.startsWith("$") ? p.fill : "currentColor", fillRule: p.rule }, i)) });
  }
  function UploadTab({ onPicked, onSvg }) {
    const [error, setError] = (0, import_element9.useState)("");
    const [busy, setBusy] = (0, import_element9.useState)(false);
    const handle = async (file) => {
      var _a, _b, _c;
      setError("");
      setBusy(true);
      try {
        if ("image/svg+xml" === file.type || /\.svg$/i.test(file.name)) {
          const svg = file.size > SVG_LIMITS.bytes ? null : sanitizeSvg(await file.text());
          if (!svg || !svg.paths.length) {
            setError((0, import_i18n17.__)("That SVG cannot be used: it is too big, carries scripts or has no filled paths. Paths are what a signature is made of.", "events-certificates"));
          } else {
            onSvg({ title: file.name.replace(/\.svg$/i, ""), ...svg });
          }
          return;
        }
        if (!config.canUpload) {
          setError((0, import_i18n17.__)("You are not allowed to upload files. Choose one from the media library, or use an SVG.", "events-certificates"));
          return;
        }
        const body = new FormData();
        body.append("file", file, file.name);
        const made = await (0, import_api_fetch2.default)({ path: "/wp/v2/media", method: "POST", body });
        onPicked({ image: ((_c = (_b = (_a = made.media_details) == null ? void 0 : _a.sizes) == null ? void 0 : _b.large) == null ? void 0 : _c.source_url) || made.source_url, json: "", attachment: made.id });
      } catch (e) {
        setError((0, import_i18n17.__)("That picture could not be read. Use a PNG, JPEG, GIF, WebP or SVG.", "events-certificates"));
      } finally {
        setBusy(false);
      }
    };
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "evcert-signature-upload", children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.DropZone, { onFilesDrop: (files) => files[0] && handle(files[0]), label: (0, import_i18n17.__)("Drop files to upload", "events-certificates") }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { className: "evcert-signature-upload__title", children: (0, import_i18n17.__)("Drop files to upload", "events-certificates") }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { children: (0, import_i18n17.__)("or", "events-certificates") }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.FormFileUpload, { accept: "image/png,image/jpeg,image/gif,image/webp,image/svg+xml,.svg", onChange: (e) => {
        var _a;
        const first = (_a = e.currentTarget.files) == null ? void 0 : _a[0];
        if (first) {
          handle(first);
        }
        e.currentTarget.value = "";
      }, render: ({ openFileDialog }) => /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Button, { variant: "secondary", __next40pxDefaultSize: true, onClick: openFileDialog, disabled: busy, children: (0, import_i18n17.__)("Select Files", "events-certificates") }) }),
      busy && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Spinner, {}),
      error && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { className: "evcert-signature-upload__error", role: "alert", children: error }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("p", { className: "description", children: [
        (0, import_i18n17.sprintf)(
          /* translators: %s: the largest file size WordPress accepts (2 GB). */
          (0, import_i18n17.__)("Maximum upload file size: %s.", "events-certificates"),
          config.maxUpload
        ),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("br", {}),
        (0, import_i18n17.sprintf)(
          /* translators: %s: suggested pixels, e.g. 600 × 220. */
          (0, import_i18n17.__)("Suggested image dimensions: %s pixels.", "events-certificates"),
          config.suggested
        )
      ] })
    ] });
  }
  function LibraryTab({ onPicked }) {
    const [items, setItems] = (0, import_element9.useState)([]);
    const [search, setSearch] = (0, import_element9.useState)("");
    const [page, setPage] = (0, import_element9.useState)(1);
    const [pages, setPages] = (0, import_element9.useState)(1);
    const [busy, setBusy] = (0, import_element9.useState)(true);
    const [error, setError] = (0, import_element9.useState)("");
    const first = (0, import_element9.useRef)(true);
    (0, import_element9.useEffect)(() => {
      let live = true;
      setBusy(true);
      const timer = window.setTimeout(() => {
        (0, import_api_fetch2.default)({ path: `/wp/v2/media?media_type=image&per_page=24&page=${page}&search=${encodeURIComponent(search)}&_fields=id,mime_type,source_url,alt_text,title,media_details`, parse: false }).then(async (response) => {
          const list = await response.json();
          if (!live) {
            return;
          }
          setPages(Number(response.headers.get("X-WP-TotalPages")) || 1);
          setItems((old) => (page > 1 ? [...old, ...list] : list).filter((m) => "image/svg+xml" !== m.mime_type));
          setError("");
        }).catch(() => live && setError((0, import_i18n17.__)("The media library could not be loaded.", "events-certificates"))).finally(() => live && setBusy(false));
      }, first.current ? 0 : 300);
      first.current = false;
      return () => {
        live = false;
        window.clearTimeout(timer);
      };
    }, [search, page]);
    const pick = async (media) => {
      var _a, _b, _c;
      setBusy(true);
      onPicked({ image: ((_c = (_b = (_a = media.media_details) == null ? void 0 : _a.sizes) == null ? void 0 : _b.large) == null ? void 0 : _c.source_url) || media.source_url, json: "", attachment: media.id });
      setBusy(false);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "evcert-signature-library", children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("input", { type: "search", className: "evcert-signature-library__search", value: search, placeholder: (0, import_i18n17.__)("Search media", "events-certificates"), "aria-label": (0, import_i18n17.__)("Search media", "events-certificates"), onChange: (e) => {
        setPage(1);
        setSearch(e.target.value);
      } }),
      error && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { className: "evcert-signature-upload__error", role: "alert", children: error }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("ul", { className: "evcert-signature-library__grid", children: items.map((media) => {
        var _a, _b, _c;
        return /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", onClick: () => pick(media), "aria-label": media.alt_text || media.title.rendered, children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("img", { src: ((_c = (_b = (_a = media.media_details) == null ? void 0 : _a.sizes) == null ? void 0 : _b.thumbnail) == null ? void 0 : _c.source_url) || media.source_url, alt: "", loading: "lazy" }) }) }, media.id);
      }) }),
      !busy && !items.length && !error && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { className: "description", children: (0, import_i18n17.__)("No images found.", "events-certificates") }),
      busy && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Spinner, {}),
      !busy && page < pages && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Button, { variant: "secondary", onClick: () => setPage(page + 1), children: (0, import_i18n17.__)("Load more", "events-certificates") })
    ] });
  }
  function Chooser({ onChoose, onClose, start }) {
    const [tab, setTab] = (0, import_element9.useState)("upload");
    const [draft, setDraft] = (0, import_element9.useState)(() => start.paths.length ? start : defaultDrawing());
    const tabs = [
      ["upload", (0, import_i18n17.__)("Upload files", "events-certificates")],
      ["library", (0, import_i18n17.__)("Media Library", "events-certificates")],
      ["svg", (0, import_i18n17.__)("Edit SVG", "events-certificates")]
    ];
    const usable = ((draft == null ? void 0 : draft.paths) || []).filter((p) => p.d);
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)(import_components12.Modal, { title: (0, import_i18n17.__)("Choose a certificate signature", "events-certificates"), size: "large", onRequestClose: onClose, className: "evcert-signature-modal", children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(ClipboardToast, { onPaste: (next) => {
        setDraft(next);
        setTab("svg");
      } }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("div", { className: "evcert-signature-modal__tabs", role: "tablist", "aria-label": (0, import_i18n17.__)("Choose a certificate signature", "events-certificates"), children: tabs.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", role: "tab", id: `evcert-signature-tab-${id}`, "aria-selected": tab === id, "aria-controls": `evcert-signature-panel-${id}`, className: tab === id ? "is-active" : "", onClick: () => setTab(id), children: label }, id)) }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { role: "tabpanel", id: `evcert-signature-panel-${tab}`, "aria-labelledby": `evcert-signature-tab-${tab}`, className: "evcert-signature-modal__panel", children: [
        "upload" === tab && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(UploadTab, { onPicked: onChoose, onSvg: (next) => {
          setDraft(next);
          setTab("svg");
        } }),
        "library" === tab && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(LibraryTab, { onPicked: onChoose }),
        "svg" === tab && /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)(import_jsx_runtime19.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(SvgSource, { draft, onChange: setDraft, design: PATH_DESIGN, mode: "light", base: start, dropFiles: true }),
          /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "evcert-actions evcert-svg-editor__footer", children: [
            /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Button, { variant: "tertiary", __next40pxDefaultSize: true, onClick: onClose, children: (0, import_i18n17.__)("Cancel", "events-certificates") }),
            /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(import_components12.Button, { variant: "primary", __next40pxDefaultSize: true, disabled: !usable.length, accessibleWhenDisabled: true, onClick: () => draft && onChoose({ image: "", attachment: 0, json: drawingJson(draft, usable) }), children: (0, import_i18n17.__)("Apply", "events-certificates") })
          ] })
        ] })
      ] })
    ] });
  }
  function Field() {
    const [choice, setChoice] = (0, import_element9.useState)({ image: config.image, json: config.json, attachment: config.attachment });
    const [open, setOpen] = (0, import_element9.useState)(false);
    const drawn = readVector(choice.json);
    const has = !!choice.image || drawn.paths.some((p) => p.d);
    const start = drawn.paths.length ? { title: "", vw: drawn.vw, vh: drawn.vh, w: drawn.w, h: drawn.h, paths: drawn.paths } : EMPTY;
    const pick = (next) => {
      setChoice(next);
      setOpen(false);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)(import_jsx_runtime19.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("input", { type: "hidden", name: `${config.option}[signature_json]`, value: choice.json }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("input", { type: "hidden", name: `${config.option}[signature_attachment]`, value: choice.attachment || "" }),
      has && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("div", { className: "evcert-signature-field__current", children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Preview, { choice }) }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "site-icon-action-buttons", children: [
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "upload-button button-hero button", "aria-haspopup": "dialog", onClick: () => "media" === config.chooser && hasMedia() ? openMediaChooser({ title: (0, import_i18n17.__)("Choose a certificate signature", "events-certificates"), button: (0, import_i18n17.__)("Set as certificate signature", "events-certificates"), suggested: [600, 220], start, onChoose: pick }) : setOpen(true), children: has ? (0, import_i18n17.__)("Change certificate signature", "events-certificates") : (0, import_i18n17.__)("Choose a certificate signature", "events-certificates") }),
        has && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "button button-secondary reset remove-site-icon evcert-remove", onClick: () => setChoice({ image: "", json: "", attachment: 0 }), children: (0, import_i18n17.__)("Remove certificate signature", "events-certificates") })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { className: "description", children: (0, import_element9.createInterpolateElement)(
        (0, import_i18n17.sprintf)(
          /* translators: %s: suggested pixels wrapped in <code>, e.g. <code>600 by 220</code>. */
          (0, import_i18n17.__)("The signature closes each certificate. It should have a transparent background and be at least %s pixels.", "events-certificates"),
          "<code>" + config.suggested.replace(" \xD7 ", " " + (0, import_i18n17._x)("by", "between the width and the height of a picture", "events-certificates") + " ") + "</code>"
        ),
        { code: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("code", {}) }
      ) }),
      open && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Chooser, { onChoose: pick, onClose: () => setOpen(false), start })
    ] });
  }
  var root = document.getElementById("evcert-signature-field");
  if (root && config) {
    (0, import_element9.createRoot)(root).render(/* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Field, {}));
  }
})();
//# sourceMappingURL=settings-signature.js.map
