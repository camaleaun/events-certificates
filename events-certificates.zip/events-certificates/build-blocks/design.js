"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // package-external:@wordpress/i18n
  var require_i18n = __commonJS({
    "package-external:@wordpress/i18n"(exports, module) {
      module.exports = window.wp.i18n;
    }
  });

  // vendor/camaleaun/draw/packages/js/src/geometry.ts
  var UNITS = { pt: 1, px: 1, mm: 2.83465, cm: 28.3465, in: 72 };
  function parseLen(value, total) {
    if (value === void 0 || value === "") {
      return 0;
    }
    if (typeof value === "number") {
      return value;
    }
    let expr = value.trim().toLowerCase();
    const calc = /^calc\((.*)\)$/.exec(expr);
    if (calc) {
      expr = calc[1];
    }
    let sum = 0;
    const re = /([+-]?)\s*(-?\d*\.?\d+)\s*(pt|px|mm|cm|in|%)?/g;
    let m;
    let matched = false;
    while (m = re.exec(expr)) {
      matched = true;
      const n = parseFloat(m[2]) * (m[1] === "-" ? -1 : 1);
      sum += m[3] === "%" ? n * total / 100 : n * (UNITS[m[3] || "pt"] || 1);
    }
    return matched ? sum : 0;
  }
  function refBox(page, ref) {
    return ref === "safe" ? { x: page.safe, y: page.safe, w: page.w - page.safe * 2, h: page.h - page.safe * 2 } : { x: 0, y: 0, w: page.w, h: page.h };
  }
  function resolveAxis(axis, origin, total, forced) {
    const start = parseLen(axis.start, total);
    const end = parseLen(axis.end, total);
    const size = forced !== void 0 ? forced : parseLen(axis.size, total);
    switch (axis.mode) {
      case "end":
        return [origin + total - end - size, size];
      case "center":
        return [origin + (total - size) / 2 + start, size];
      case "stretch":
        return [origin + start, Math.max(1, total - start - end)];
      default:
        return [origin + start, size];
    }
  }
  function resolve(el, page) {
    const layout = el.layout;
    if (!layout || el.type === "line") {
      return el;
    }
    const r = refBox(page, layout.ref);
    let [x, w] = resolveAxis(layout.h, r.x, r.w);
    let [y, h] = resolveAxis(layout.v, r.y, r.h);
    const ratio = lockedRatio(el);
    const side = ratio ? lockedSide(layout) : null;
    if (ratio && side === "w") {
      [x, w] = resolveAxis(layout.h, r.x, r.w, h * ratio);
    } else if (ratio && side === "h") {
      [y, h] = resolveAxis(layout.v, r.y, r.h, w / ratio);
    }
    return { ...el, x, y, w, h };
  }
  function lockedRatio(el) {
    if (el.type === "image") {
      const parts = (el.ratio || "auto").split("/").map(Number);
      return parts.length === 2 && parts[0] > 0 && parts[1] > 0 ? parts[0] / parts[1] : void 0;
    }
    const lock = el.lock;
    return lock && lock > 0 ? lock : void 0;
  }
  function lockedSide(layout) {
    const h = layout.h.mode === "stretch";
    const v = layout.v.mode === "stretch";
    if (h && v) {
      return null;
    }
    return v ? "w" : "h";
  }
  function rectPath(x, y, w, h, radius = [], shape = "round") {
    const r = [0, 1, 2, 3].map((i) => Math.max(0, Math.min(radius[i] || 0, w / 2, h / 2)));
    const f = (n) => Math.round(n * 100) / 100;
    const corners = [
      { c: [x, y], in: [0, 1], out: [1, 0] },
      // top-left: coming up the left edge, leaving right.
      { c: [x + w, y], in: [-1, 0], out: [0, 1] },
      { c: [x + w, y + h], in: [0, -1], out: [-1, 0] },
      { c: [x, y + h], in: [1, 0], out: [0, -1] }
    ];
    let d = "";
    corners.forEach(({ c, in: din, out }, i) => {
      const rr = r[i];
      const start = [c[0] + din[0] * rr, c[1] + din[1] * rr];
      const end = [c[0] + out[0] * rr, c[1] + out[1] * rr];
      d += (i === 0 ? "M" : "L") + `${f(start[0])} ${f(start[1])}`;
      if (!rr) {
        return;
      }
      switch (shape) {
        case "scoop":
          d += `A${f(rr)} ${f(rr)} 0 0 0 ${f(end[0])} ${f(end[1])}`;
          break;
        case "bevel":
          d += `L${f(end[0])} ${f(end[1])}`;
          break;
        case "notch": {
          const inner = [start[0] + end[0] - c[0], start[1] + end[1] - c[1]];
          d += `L${f(inner[0])} ${f(inner[1])}L${f(end[0])} ${f(end[1])}`;
          break;
        }
        case "squircle": {
          const k = 0.18;
          const c1 = [c[0] + (start[0] - c[0]) * k, c[1] + (start[1] - c[1]) * k];
          const c2 = [c[0] + (end[0] - c[0]) * k, c[1] + (end[1] - c[1]) * k];
          d += `C${f(c1[0])} ${f(c1[1])} ${f(c2[0])} ${f(c2[1])} ${f(end[0])} ${f(end[1])}`;
          break;
        }
        default:
          d += `A${f(rr)} ${f(rr)} 0 0 1 ${f(end[0])} ${f(end[1])}`;
      }
    });
    return d + "Z";
  }

  // src/editor/model.ts
  var import_i18n = __toESM(require_i18n());
  var resolve2 = (el, page) => resolve(el, page);
  function box(el) {
    if (el.type === "line") {
      const x = Math.min(el.x1, el.x2);
      const y = Math.min(el.y1, el.y2);
      return { x, y, w: Math.abs(el.x2 - el.x1), h: Math.abs(el.y2 - el.y1) };
    }
    return { x: el.x, y: el.y, w: el.w, h: el.h };
  }
  function colorOf(v, mode) {
    return mode === "dark" && v.dark ? v.dark : v.light;
  }
  function builtinColor(key, mode) {
    const dark = mode === "dark";
    switch (key) {
      case "text":
      case "muted":
      case "line":
        return dark ? "#ffffff" : "#000000";
      case "background":
        return "transparent";
      case "primary":
        return "#3858e9";
    }
    return "";
  }
  function isWhite(value) {
    const v = (value || "").toLowerCase().replace(/\s+/g, "");
    return /^#(f{3,4}|f{6}|f{8})$/.test(v) || v === "white" || v === "rgb(255,255,255)" || v === "rgba(255,255,255,1)";
  }
  function color(design, value, mode, depth = 0) {
    if (!value) {
      return "none";
    }
    if (value.startsWith("$")) {
      const key = value.slice(1);
      const v = design.colors[key];
      if (v) {
        const own = colorOf(v, mode);
        if (own.startsWith("$")) {
          return depth < 5 ? color(design, own, mode, depth + 1) : "none";
        }
        return own || "none";
      }
      const swatch = (design.palette || []).find((s) => s.slug === key);
      return swatch ? swatch.color : builtinColor(key, mode) || "none";
    }
    return value;
  }
  function parseText(text) {
    const runs = [];
    const parts = text.split(/(\*\*.+?\*\*)/);
    for (const part of parts) {
      const bold = /^\*\*(.+)\*\*$/.exec(part);
      const body = bold ? bold[1] : part;
      for (const piece of body.split(/(\{[a-z_]+\})/)) {
        if (!piece) {
          continue;
        }
        const field = /^\{([a-z_]+)\}$/.exec(piece);
        const run = field ? { field: field[1] } : { text: piece };
        if (bold) {
          run.b = true;
        }
        runs.push(run);
      }
    }
    return runs;
  }
  function runsOf(el) {
    return el.runs || parseText(el.text || "");
  }
  function runsIn(el, locale) {
    const variant = (el.variants || {})[locale.replace("-", "_")];
    return variant && variant.length ? variant : runsOf(el);
  }
  function pageBg(page, mode) {
    var _a;
    return typeof page.bg === "string" ? page.bg : ((_a = page.bg) == null ? void 0 : _a[mode]) || "";
  }

  // src/quick-generator/design.ts
  var PT = 0.3528;
  var VOUCHING = ["authenticity", "code", "verify"];
  var SERIF = /serif|lora|georgia|times|garamond/i;
  function fontOf(b, el) {
    const family = (el.font || "").replace(/['"]/g, "").split(",")[0].trim();
    const want = el.weight || 400;
    const weight = [400, 500, 600].reduce((best, w) => Math.abs(w - want) < Math.abs(best - want) ? w : best, 400);
    const face = `${family}:${weight}`;
    if (b.fonts.includes(face)) {
      return face;
    }
    return SERIF.test(family) && !/sans/i.test(family) ? "CertSerif:400" : want >= 600 ? "CertSans:600" : "CertSans:400";
  }
  function cssFont(face, px) {
    const [family, weight] = face.split(":");
    return `${weight} ${px}px "${family}", ${SERIF.test(family) && !/sans/i.test(family) ? "Georgia, serif" : "system-ui, sans-serif"}`;
  }
  var METRICS = {};
  function metricsOf(face) {
    if (METRICS[face]) {
      return METRICS[face];
    }
    let found = { ascent: SERIF.test(face) ? 0.99 : 1.025, descent: SERIF.test(face) ? 0.31 : 0.275 };
    if (typeof document !== "undefined") {
      const ctx = document.createElement("canvas").getContext("2d");
      if (ctx) {
        ctx.font = cssFont(face, 100);
        const m = ctx.measureText("Hg");
        if (m.fontBoundingBoxAscent) {
          found = { ascent: m.fontBoundingBoxAscent / 100, descent: m.fontBoundingBoxDescent / 100 };
          if (document.fonts && document.fonts.check(cssFont(face, 16))) {
            METRICS[face] = found;
          }
        }
      }
    }
    return found;
  }
  function fontsUsed(design, shipped) {
    const probe = { fonts: shipped };
    const faces = /* @__PURE__ */ new Set(["CertSerif:400", "CertSans:400", "CertSans:600"]);
    design.elements.forEach((raw) => {
      const el = resolve2(raw, design.page);
      if ("text" === el.type) {
        faces.add(fontOf(probe, el));
      }
    });
    return [...faces].filter((face) => shipped.includes(face));
  }
  function textOf(runs, value) {
    return (runs || []).map((run) => "field" in run ? value(run.field, run.format) : run.text).join("");
  }
  function orphanLabels(design, value) {
    const texts = /* @__PURE__ */ new Map();
    design.elements.forEach((raw) => {
      const el = resolve2(raw, design.page);
      if ("text" === el.type && el.id) {
        texts.set(el.id, el);
      }
    });
    const orphans = /* @__PURE__ */ new Set();
    texts.forEach((_el, id) => {
      const pair = id.endsWith("-label") ? texts.get(id.slice(0, -6) + "-value") : void 0;
      if (pair && !pair.hidden && "" === textOf(pair.runs, value).trim()) {
        orphans.add(id);
      }
    });
    return orphans;
  }
  function wrap(b, text, font, size, max, spacing) {
    const lines = [];
    text.split("\n").forEach((paragraph) => {
      let line = "";
      paragraph.split(/\s+/).filter(Boolean).forEach((word) => {
        const attempt = line ? line + " " + word : word;
        if (!line || b.measure(attempt, font, size, spacing) <= max) {
          line = attempt;
        } else {
          lines.push(line);
          line = word;
        }
      });
      lines.push(line);
    });
    return lines;
  }
  function isFilled(value) {
    return !!value && "none" !== value && "transparent" !== value;
  }
  function drawText(b, design, el, value, locale) {
    let text = textOf(runsIn(el, locale), value);
    if (el.upper) {
      text = text.toLocaleUpperCase(locale);
    }
    if ("" === text.trim()) {
      return;
    }
    const font = fontOf(b, el);
    const spacing = (el.ls || 0) * PT;
    const width = el.w * PT;
    let size = el.size || 14;
    if (el.fit) {
      const natural = b.measure(text.replace(/\n/g, " "), font, size, spacing);
      if (natural > width && natural > 0) {
        size = Math.max(el.min || 8, size * width / natural);
      }
    }
    const lh = el.lh || 1.2;
    const lines = el.fit ? [text.replace(/\n/g, " ")] : wrap(b, text, font, size, width, spacing);
    const m = metricsOf(font);
    const base = size * ((lh - (m.ascent + m.descent)) / 2 + m.ascent) * PT;
    const pitch = size * lh * PT;
    const left = el.x * PT;
    const top = el.y * PT;
    const cx = left + width / 2;
    const cy = top + el.h * PT / 2;
    const turn = (el.rotation || 0) * Math.PI / 180;
    const ink = color(design, el.color || "$text", "light");
    lines.forEach((line, i) => {
      const w = b.measure(line, font, size, spacing);
      const x = "center" === el.align ? left + (width - w) / 2 : "right" === el.align ? left + width - w : left;
      const y = top + base + i * pitch;
      if (!turn) {
        b.text(line, x, y, { font, size, color: ink, cs: spacing });
        return;
      }
      const dx = x - cx;
      const dy = y - cy;
      b.text(line, cx + dx * Math.cos(turn) - dy * Math.sin(turn), cy + dx * Math.sin(turn) + dy * Math.cos(turn), { font, size, color: ink, cs: spacing, angle: -(el.rotation || 0) });
    });
  }
  function artOf(design, el) {
    const fill = (value) => color(design, value, "light");
    if (el.type === "svg") {
      const paths = (el.paths || []).map((p) => `<path d="${p.d}" fill="${isFilled(fill(p.fill)) ? fill(p.fill) : fill(el.color || "$text")}"${"evenodd" === p.rule ? ' fill-rule="evenodd"' : ""}/>`).join("");
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.vw} ${el.vh}" width="${el.w}" height="${el.h}">${paths}</svg>`, w: el.w, h: el.h };
    }
    if (el.type === "path") {
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.vw} ${el.vh}" width="${el.w}" height="${el.h}"><path d="${el.d}" fill="${fill(el.fill)}" stroke="${fill(el.stroke)}" stroke-width="${el.strokeWidth || 0}"/></svg>`, w: el.w, h: el.h };
    }
    if (el.type === "ellipse") {
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.w} ${el.h}" width="${el.w}" height="${el.h}"><ellipse cx="${el.w / 2}" cy="${el.h / 2}" rx="${el.w / 2}" ry="${el.h / 2}" fill="${fill(el.fill)}"/></svg>`, w: el.w, h: el.h };
    }
    if (el.type === "rect" && (el.radius && el.radius.some(Boolean) || el.rotation)) {
      const sw = el.strokeWidth || 0;
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${-sw / 2} ${-sw / 2} ${el.w + sw} ${el.h + sw}" width="${el.w + sw}" height="${el.h + sw}"><path d="${rectPath(0, 0, el.w, el.h, el.radius, el.corner)}" fill="${fill(el.fill)}" stroke="${fill(el.stroke)}" stroke-width="${sw}"/></svg>`, w: el.w + sw, h: el.h + sw };
    }
    return null;
  }
  function rasterize(svg, w, h, alias) {
    return new Promise((resolveImage, reject) => {
      const img = new Image();
      img.onload = () => {
        var _a;
        const scale = 4;
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(w * scale));
        canvas.height = Math.max(1, Math.round(h * scale));
        (_a = canvas.getContext("2d")) == null ? void 0 : _a.drawImage(img, 0, 0, canvas.width, canvas.height);
        const src = canvas.toDataURL("image/png");
        const png = new Image();
        png.onload = () => resolveImage({ src, img: png, ratio: w / h, alias });
        png.src = src;
      };
      img.onerror = reject;
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
    });
  }
  function rotated(pic, angle, w, h) {
    return new Promise((resolveImage) => {
      const img = pic.img;
      if (!img) {
        resolveImage(pic);
        return;
      }
      const rad = angle * Math.PI / 180;
      const cos = Math.abs(Math.cos(rad));
      const sin = Math.abs(Math.sin(rad));
      const bw = w * cos + h * sin;
      const bh = w * sin + h * cos;
      const scale = img.naturalWidth / w;
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(bw * scale));
      canvas.height = Math.max(1, Math.round(bh * scale));
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(rad);
        ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
      }
      const src = canvas.toDataURL("image/png");
      const png = new Image();
      png.onload = () => resolveImage({ src, img: png, ratio: bw / bh, alias: pic.alias + "-r", rot: { w: bw, h: bh } });
      png.src = src;
    });
  }
  async function prepare(design) {
    const art = {};
    for (const raw of design.elements) {
      const el = resolve2(raw, design.page);
      if (el.hidden || "signature" === el.type) {
        continue;
      }
      const found = artOf(design, el);
      if (found) {
        try {
          const flat = await rasterize(found.svg, found.w, found.h, "art-" + el.id);
          art[el.id] = el.rotation ? await rotated(flat, el.rotation, found.w, found.h) : flat;
        } catch (e) {
        }
      }
    }
    return art;
  }
  function draw(b, design, value, pictures, locale) {
    const page = design.page;
    const bg = color(design, pageBg(page, "light"), "light");
    const fill = isFilled(bg) ? bg : "#ffffff";
    if (!(b.skipWhitePage && isWhite(fill))) {
      b.rect(0, 0, page.w * PT, page.h * PT, fill);
    }
    let logoDrawn = false;
    const orphans = orphanLabels(design, value);
    for (const raw of design.elements) {
      const el = resolve2(raw, page);
      if (el.hidden || el.type === "verification" || VOUCHING.includes(el.slot || "") || orphans.has(el.id)) {
        continue;
      }
      b.alpha(el.opacity === void 0 ? 1 : el.opacity);
      const art = pictures.art && pictures.art[el.id];
      if (art) {
        const at = box(el);
        if (art.rot) {
          const cx = at.x + at.w / 2;
          const cy = at.y + at.h / 2;
          b.image(art, (cx - art.rot.w / 2) * PT, (cy - art.rot.h / 2) * PT, art.rot.w * PT, art.rot.h * PT);
        } else {
          b.image(art, at.x * PT, at.y * PT, at.w * PT, at.h * PT);
        }
        continue;
      }
      switch (el.type) {
        case "text":
          drawText(b, design, el, value, locale);
          break;
        case "rect": {
          const fill2 = color(design, el.fill, "light");
          if (isFilled(fill2)) {
            b.rect(el.x * PT, el.y * PT, el.w * PT, el.h * PT, fill2);
          }
          const stroke = color(design, el.stroke, "light");
          if (isFilled(stroke) && (el.strokeWidth || 0) > 0) {
            const [x, y, w, h] = [el.x * PT, el.y * PT, el.w * PT, el.h * PT];
            const width = (el.strokeWidth || 0) * PT;
            [[x, y, x + w, y], [x + w, y, x + w, y + h], [x + w, y + h, x, y + h], [x, y + h, x, y]].forEach(([x1, y1, x2, y2]) => b.line(x1, y1, x2, y2, stroke, width));
          }
          break;
        }
        case "line":
          b.line(el.x1 * PT, el.y1 * PT, el.x2 * PT, el.y2 * PT, color(design, el.stroke || "$line", "light"), (el.strokeWidth || 1) * PT);
          break;
        case "signature":
          if (pictures.signature) {
            const w = Math.min(el.w, el.h * pictures.signature.ratio) * PT;
            const h = w / pictures.signature.ratio;
            b.image(pictures.signature, el.x * PT, (el.y + el.h) * PT - h, w, h);
          }
          break;
        case "image":
          if (("logo" === el.slot || "logo" === el.id) && pictures.logo) {
            const ratio = pictures.logo.ratio;
            const w = Math.min(el.w * PT, el.h * PT * ratio);
            const h = w / ratio;
            b.image(pictures.logo, (el.x + el.w) * PT - w, el.y * PT + (el.h * PT - h) / 2, w, h);
            logoDrawn = true;
          }
          break;
        default:
          break;
      }
    }
    b.alpha(1);
    if (pictures.logo && !logoDrawn) {
      const found = design.elements.map((e) => resolve2(e, page)).find((e) => "title" === e.id || "title" === e.slot);
      const title = found ? box(found) : null;
      const right = (title ? title.x + title.w : page.w - (page.safe || 28)) * PT;
      let w = 62;
      let h = w / pictures.logo.ratio;
      if (h > 18) {
        h = 18;
        w = h * pictures.logo.ratio;
      }
      b.image(pictures.logo, right - w, 20 + (18 - h) / 2, w, h);
    }
  }
  window.evcertDesign = { draw, prepare, css: cssFont, fontsUsed };
})();
//# sourceMappingURL=design.js.map
