"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // package-external:@wordpress/a11y
  var require_a11y = __commonJS({
    "package-external:@wordpress/a11y"(exports, module) {
      module.exports = window.wp.a11y;
    }
  });

  // package-external:@wordpress/api-fetch
  var require_api_fetch = __commonJS({
    "package-external:@wordpress/api-fetch"(exports, module) {
      module.exports = window.wp.apiFetch;
    }
  });

  // package-external:@wordpress/components
  var require_components = __commonJS({
    "package-external:@wordpress/components"(exports, module) {
      module.exports = window.wp.components;
    }
  });

  // package-external:@wordpress/commands
  var require_commands = __commonJS({
    "package-external:@wordpress/commands"(exports, module) {
      module.exports = window.wp.commands;
    }
  });

  // package-external:@wordpress/data
  var require_data = __commonJS({
    "package-external:@wordpress/data"(exports, module) {
      module.exports = window.wp.data;
    }
  });

  // package-external:@wordpress/date
  var require_date = __commonJS({
    "package-external:@wordpress/date"(exports, module) {
      module.exports = window.wp.date;
    }
  });

  // package-external:@wordpress/element
  var require_element = __commonJS({
    "package-external:@wordpress/element"(exports, module) {
      module.exports = window.wp.element;
    }
  });

  // package-external:@wordpress/i18n
  var require_i18n = __commonJS({
    "package-external:@wordpress/i18n"(exports, module) {
      module.exports = window.wp.i18n;
    }
  });

  // package-external:@wordpress/primitives
  var require_primitives = __commonJS({
    "package-external:@wordpress/primitives"(exports, module) {
      module.exports = window.wp.primitives;
    }
  });

  // vendor-external:react/jsx-runtime
  var require_jsx_runtime = __commonJS({
    "vendor-external:react/jsx-runtime"(exports, module) {
      module.exports = window.ReactJSXRuntime;
    }
  });

  // src/generator/index.tsx
  var import_a11y = __toESM(require_a11y());
  var import_api_fetch3 = __toESM(require_api_fetch());
  var import_components14 = __toESM(require_components());
  var import_commands = __toESM(require_commands());
  var import_data = __toESM(require_data());
  var import_date = __toESM(require_date());
  var import_element11 = __toESM(require_element());
  var import_i18n19 = __toESM(require_i18n());

  // node_modules/@wordpress/icons/build-module/library/calendar.mjs
  var import_primitives = __toESM(require_primitives(), 1);
  var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
  var calendar_default = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.Path, { d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm.5 16c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5V7h15v12zM9 10H7v2h2v-2zm0 4H7v2h2v-2zm4-4h-2v2h2v-2zm4 0h-2v2h2v-2zm-4 4h-2v2h2v-2zm4 0h-2v2h2v-2z" }) });

  // node_modules/@wordpress/icons/build-module/library/chevron-down.mjs
  var import_primitives2 = __toESM(require_primitives(), 1);
  var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
  var chevron_down_default = /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.Path, { d: "M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z" }) });

  // node_modules/@wordpress/icons/build-module/library/chevron-up.mjs
  var import_primitives3 = __toESM(require_primitives(), 1);
  var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
  var chevron_up_default = /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.Path, { d: "M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z" }) });

  // node_modules/@wordpress/icons/build-module/library/close-small.mjs
  var import_primitives4 = __toESM(require_primitives(), 1);
  var import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
  var close_small_default = /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.Path, { d: "M12 13.06l3.712 3.713 1.061-1.06L13.061 12l3.712-3.712-1.06-1.06L12 10.938 8.288 7.227l-1.061 1.06L10.939 12l-3.712 3.712 1.06 1.061L12 13.061z" }) });

  // node_modules/@wordpress/icons/build-module/library/cog.mjs
  var import_primitives5 = __toESM(require_primitives(), 1);
  var import_jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
  var cog_default = /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" }) });

  // node_modules/@wordpress/icons/build-module/library/copy.mjs
  var import_primitives6 = __toESM(require_primitives(), 1);
  var import_jsx_runtime6 = __toESM(require_jsx_runtime(), 1);
  var copy_default = /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_primitives6.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_primitives6.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M5 4.5h11a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V5a.5.5 0 0 1 .5-.5ZM3 5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5Zm17 3v10.75c0 .69-.56 1.25-1.25 1.25H6v1.5h12.75a2.75 2.75 0 0 0 2.75-2.75V8H20Z" }) });

  // node_modules/@wordpress/icons/build-module/library/download.mjs
  var import_primitives7 = __toESM(require_primitives(), 1);
  var import_jsx_runtime7 = __toESM(require_jsx_runtime(), 1);
  var download_default = /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(import_primitives7.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(import_primitives7.Path, { d: "M18 11.3l-1-1.1-4 4V3h-1.5v11.3L7 10.2l-1 1.1 6.2 5.8 5.8-5.8zm.5 3.7v3.5h-13V15H4v5h16v-5h-1.5z" }) });

  // node_modules/@wordpress/icons/build-module/library/help.mjs
  var import_primitives8 = __toESM(require_primitives(), 1);
  var import_jsx_runtime8 = __toESM(require_jsx_runtime(), 1);
  var help_default = /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_primitives8.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_primitives8.Path, { d: "M12 4a8 8 0 1 1 .001 16.001A8 8 0 0 1 12 4Zm0 1.5a6.5 6.5 0 1 0-.001 13.001A6.5 6.5 0 0 0 12 5.5Zm.75 11h-1.5V15h1.5v1.5Zm-.445-9.234a3 3 0 0 1 .445 5.89V14h-1.5v-1.25c0-.57.452-.958.917-1.01A1.5 1.5 0 0 0 12 8.75a1.5 1.5 0 0 0-1.5 1.5H9a3 3 0 0 1 3.305-2.984Z" }) });

  // node_modules/@wordpress/icons/build-module/library/more-vertical.mjs
  var import_primitives9 = __toESM(require_primitives(), 1);
  var import_jsx_runtime9 = __toESM(require_jsx_runtime(), 1);
  var more_vertical_default = /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_primitives9.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(import_primitives9.Path, { d: "M13 19h-2v-2h2v2zm0-6h-2v-2h2v2zm0-6h-2V5h2v2z" }) });

  // node_modules/@wordpress/icons/build-module/library/page.mjs
  var import_primitives10 = __toESM(require_primitives(), 1);
  var import_jsx_runtime10 = __toESM(require_jsx_runtime(), 1);
  var page_default = /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_primitives10.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_primitives10.Path, { d: "M15.5 7.5h-7V9h7V7.5Zm-7 3.5h7v1.5h-7V11Zm7 3.5h-7V16h7v-1.5Z" }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_primitives10.Path, { d: "M17 4H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2ZM7 5.5h10a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-.5.5H7a.5.5 0 0 1-.5-.5V6a.5.5 0 0 1 .5-.5Z" })
  ] });

  // node_modules/@wordpress/icons/build-module/library/plus.mjs
  var import_primitives11 = __toESM(require_primitives(), 1);
  var import_jsx_runtime11 = __toESM(require_jsx_runtime(), 1);
  var plus_default = /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(import_primitives11.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(import_primitives11.Path, { d: "M11 12.5V17.5H12.5V12.5H17.5V11H12.5V6H11V11H6V12.5H11Z" }) });

  // node_modules/@wordpress/icons/build-module/library/trash.mjs
  var import_primitives12 = __toESM(require_primitives(), 1);
  var import_jsx_runtime12 = __toESM(require_jsx_runtime(), 1);
  var trash_default = /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(import_primitives12.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(import_primitives12.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M12 5.5A2.25 2.25 0 0 0 9.878 7h4.244A2.251 2.251 0 0 0 12 5.5ZM12 4a3.751 3.751 0 0 0-3.675 3H5v1.5h1.27l.818 8.997a2.75 2.75 0 0 0 2.739 2.501h4.347a2.75 2.75 0 0 0 2.738-2.5L17.73 8.5H19V7h-3.325A3.751 3.751 0 0 0 12 4Zm4.224 4.5H7.776l.806 8.861a1.25 1.25 0 0 0 1.245 1.137h4.347a1.25 1.25 0 0 0 1.245-1.137l.805-8.861Z" }) });

  // src/generator/picture-field.tsx
  var import_api_fetch2 = __toESM(require_api_fetch());
  var import_components13 = __toESM(require_components());
  var import_element10 = __toESM(require_element());
  var import_i18n18 = __toESM(require_i18n());

  // src/editor/SvgEditor.tsx
  var import_components11 = __toESM(require_components());
  var import_element8 = __toESM(require_element());
  var import_i18n15 = __toESM(require_i18n());

  // src/editor/SvgSource.tsx
  var import_components10 = __toESM(require_components());
  var import_element7 = __toESM(require_element());
  var import_i18n14 = __toESM(require_i18n());

  // src/media-chooser/svg-code.ts
  var import_i18n2 = __toESM(require_i18n());

  // vendor/camaleaun/draw/packages/js/src/geometry.ts
  var UNITS = { pt: 1, px: 1, mm: 2.83465, cm: 28.3465, in: 72 };
  function parseLen(value, total) {
    if (value === void 0 || value === "") {
      return 0;
    }
    if (typeof value === "number") {
      return value;
    }
    let expr = value.trim().toLowerCase();
    const calc = /^calc\((.*)\)$/.exec(expr);
    if (calc) {
      expr = calc[1];
    }
    let sum = 0;
    const re = /([+-]?)\s*(-?\d*\.?\d+)\s*(pt|px|mm|cm|in|%)?/g;
    let m;
    let matched = false;
    while (m = re.exec(expr)) {
      matched = true;
      const n = parseFloat(m[2]) * (m[1] === "-" ? -1 : 1);
      sum += m[3] === "%" ? n * total / 100 : n * (UNITS[m[3] || "pt"] || 1);
    }
    return matched ? sum : 0;
  }
  function refBox(page, ref) {
    return ref === "safe" ? { x: page.safe, y: page.safe, w: page.w - page.safe * 2, h: page.h - page.safe * 2 } : { x: 0, y: 0, w: page.w, h: page.h };
  }
  function resolveAxis(axis, origin, total, forced) {
    const start = parseLen(axis.start, total);
    const end = parseLen(axis.end, total);
    const size = forced !== void 0 ? forced : parseLen(axis.size, total);
    switch (axis.mode) {
      case "end":
        return [origin + total - end - size, size];
      case "center":
        return [origin + (total - size) / 2 + start, size];
      case "stretch":
        return [origin + start, Math.max(1, total - start - end)];
      default:
        return [origin + start, size];
    }
  }
  function resolve(el, page) {
    const layout = el.layout;
    if (!layout || el.type === "line") {
      return el;
    }
    const r = refBox(page, layout.ref);
    let [x, w] = resolveAxis(layout.h, r.x, r.w);
    let [y, h] = resolveAxis(layout.v, r.y, r.h);
    const ratio = lockedRatio(el);
    const side = ratio ? lockedSide(layout) : null;
    if (ratio && side === "w") {
      [x, w] = resolveAxis(layout.h, r.x, r.w, h * ratio);
    } else if (ratio && side === "h") {
      [y, h] = resolveAxis(layout.v, r.y, r.h, w / ratio);
    }
    return { ...el, x, y, w, h };
  }
  function lockedRatio(el) {
    if (el.type === "image") {
      const parts = (el.ratio || "auto").split("/").map(Number);
      return parts.length === 2 && parts[0] > 0 && parts[1] > 0 ? parts[0] / parts[1] : void 0;
    }
    const lock = el.lock;
    return lock && lock > 0 ? lock : void 0;
  }
  function lockedSide(layout) {
    const h = layout.h.mode === "stretch";
    const v = layout.v.mode === "stretch";
    if (h && v) {
      return null;
    }
    return v ? "w" : "h";
  }
  function lenLike(previous, pt, total) {
    const round = (n) => Math.round(n * 100) / 100;
    if (previous && /%\s*$/.test(previous) && !/calc/i.test(previous)) {
      return `${round(pt / total * 100)}%`;
    }
    return `${round(pt)}pt`;
  }
  function axisFrom(axis, pos, size, origin, total) {
    const offset = pos - origin;
    switch (axis.mode) {
      case "end":
        return { ...axis, end: lenLike(axis.end, total - offset - size, total), size: lenLike(axis.size, size, total) };
      case "center":
        return { ...axis, start: lenLike(axis.start, offset - (total - size) / 2, total), size: lenLike(axis.size, size, total) };
      case "stretch":
        return { ...axis, start: lenLike(axis.start, offset, total), end: lenLike(axis.end, total - offset - size, total) };
      default:
        return { ...axis, start: lenLike(axis.start, offset, total), size: lenLike(axis.size, size, total) };
    }
  }
  function layoutFrom(layout, b, page) {
    const r = refBox(page, layout.ref);
    return { ...layout, h: axisFrom(layout.h, b.x, b.w, r.x, r.w), v: axisFrom(layout.v, b.y, b.h, r.y, r.h) };
  }
  function rectPath(x, y, w, h, radius = [], shape2 = "round") {
    const r = [0, 1, 2, 3].map((i) => Math.max(0, Math.min(radius[i] || 0, w / 2, h / 2)));
    const f = (n) => Math.round(n * 100) / 100;
    const corners = [
      { c: [x, y], in: [0, 1], out: [1, 0] },
      // top-left: coming up the left edge, leaving right.
      { c: [x + w, y], in: [-1, 0], out: [0, 1] },
      { c: [x + w, y + h], in: [0, -1], out: [-1, 0] },
      { c: [x, y + h], in: [1, 0], out: [0, -1] }
    ];
    let d = "";
    corners.forEach(({ c, in: din, out }, i) => {
      const rr = r[i];
      const start = [c[0] + din[0] * rr, c[1] + din[1] * rr];
      const end = [c[0] + out[0] * rr, c[1] + out[1] * rr];
      d += (i === 0 ? "M" : "L") + `${f(start[0])} ${f(start[1])}`;
      if (!rr) {
        return;
      }
      switch (shape2) {
        case "scoop":
          d += `A${f(rr)} ${f(rr)} 0 0 0 ${f(end[0])} ${f(end[1])}`;
          break;
        case "bevel":
          d += `L${f(end[0])} ${f(end[1])}`;
          break;
        case "notch": {
          const inner = [start[0] + end[0] - c[0], start[1] + end[1] - c[1]];
          d += `L${f(inner[0])} ${f(inner[1])}L${f(end[0])} ${f(end[1])}`;
          break;
        }
        case "squircle": {
          const k = 0.18;
          const c1 = [c[0] + (start[0] - c[0]) * k, c[1] + (start[1] - c[1]) * k];
          const c2 = [c[0] + (end[0] - c[0]) * k, c[1] + (end[1] - c[1]) * k];
          d += `C${f(c1[0])} ${f(c1[1])} ${f(c2[0])} ${f(c2[1])} ${f(end[0])} ${f(end[1])}`;
          break;
        }
        default:
          d += `A${f(rr)} ${f(rr)} 0 0 1 ${f(end[0])} ${f(end[1])}`;
      }
    });
    return d + "Z";
  }
  var SVG_LIMITS = { bytes: 524288, paths: 50, pathData: 2e4, viewBox: 5e3 };
  function svgCodeAllowed(code) {
    return code.length <= SVG_LIMITS.bytes && !/<!(DOCTYPE|ENTITY)|<\?xml-stylesheet|<\s*script|\son[a-z]+\s*=/i.test(code);
  }
  function isPathData(d) {
    return /^[MmLlHhVvCcSsQqTtAaZz0-9eE.,\s+-]*$/.test(d) && /^\s*[Mm]/.test(d);
  }
  function isFill(value) {
    return /^(none|currentcolor|#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\)|\$[a-z0-9_-]+)$/i.test(value.trim());
  }
  function sanitizeSvg(code) {
    const text2 = code.trim();
    if (!svgCodeAllowed(text2)) {
      return null;
    }
    const doc = new DOMParser().parseFromString(/^<svg[\s>]/i.test(text2) ? text2 : `<svg xmlns="http://www.w3.org/2000/svg">${text2}</svg>`, "image/svg+xml");
    const root2 = doc.documentElement;
    if (!root2 || root2.nodeName.toLowerCase() !== "svg" || doc.querySelector("parsererror")) {
      return null;
    }
    const inherited = (node, name) => {
      for (let n = node; n; n = n.parentElement) {
        if (n.getAttribute(name)) {
          return n.getAttribute(name);
        }
      }
      return null;
    };
    const paths = [];
    for (const node of Array.from(root2.getElementsByTagName("path"))) {
      if (paths.length >= SVG_LIMITS.paths) {
        break;
      }
      const d = (node.getAttribute("d") || "").trim().replace(/\s+/g, " ");
      if (!d || d.length > SVG_LIMITS.pathData || !isPathData(d)) {
        continue;
      }
      const fill = inherited(node, "fill");
      const rule = inherited(node, "fill-rule");
      paths.push({ d, ...fill && isFill(fill) && fill.toLowerCase() !== "currentcolor" ? { fill } : {}, ...rule === "evenodd" ? { rule: "evenodd" } : {} });
    }
    if (!paths.length) {
      return null;
    }
    const box2 = (root2.getAttribute("viewBox") || "").split(/[\s,]+/).map(Number);
    const vw = box2.length === 4 && box2[2] > 0 ? box2[2] : Number(root2.getAttribute("width")) || 100;
    const vh = box2.length === 4 && box2[3] > 0 ? box2[3] : Number(root2.getAttribute("height")) || 100;
    if (!(vw > 0 && vh > 0 && vw <= SVG_LIMITS.viewBox && vh <= SVG_LIMITS.viewBox)) {
      return null;
    }
    const size = (name) => {
      const given = /^\s*([\d.]+)(px)?\s*$/.exec(root2.getAttribute(name) || "");
      return given ? Number(given[1]) : 0;
    };
    const w = size("width");
    const h = size("height");
    const shown2 = w > 0 && h > 0 && w <= SVG_LIMITS.viewBox && h <= SVG_LIMITS.viewBox && (w !== vw || h !== vh);
    return { vw, vh, ...shown2 ? { w, h } : {}, paths };
  }

  // src/editor/svg-draft.ts
  var INFO_ICON = "M5.5 12a6.5 6.5 0 1 1 13 0 6.5 6.5 0 0 1-13 0ZM12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm.75 4v1.5h-1.5V8h1.5Zm0 8v-5h-1.5v5h1.5Z";
  var INFO_VIEWBOX = 24;
  var INFO_SIZE = 96;
  var infoSvg = () => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${INFO_VIEWBOX} ${INFO_VIEWBOX}">
  <path d="${INFO_ICON}"/>
</svg>`;
  var defaultDrawing = () => ({ title: "", vw: INFO_VIEWBOX, vh: INFO_VIEWBOX, w: INFO_SIZE, h: INFO_SIZE, paths: [{ d: INFO_ICON }] });
  var emptiedElement = () => ({ vw: INFO_VIEWBOX, vh: INFO_VIEWBOX, paths: [{ d: INFO_ICON }], markup: void 0, fill: void 0 });
  function refilled(draft, element) {
    if (element) {
      const { vw, vh, paths } = emptiedElement();
      return { ...draft, vw, vh, paths };
    }
    return { ...defaultDrawing(), title: draft.title };
  }
  var taken = (pasted, base, element) => element ? { ...pasted, title: base.title, w: base.w, h: base.h } : pasted;
  function inkOn(color2) {
    const c = String(color2 || "").trim().toLowerCase();
    let rgb = null;
    const hex = /^#([0-9a-f]{3,8})$/.exec(c);
    if (hex) {
      const h = hex[1];
      if (h.length === 3 || h.length === 4) {
        rgb = [0, 1, 2].map((i) => parseInt(h[i] + h[i], 16));
      } else if (h.length === 6 || h.length === 8) {
        rgb = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
      }
    }
    const fn = /^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)/.exec(c);
    if (!rgb && fn) {
      rgb = [Number(fn[1]), Number(fn[2]), Number(fn[3])];
    }
    if (!rgb || rgb.some((n) => Number.isNaN(n))) {
      return "#fff";
    }
    const [r, g, b] = rgb.map((n) => {
      const s = n / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.4 ? "#1e1e1e" : "#fff";
  }

  // src/editor/model.ts
  var import_i18n = __toESM(require_i18n());
  var resolve2 = (el, page) => resolve(el, page);
  function box(el) {
    if (el.type === "line") {
      const x = Math.min(el.x1, el.x2);
      const y = Math.min(el.y1, el.y2);
      return { x, y, w: Math.abs(el.x2 - el.x1), h: Math.abs(el.y2 - el.y1) };
    }
    return { x: el.x, y: el.y, w: el.w, h: el.h };
  }
  function colorOf(v, mode) {
    return mode === "dark" && v.dark ? v.dark : v.light;
  }
  function builtinColor(key, mode) {
    const dark = mode === "dark";
    switch (key) {
      case "text":
      case "muted":
      case "line":
        return dark ? "#ffffff" : "#000000";
      case "background":
        return "transparent";
      case "primary":
        return "#3858e9";
    }
    return "";
  }
  function colorGroups(design) {
    const keys = Object.keys(design.colors).filter((k) => design.colors[k].light && design.colors[k].light !== "none");
    return keys.length ? [{ name: "elements", keys }] : [];
  }
  function isWhite(value) {
    const v = (value || "").toLowerCase().replace(/\s+/g, "");
    return /^#(f{3,4}|f{6}|f{8})$/.test(v) || v === "white" || v === "rgb(255,255,255)" || v === "rgba(255,255,255,1)";
  }
  function color(design, value, mode, depth = 0) {
    if (!value) {
      return "none";
    }
    if (value.startsWith("$")) {
      const key = value.slice(1);
      const v = design.colors[key];
      if (v) {
        const own = colorOf(v, mode);
        if (own.startsWith("$")) {
          return depth < 5 ? color(design, own, mode, depth + 1) : "none";
        }
        return own || "none";
      }
      const swatch = (design.palette || []).find((s) => s.slug === key);
      return swatch ? swatch.color : builtinColor(key, mode) || "none";
    }
    return value;
  }
  function colorIn(design, v, mode) {
    return color(design, colorOf(v, mode), mode);
  }
  var REQUIRED_SLOTS = [];
  function parseText(text2) {
    const runs = [];
    const parts = text2.split(/(\*\*.+?\*\*)/);
    for (const part of parts) {
      const bold = /^\*\*(.+)\*\*$/.exec(part);
      const body = bold ? bold[1] : part;
      for (const piece of body.split(/(\{[a-z_]+\})/)) {
        if (!piece) {
          continue;
        }
        const field2 = /^\{([a-z_]+)\}$/.exec(piece);
        const run = field2 ? { field: field2[1] } : { text: piece };
        if (bold) {
          run.b = true;
        }
        runs.push(run);
      }
    }
    return runs;
  }
  function runsOf(el) {
    return el.runs || parseText(el.text || "");
  }
  function runsIn(el, locale) {
    const variant = (el.variants || {})[locale.replace("-", "_")];
    return variant && variant.length ? variant : runsOf(el);
  }
  function svgPaths(el) {
    if (el.paths) {
      return el.paths;
    }
    const parsed = el.markup ? sanitizeSvg(el.markup) : null;
    return ((parsed == null ? void 0 : parsed.paths) || []).map((p) => el.fill ? { ...p, fill: el.fill } : p);
  }
  function pageBg(page, mode) {
    var _a;
    return typeof page.bg === "string" ? page.bg : ((_a = page.bg) == null ? void 0 : _a[mode]) || "";
  }

  // src/media-chooser/svg-code.ts
  var bareSvg = (text2) => text2.replace(/<\?xml[^>]*\?>/gi, "").replace(/<!--[\s\S]*?-->/g, "").trim();
  var SVG_EXAMPLE = infoSvg();
  function problemText(problem) {
    switch (problem) {
      case "not-svg":
        return (0, import_i18n2.__)("That is not SVG code: it should start with <svg>.", "events-certificates");
      case "forbidden":
        return (0, import_i18n2.__)("That SVG has parts that are not allowed (a script, an event handler, a DOCTYPE or an entity).", "events-certificates");
      case "too-big":
        return (0, import_i18n2.__)("That SVG is too big.", "events-certificates");
      case "no-paths":
        return (0, import_i18n2.__)("That SVG has no paths: only its <path> elements are read, so shapes and text must be converted to paths first.", "events-certificates");
      default:
        return "";
    }
  }
  function parseSvgText(text2, title = "") {
    const code = bareSvg(text2);
    if (!code) {
      return { problem: "empty" };
    }
    if (!/^<svg[\s>]/i.test(code)) {
      return { problem: "not-svg" };
    }
    if (code.length > SVG_LIMITS.bytes) {
      return { problem: "too-big" };
    }
    if (!svgCodeAllowed(code)) {
      return { problem: "forbidden" };
    }
    const svg = sanitizeSvg(code);
    return svg ? { draft: { title, ...svg } } : { problem: "no-paths" };
  }
  function offerFor(clip, handled) {
    const code = clip ? bareSvg(clip) : "";
    return code && code !== handled && "draft" in parseSvgText(code) ? code : null;
  }

  // src/editor/SvgFields.tsx
  var import_element6 = __toESM(require_element());
  var import_i18n13 = __toESM(require_i18n());

  // src/editor/SizeRow.tsx
  var import_components9 = __toESM(require_components());
  var import_i18n12 = __toESM(require_i18n());

  // src/editor/DesignPanel.tsx
  var import_components8 = __toESM(require_components());
  var import_i18n11 = __toESM(require_i18n());

  // src/editor/ColorsSection.tsx
  var import_components = __toESM(require_components());
  var import_element = __toESM(require_element());
  var import_i18n4 = __toESM(require_i18n());

  // src/editor/base.ts
  var import_i18n3 = __toESM(require_i18n());
  var KEPT_SLOTS = Array.from(new Set(REQUIRED_SLOTS));

  // src/editor/ColorsSection.tsx
  var import_jsx_runtime13 = __toESM(require_jsx_runtime());

  // src/editor/Inspector.tsx
  var import_components7 = __toESM(require_components());
  var import_element5 = __toESM(require_element());
  var import_i18n10 = __toESM(require_i18n());

  // src/editor/icons.tsx
  var import_components2 = __toESM(require_components());
  var import_jsx_runtime14 = __toESM(require_jsx_runtime());
  var stroke = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" };
  var solid = { fill: "currentColor" };
  var icon = (...children) => /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", children });
  var text = icon(/* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M5.5 6.75h13M12 6.75v10.5M9.5 17.25h5", ...stroke }, "a"));
  var line = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M6.5 17.5l11-11", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Circle, { cx: "5.5", cy: "18.5", r: "1.75", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Circle, { cx: "18.5", cy: "5.5", r: "1.75", ...solid }, "c")
  );
  var rect = icon(/* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "4.75", y: "6.75", width: "14.5", height: "10.5", rx: "1.5", ...stroke }, "a"));
  var ellipse = icon(/* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M4.75 12a7.25 5.25 0 1 0 14.5 0 7.25 5.25 0 1 0-14.5 0z", ...stroke }, "a"));
  var shape = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M6 16.5c0-6.5 5.5-9 12-9", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "3.75", y: "15", width: "3", height: "3", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "17.25", y: "6", width: "3", height: "3", ...solid }, "c")
  );
  var picture = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "4.75", y: "5.75", width: "14.5", height: "12.5", rx: "1.5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M5.5 16.5l3.75-4.25 2.75 2.75 2-2 4.5 4", ...stroke }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Circle, { cx: "15.25", cy: "9.75", r: "1.25", ...solid }, "c")
  );
  var drawing = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M7.5 7L2.75 12l4.75 5M16.5 7l4.75 5-4.75 5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M12 8.25l3 3.75-3 3.75L9 12z", ...solid }, "b")
  );
  var signature = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M4 19.25h16", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M4.5 15c1.6-3.4 2.9-8.5 4.2-8.5.9 0 .3 3.7-.2 6.2-.3 1.5.4 1.6 1.2.4 1-1.5 1.8-3.4 2.9-3.4.8 0 .1 2.3.9 2.3 1.2 0 1.8-1.9 3.3-1.9 1 0 .6 1.5 1.5 1.5.9 0 1.5-1 2.2-1.6", ...stroke }, "b")
  );
  var qr = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "4.75", y: "4.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "13.75", y: "4.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "4.75", y: "13.75", width: "5.5", height: "5.5", rx: ".75", ...stroke }, "c"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M7 7h1.25v1.25H7zM16 7h1.25v1.25H16zM7 16h1.25v1.25H7zM13.75 13.75H16v2.25h-2.25zM17.5 13.75h1.75V15.5H17.5zM13.75 17.5h1.75v1.75h-1.75zM17.25 17.25h2v2h-2z", ...solid }, "d")
  );
  var verification = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Rect, { x: "4.75", y: "6.75", width: "6.5", height: "6.5", rx: ".75", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M7.25 9.25h1.5v1.5h-1.5z", ...solid }, "b"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M14 8h5.25M14 12h5.25M4.75 17h14.5", ...stroke }, "c")
  );
  var logo = icon(
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Circle, { cx: "12", cy: "9.5", r: "5", ...stroke }, "a"),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(import_components2.Path, { d: "M9 13.75l-1.75 5.5 4.75-2 4.75 2-1.75-5.5", ...stroke }, "b")
  );

  // src/editor/media.ts
  var import_api_fetch = __toESM(require_api_fetch());
  var import_i18n5 = __toESM(require_i18n());

  // src/editor/SvgPanel.tsx
  var import_components4 = __toESM(require_components());
  var import_element2 = __toESM(require_element());
  var import_i18n7 = __toESM(require_i18n());

  // src/editor/SvgGroups.tsx
  var import_components3 = __toESM(require_components());
  var import_i18n6 = __toESM(require_i18n());
  var import_jsx_runtime15 = __toESM(require_jsx_runtime());
  function ViewBoxRow({ vw, vh, onChange }) {
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(DropdownRow, { label: (0, import_i18n6.__)("ViewBox", "events-certificates"), value: `${vw} \xD7 ${vh}`, children: () => /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)(import_components3.__experimentalHStack, { alignment: "top", children: [
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(import_components3.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n6.__)("Width", "events-certificates"), min: 1, value: vw, onChange: (v) => Number(v) > 0 && onChange({ vw: Number(v) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(import_components3.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n6.__)("Height", "events-certificates"), min: 1, value: vh, onChange: (v) => Number(v) > 0 && onChange({ vh: Number(v) }) })
    ] }) });
  }
  function SvgGroups({ viewBox, size, paths }) {
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "evcert-svg-panel", children: [
      /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("div", { className: "evcert-inspector__section", children: [
        viewBox,
        size
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("div", { className: "evcert-inspector__section", children: paths })
    ] });
  }

  // src/editor/SvgPanel.tsx
  var import_jsx_runtime16 = __toESM(require_jsx_runtime());
  var TRANSPARENT = "#ffffff00";
  function FillSwatch({ value, current, design, mode, onChange }) {
    const variable = (value == null ? void 0 : value.startsWith("$")) ? design.colors[value.slice(1)] : null;
    const shown2 = value ? color(design, value, mode) : color(design, current, mode);
    const palette = Object.entries(design.colors).map(([slug, v]) => ({ slug, name: v.name, color: colorIn(design, v, mode) === "transparent" ? TRANSPARENT : colorIn(design, v, mode) }));
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
      import_components4.Dropdown,
      {
        popoverProps: { placement: "left-start", offset: 36, shift: true, className: "evcert-colors__popover-wrap" },
        renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
          import_components4.Button,
          {
            className: "evcert-svg-path__swatch",
            onClick: onToggle,
            "aria-expanded": isOpen,
            label: (0, import_i18n7.sprintf)(
              /* translators: %s: color name. */
              (0, import_i18n7.__)("Fill: %s", "events-certificates"),
              value ? (variable == null ? void 0 : variable.name) || value : (0, import_i18n7.__)("Current color", "events-certificates")
            ),
            showTooltip: true,
            children: value ? /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.ColorIndicator, { colorValue: shown2 === "none" ? void 0 : shown2 }) : (
              // The current color is a circle in that color cut across by a stroke that shows on it: as the "no color" of the palette,
              // which is an empty circle with a slash (the style of .is-current has it).
              /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.ColorIndicator, { colorValue: "", className: "is-current", style: { "--evcert-fill": shown2 === "none" ? "#fff" : shown2, "--evcert-ink": shown2 === "none" ? "#949494" : inkOn(shown2) } })
            )
          }
        ),
        renderContent: () => /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "evcert-color-popover", children: [
          colorGroups(design).map((group) => {
            var _a;
            return /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { children: [
              /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("p", { className: "evcert-color-popover__label", children: (0, import_i18n7.__)("Elements", "events-certificates") }),
              /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
                import_components4.ColorPalette,
                {
                  colors: group.keys.map((key) => palette.find((c) => c.slug === key)),
                  value: variable ? (_a = group.keys.map((key) => palette.find((c) => c.slug === key)).find((c) => `$${c == null ? void 0 : c.slug}` === value)) == null ? void 0 : _a.color : void 0,
                  disableCustomColors: true,
                  clearable: false,
                  onChange: (picked, index) => {
                    const key = index === void 0 ? void 0 : group.keys[index];
                    onChange(key ? `$${key}` : picked || void 0);
                  }
                }
              )
            ] }, group.name);
          }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("p", { className: "evcert-color-popover__label", children: (0, import_i18n7.__)("Custom", "events-certificates") }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.ColorPalette, { value: value && !variable ? value : void 0, clearable: false, onChange: (c) => onChange(c || void 0) }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { className: "evcert-color-popover__footer", children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.Button, { variant: "tertiary", size: "small", disabled: !value, accessibleWhenDisabled: true, onClick: () => onChange(void 0), children: (0, import_i18n7.__)("Clear", "events-certificates") }) })
        ] })
      }
    );
  }
  function PathData({ index, value, multiline, onChange, onImport, onFocus }) {
    const [text2, setText] = (0, import_element2.useState)(value);
    const valid = !text2 || isPathData(text2);
    const props = {
      __nextHasNoMarginBottom: true,
      className: `evcert-svg-path__d${valid ? "" : " is-invalid"}`,
      label: (0, import_i18n7.sprintf)(
        /* translators: %d: path number. */
        (0, import_i18n7.__)("Path %d data (d)", "events-certificates"),
        index + 1
      ),
      hideLabelFromVision: !multiline,
      placeholder: "M0 0h24v24H0z",
      value: text2,
      onFocus,
      onPaste: (event) => {
        const pasted = event.clipboardData.getData("text/plain");
        const svg = /^\s*</.test(pasted) ? sanitizeSvg(pasted) : null;
        if (svg) {
          event.preventDefault();
          onImport(svg);
        }
      },
      onChange: (d) => {
        setText(d);
        if (isPathData(d)) {
          onChange(d.trim());
        }
      }
    };
    return multiline ? /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.TextareaControl, { ...props, rows: 3, help: valid ? void 0 : (0, import_i18n7.__)("Only path commands and numbers, starting with M.", "events-certificates") }) : /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.TextControl, { __next40pxDefaultSize: true, ...props });
  }
  var short = (d) => d.length > 28 ? `${d.slice(0, 28).trim()}\u2026` : d;
  function PathList({ paths, current, design, mode, onPaths, onImport, onFocus, onEmpty, placement = "left-start" }) {
    const [version, setVersion] = (0, import_element2.useState)(0);
    const replace = (next) => {
      onPaths(next);
      setVersion(version + 1);
    };
    const setPath = (i, patch) => onPaths(paths.map((p, j) => j === i ? { ...p, ...patch } : p));
    const move = (i, to) => {
      const next = [...paths];
      const [p] = next.splice(i, 1);
      next.splice(to, 0, p);
      replace(next);
    };
    const remove = (i) => {
      const next = paths.filter((_, j) => j !== i);
      if (onEmpty && !next.some((p) => p.d)) {
        onEmpty();
        setVersion(version + 1);
        return;
      }
      replace(next);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_jsx_runtime16.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_components4.__experimentalHStack, { className: "evcert-svg-panel__header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("h2", { className: "evcert-section-heading", children: (0, import_i18n7.__)("Paths", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.Button, { className: "evcert-appender", icon: plus_default, label: (0, import_i18n7.__)("Add path", "events-certificates"), onClick: () => replace([...paths, { d: "" }]) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.__experimentalItemGroup, { isBordered: true, isSeparated: true, className: "evcert-svg-paths", children: paths.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.__experimentalItem, { className: "evcert-svg-path", onMouseEnter: () => onFocus == null ? void 0 : onFocus(i), onMouseLeave: () => onFocus == null ? void 0 : onFocus(null), children: /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_components4.__experimentalHStack, { spacing: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(FillSwatch, { value: p.fill, current, design, mode, onChange: (fill) => setPath(i, { fill }) }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
          import_components4.Dropdown,
          {
            className: "evcert-svg-path__link",
            popoverProps: { placement, offset: placement === "left-start" ? 36 : 8, shift: true },
            onToggle: (open) => onFocus == null ? void 0 : onFocus(open ? i : null),
            renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.Button, { variant: "link", className: "evcert-svg-path__d-link", onClick: onToggle, "aria-expanded": isOpen, title: p.d, children: p.d ? short(p.d) : (0, import_i18n7.__)("Add path data", "events-certificates") }),
            renderContent: () => /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { className: "evcert-svg-path__popover", children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(PathData, { multiline: true, index: i, value: p.d, onChange: (d) => setPath(i, { d }), onImport }) })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "evcert-mover evcert-mover--inline", children: [
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.Button, { size: "small", icon: chevron_up_default, label: (0, import_i18n7.__)("Move up", "events-certificates"), disabled: i === 0, accessibleWhenDisabled: true, onClick: () => move(i, i - 1) }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.Button, { size: "small", icon: chevron_down_default, label: (0, import_i18n7.__)("Move down", "events-certificates"), disabled: i === paths.length - 1, accessibleWhenDisabled: true, onClick: () => move(i, i + 1) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.DropdownMenu, { icon: more_vertical_default, label: (0, import_i18n7.__)("Path options", "events-certificates"), toggleProps: { size: "small" }, popoverProps: { placement: "bottom-end" }, children: ({ onClose }) => /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_jsx_runtime16.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(import_components4.MenuGroup, { children: [
            /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.MenuItem, { onClick: () => {
              move(i, 0);
              onClose();
            }, disabled: i === 0, children: (0, import_i18n7.__)("Move to bottom (behind)", "events-certificates") }),
            /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.MenuItem, { onClick: () => {
              move(i, paths.length - 1);
              onClose();
            }, disabled: i === paths.length - 1, children: (0, import_i18n7.__)("Move to top (in front)", "events-certificates") }),
            /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.MenuItem, { icon: copy_default, onClick: () => {
              replace([...paths.slice(0, i + 1), { ...p }, ...paths.slice(i + 1)]);
              onClose();
            }, children: (0, import_i18n7.__)("Duplicate", "events-certificates") })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.MenuGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(import_components4.MenuItem, { icon: trash_default, disabled: paths.length === 1 && !onEmpty, onClick: () => {
            remove(i);
            onClose();
          }, children: (0, import_i18n7.__)("Delete", "events-certificates") }) })
        ] }) })
      ] }) }, `${version}-${i}`)) })
    ] });
  }

  // src/editor/FieldText.tsx
  var import_components5 = __toESM(require_components());
  var import_element3 = __toESM(require_element());
  var import_i18n8 = __toESM(require_i18n());
  var import_jsx_runtime17 = __toESM(require_jsx_runtime());

  // src/editor/TextByLanguage.tsx
  var import_components6 = __toESM(require_components());
  var import_element4 = __toESM(require_element());
  var import_i18n9 = __toESM(require_i18n());
  var import_jsx_runtime18 = __toESM(require_jsx_runtime());

  // src/editor/Inspector.tsx
  var import_jsx_runtime19 = __toESM(require_jsx_runtime());
  var FONT_SIZES = [8, 10, 12, 14, 16, 18, 24, 32, 42].map((size) => ({ name: `${size} pt`, slug: String(size), size }));

  // src/editor/DesignPanel.tsx
  var import_jsx_runtime20 = __toESM(require_jsx_runtime());
  function Row({ label, children }) {
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(import_components8.__experimentalHStack, { className: "evcert-panel-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("div", { className: "evcert-panel-row__label", children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("div", { className: "evcert-panel-row__control", children })
    ] });
  }
  function DropdownRow({ label, value, children, plain = false }) {
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(Row, { label, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(
      import_components8.Dropdown,
      {
        popoverProps: { placement: "left-start", offset: 36, shift: true, ...plain ? { className: "evcert-colors__popover-wrap" } : {} },
        renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(import_components8.Button, { size: "compact", variant: "tertiary", onClick: onToggle, "aria-expanded": isOpen, children: value }),
        renderContent: ({ onClose }) => plain ? /* @__PURE__ */ (0, import_jsx_runtime20.jsx)(import_jsx_runtime20.Fragment, { children: children(onClose) }) : /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("div", { className: "evcert-row-popover", children: children(onClose) })
      }
    ) });
  }

  // src/editor/size.ts
  var round2 = (n) => Math.round(n * 100) / 100;
  var shown = round2;
  function sizePatch(el, w, h, page) {
    if (!w || !h || round2(el.w) === w && round2(el.h) === h) {
      return {};
    }
    return { w, h, ...el.layout ? { layout: layoutFrom(el.layout, { x: el.x, y: el.y, w, h }, page) } : {} };
  }

  // src/editor/SizeRow.tsx
  var import_jsx_runtime21 = __toESM(require_jsx_runtime());
  function SizeRow({ w, h, placeholder, disabled, onChange, note }) {
    return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(DropdownRow, { label: (0, import_i18n12.__)("Size", "events-certificates"), value: w && h ? `${w} \xD7 ${h}` : "- \xD7 -", children: () => /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_jsx_runtime21.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)(import_components9.__experimentalHStack, { alignment: "top", children: [
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(import_components9.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n12.__)("Width", "events-certificates"), min: 1, disabled: disabled == null ? void 0 : disabled.w, placeholder: placeholder ? String(placeholder[0]) : void 0, value: w != null ? w : "", onChange: (v) => onChange("w", v) }),
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(import_components9.__experimentalNumberControl, { __next40pxDefaultSize: true, label: (0, import_i18n12.__)("Height", "events-certificates"), min: 1, disabled: disabled == null ? void 0 : disabled.h, placeholder: placeholder ? String(placeholder[1]) : void 0, value: h != null ? h : "", onChange: (v) => onChange("h", v) })
      ] }),
      note && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("p", { className: "description", children: note })
    ] }) });
  }

  // src/editor/SvgFields.tsx
  var import_jsx_runtime22 = __toESM(require_jsx_runtime());
  function sized(draft, side, raw, element) {
    const value = Number(raw);
    if (!(value > 0)) {
      return element ? draft : { ...draft, w: void 0, h: void 0 };
    }
    const ratio = draft.vw / draft.vh;
    const other = "w" === side ? Math.round(value / ratio * 100) / 100 : Math.round(value * ratio * 100) / 100;
    const next = { ...draft, [side]: value };
    const opposite = "w" === side ? "h" : "w";
    return next[opposite] ? next : { ...next, [opposite]: other };
  }
  function SvgFields({ draft, onChange, design, mode, current = "$text", element, before }) {
    const [focus, setFocus] = (0, import_element6.useState)(null);
    const { title, vw, vh, paths } = draft;
    return /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "evcert-svg-editor__body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("div", { className: "evcert-svg-editor__preview", children: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("svg", { viewBox: `0 0 ${vw} ${vh}`, role: "img", "aria-label": title.trim() || (0, import_i18n13.__)("Preview", "events-certificates"), style: { "--evcert-ratio": vw / vh }, children: paths.map(
        (p, i) => p.d ? /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("path", { d: p.d, fill: color(design, p.fill || current, mode), fillRule: p.rule, opacity: focus === null || focus === i ? 1 : 0.25 }, i) : null
      ) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime22.jsxs)("div", { className: "evcert-svg-editor__fields", children: [
        before,
        /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(
          SvgGroups,
          {
            viewBox: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(ViewBoxRow, { vw, vh, onChange: (patch) => onChange({ ...draft, ...patch }) }),
            size: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(
              SizeRow,
              {
                w: draft.w,
                h: draft.h,
                placeholder: [vw, vh],
                onChange: (side, value) => onChange(sized(draft, side, value, element)),
                note: element ? void 0 : (0, import_i18n13.__)("The size to show it at, e.g. an icon of 24 \xD7 24 shown at 512 \xD7 512. Empty, it is the viewBox\u2019s; the certificate fits it in its place with this proportion.", "events-certificates")
              }
            ),
            paths: /* @__PURE__ */ (0, import_jsx_runtime22.jsx)(PathList, { paths, current, design, mode, onPaths: (next) => onChange({ ...draft, paths: next }), onFocus: setFocus, onEmpty: () => {
              setFocus(null);
              onChange(refilled(draft, element));
            }, onImport: (svg) => onChange({ ...draft, vw: svg.vw, vh: svg.vh, w: element ? draft.w : svg.w, h: element ? draft.h : svg.h, paths: svg.paths }) })
          }
        )
      ] })
    ] });
  }

  // src/editor/SvgSource.tsx
  var import_jsx_runtime23 = __toESM(require_jsx_runtime());
  var isSvgFile = (file) => /^image\/svg/i.test(file.type) || /\.svg$/i.test(file.name);
  function SvgSource({ draft, onChange, design, mode, current, element, base, dropFiles }) {
    const [text2, setText] = (0, import_element7.useState)("");
    const [problem, setProblem] = (0, import_element7.useState)("");
    const has = !!draft;
    (0, import_element7.useEffect)(() => {
      if (has) {
        setText("");
        setProblem("");
      }
    }, [has]);
    const take = (value, say, title = "") => {
      const parsed = parseSvgText(value, title);
      if ("draft" in parsed) {
        onChange(taken(parsed.draft, base, element));
        return true;
      }
      setProblem(say ? problemText(parsed.problem) : "");
      return false;
    };
    if (draft) {
      return /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(
        SvgFields,
        {
          draft,
          onChange,
          design,
          mode,
          current,
          element,
          before: /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "evcert-svg-tab__again", children: /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(import_components10.Button, { variant: "tertiary", size: "compact", onClick: () => onChange(null), children: (0, import_i18n14.__)("Paste another SVG", "events-certificates") }) })
        }
      );
    }
    return /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "evcert-svg-editor__body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "evcert-svg-editor__preview", children: /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("svg", { viewBox: "0 0 120 44", role: "img", "aria-label": (0, import_i18n14.__)("Preview", "events-certificates"), style: { "--evcert-ratio": 120 / 44 } }) }),
      /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "evcert-svg-editor__fields evcert-svg-code", children: [
        /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(
          import_components10.TextareaControl,
          {
            __nextHasNoMarginBottom: true,
            label: (0, import_i18n14.__)("SVG code", "events-certificates"),
            help: (0, import_i18n14.__)("Paste the code of an SVG here, or drop an .svg file on this window.", "events-certificates"),
            placeholder: SVG_EXAMPLE,
            rows: 12,
            value: text2,
            spellCheck: false,
            onChange: (value) => {
              setText(value);
              take(value, false);
            },
            onPaste: (event) => {
              if (take(event.clipboardData.getData("text"), false)) {
                event.preventDefault();
              } else {
                setProblem(problemText(parseSvgText(event.clipboardData.getData("text")).problem));
              }
            },
            onBlur: () => text2.trim() && take(text2, true)
          }
        ),
        problem && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("p", { className: "evcert-svg-code__problem", role: "alert", children: problem })
      ] }),
      dropFiles && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(
        import_components10.DropZone,
        {
          label: (0, import_i18n14.__)("Drop an .svg file to read its paths", "events-certificates"),
          onFilesDrop: (files) => {
            const file = files.find(isSvgFile);
            if (file) {
              file.text().then((value) => take(value, true, file.name.replace(/\.svg$/i, "")));
            }
          }
        }
      )
    ] });
  }

  // src/editor/SvgEditor.tsx
  var import_jsx_runtime24 = __toESM(require_jsx_runtime());
  function SvgEditor({ el, design, mode, onApply, onClose, preferred, onApplyDrawing }) {
    const [base] = (0, import_element8.useState)(() => ({ title: el.title || "", vw: el.vw, vh: el.vh, ...onApplyDrawing ? (preferred == null ? void 0 : preferred.w) && (preferred == null ? void 0 : preferred.h) ? preferred : {} : { w: shown(el.w), h: shown(el.h) }, paths: svgPaths(el) }));
    const [draft, setDraft] = (0, import_element8.useState)(base.paths.some((p) => p.d) ? base : null);
    const usable = ((draft == null ? void 0 : draft.paths) || []).filter((p) => p.d);
    const title = (draft == null ? void 0 : draft.title) || "";
    return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)(import_components11.Modal, { title: title.trim() ? (0, import_i18n15.sprintf)(
      /* translators: %s: title of the SVG. */
      (0, import_i18n15.__)("Edit SVG: %s", "events-certificates"),
      title.trim()
    ) : (0, import_i18n15.__)("Edit SVG", "events-certificates"), size: "large", onRequestClose: onClose, className: "evcert-svg-editor", overlayClassName: "evcert-svg-editor-overlay", children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(SvgSource, { draft, onChange: setDraft, design, mode, current: el.color || "$text", element: !onApplyDrawing, base, dropFiles: true }),
      /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "evcert-actions evcert-svg-editor__footer", children: [
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(import_components11.Button, { variant: "tertiary", __next40pxDefaultSize: true, onClick: onClose, children: (0, import_i18n15.__)("Cancel", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(
          import_components11.Button,
          {
            variant: "primary",
            __next40pxDefaultSize: true,
            disabled: !usable.length,
            accessibleWhenDisabled: true,
            onClick: () => {
              if (!draft) {
                return;
              }
              if (onApplyDrawing) {
                onApplyDrawing({ ...draft, paths: usable });
              } else {
                onApply({ title: draft.title.trim() || void 0, vw: draft.vw, vh: draft.vh, paths: usable, markup: void 0, fill: void 0, ...sizePatch(el, draft.w, draft.h, design.page) });
              }
              onClose();
            },
            children: (0, import_i18n15.__)("Apply", "events-certificates")
          }
        )
      ] })
    ] });
  }

  // src/media-chooser/index.tsx
  var import_components12 = __toESM(require_components());
  var import_element9 = __toESM(require_element());
  var import_i18n17 = __toESM(require_i18n());

  // src/media-chooser/shared.ts
  var import_i18n16 = __toESM(require_i18n());
  var PATH_DESIGN = { page: { w: 120, h: 44, bg: "transparent", safe: 0, bleed: 0 }, colors: { text: { name: (0, import_i18n16.__)("Text", "events-certificates"), light: "#1e1e1e", dark: "#f0f0f0" } }, elements: [] };
  var drawingJson = (draft, paths) => JSON.stringify({ vw: draft.vw, vh: draft.vh, ...draft.w && draft.h ? { w: draft.w, h: draft.h } : {}, paths });
  var readVector = (json) => {
    try {
      const parsed = JSON.parse(json);
      return parsed && parsed.vw > 0 && parsed.vh > 0 && Array.isArray(parsed.paths) ? parsed : { vw: 120, vh: 44, paths: [] };
    } catch (e) {
      return { vw: 120, vh: 44, paths: [] };
    }
  };

  // src/media-chooser/index.tsx
  var import_jsx_runtime25 = __toESM(require_jsx_runtime());
  var hasMedia = () => {
    var _a;
    return !!((_a = window.wp) == null ? void 0 : _a.media);
  };
  async function svgFile(file) {
    const parsed = parseSvgText(await file.text(), file.name.replace(/\.svg$/i, ""));
    return "draft" in parsed ? parsed.draft : null;
  }
  var isSvgFile2 = (file) => /^image\/svg/i.test(file.type) || /\.svg$/i.test(file.name);
  async function readClipboard() {
    var _a;
    const read = () => navigator.clipboard.readText().catch(() => null);
    return (_a = await read()) != null ? _a : await new Promise((resolve3) => window.setTimeout(() => read().then(resolve3), 150));
  }
  var OFFER_MS = 9e3;
  var ERROR_MS = 6e3;
  var LEAVE_MS = 200;
  function ClipboardToast({ onPaste, modal }) {
    const [toast, setToast] = (0, import_element9.useState)(null);
    const [leaving, setLeaving] = (0, import_element9.useState)(false);
    const [paused, setPaused] = (0, import_element9.useState)(false);
    const handled = (0, import_element9.useRef)("");
    const current = (0, import_element9.useRef)(null);
    const busy = (0, import_element9.useRef)(false);
    const when = (0, import_element9.useRef)(0);
    const show = (0, import_element9.useCallback)((next) => {
      current.current = next;
      setLeaving(false);
      setToast(next);
    }, []);
    const dismiss = (0, import_element9.useCallback)(() => {
      const gone = current.current;
      if (!gone) {
        return;
      }
      if (gone.kind === "offer") {
        handled.current = gone.text;
      }
      current.current = null;
      setLeaving(true);
      window.setTimeout(() => {
        if (!current.current) {
          setToast(null);
          setLeaving(false);
        }
      }, LEAVE_MS);
    }, []);
    const check = (0, import_element9.useCallback)(async () => {
      var _a, _b;
      if (busy.current) {
        return;
      }
      busy.current = true;
      const clip = await readClipboard();
      busy.current = false;
      if (clip === null) {
        return;
      }
      const code = offerFor(clip, handled.current);
      if (code && ((_a = current.current) == null ? void 0 : _a.text) !== code) {
        show({ kind: "offer", text: code });
      } else if (!code && ((_b = current.current) == null ? void 0 : _b.kind) === "offer") {
        dismiss();
      }
    }, [show, dismiss]);
    (0, import_element9.useEffect)(() => {
      const again = () => {
        if (Date.now() - when.current > 1e3) {
          when.current = Date.now();
          check();
        }
      };
      const visible = () => document.visibilityState === "visible" && again();
      const problem = (event) => show({ kind: "error", text: event.detail });
      check();
      window.addEventListener("focus", again);
      document.addEventListener("visibilitychange", visible);
      window.addEventListener("evcert:svg-problem", problem);
      modal == null ? void 0 : modal.addEventListener("pointerenter", again);
      return () => {
        window.removeEventListener("focus", again);
        document.removeEventListener("visibilitychange", visible);
        window.removeEventListener("evcert:svg-problem", problem);
        modal == null ? void 0 : modal.removeEventListener("pointerenter", again);
      };
    }, [check, show, modal]);
    (0, import_element9.useEffect)(() => {
      if (!toast || leaving || paused) {
        return void 0;
      }
      const timer = window.setTimeout(dismiss, toast.kind === "error" ? ERROR_MS : OFFER_MS);
      return () => window.clearTimeout(timer);
    }, [toast, leaving, paused, dismiss]);
    if (!toast) {
      return null;
    }
    const hold = { onMouseEnter: () => setPaused(true), onMouseLeave: () => setPaused(false), onFocus: () => setPaused(true), onBlur: () => setPaused(false) };
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: `evcert-toast${toast.kind === "error" ? " is-error" : ""}${leaving ? " is-leaving" : ""}`, role: toast.kind === "error" ? "alert" : "status", ...hold, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { children: toast.kind === "error" ? toast.text : (0, import_i18n17.__)("You have an SVG copied. Paste it as the signature?", "events-certificates") }),
      toast.kind === "offer" && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(
        "button",
        {
          type: "button",
          className: "button-link",
          onClick: () => {
            const parsed = parseSvgText(toast.text);
            if ("draft" in parsed) {
              onPaste(parsed.draft);
            }
            dismiss();
          },
          children: (0, import_i18n17.__)("Paste", "events-certificates")
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: "evcert-toast__close", "aria-label": (0, import_i18n17.__)("Close", "events-certificates"), onClick: dismiss, children: "\xD7" })
    ] });
  }
  function SvgTab({ start, onChoose, onClose }) {
    const [draft, setDraft] = (0, import_element9.useState)(() => start.paths.length ? start : defaultDrawing());
    (0, import_element9.useEffect)(() => {
      const set = (event) => setDraft(event.detail);
      window.addEventListener("evcert:svg-draft", set);
      return () => window.removeEventListener("evcert:svg-draft", set);
    }, []);
    const usable = ((draft == null ? void 0 : draft.paths) || []).filter((p) => p.d);
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)(import_jsx_runtime25.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "evcert-svg-tab__content", children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(SvgSource, { draft, onChange: setDraft, design: PATH_DESIGN, mode: "light", base: start }) }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "evcert-actions evcert-svg-editor__footer", children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(import_components12.Button, { variant: "tertiary", __next40pxDefaultSize: true, onClick: onClose, children: (0, import_i18n17.__)("Cancel", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(import_components12.Button, { variant: "primary", __next40pxDefaultSize: true, disabled: !usable.length, accessibleWhenDisabled: true, onClick: () => draft && onChoose({ image: "", attachment: 0, json: drawingJson(draft, usable) }), children: (0, import_i18n17.__)("Apply", "events-certificates") })
      ] })
    ] });
  }
  function openMediaChooser({ title, button, suggested, start, onChoose }) {
    const media = window.wp.media;
    const frame = media({
      title,
      button: { text: button, close: false },
      multiple: false,
      states: [
        new media.controller.Library({
          title,
          library: media.query({ type: ["image/png", "image/jpeg", "image/gif", "image/webp"] }),
          // Never an SVG file: drawings are paths.
          multiple: false,
          date: false,
          priority: 20,
          suggestedWidth: suggested[0],
          suggestedHeight: suggested[1]
        })
      ]
    });
    const roots = [];
    const mount = (node, element) => {
      const root2 = (0, import_element9.createRoot)(node);
      root2.render(element);
      roots.push(root2);
    };
    frame.on("select", () => {
      var _a, _b;
      const attachment = frame.state().get("selection").first().toJSON();
      onChoose({ image: ((_b = (_a = attachment.sizes) == null ? void 0 : _a.large) == null ? void 0 : _b.url) || attachment.url, json: "", attachment: attachment.id });
      frame.close();
    });
    frame.on("router:render:browse", (router) => {
      router.set({ "evcert-svg": { text: (0, import_i18n17.__)("SVG", "events-certificates"), priority: 60 } });
    });
    frame.on("content:create:evcert-svg", () => {
      const View = media.View.extend({
        className: "evcert-signature-svgtab",
        render() {
          mount(this.el, /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(SvgTab, { start, onChoose: (choice) => {
            onChoose(choice);
            frame.close();
          }, onClose: () => frame.close() }));
          return this;
        }
      });
      frame.content.set(new View());
    });
    frame.on("content:activate:evcert-svg", () => frame.$el.addClass("evcert-svg-mode"));
    frame.on("content:deactivate:evcert-svg", () => frame.$el.removeClass("evcert-svg-mode"));
    const showDraft = (draft) => {
      frame.content.mode("evcert-svg");
      window.setTimeout(() => window.dispatchEvent(new CustomEvent("evcert:svg-draft", { detail: draft })), 50);
    };
    const files = (event) => {
      var _a;
      const target = event.target;
      return Array.from(event.type === "drop" ? ((_a = event.dataTransfer) == null ? void 0 : _a.files) || [] : (target == null ? void 0 : target.type) === "file" ? target.files || [] : []);
    };
    const takeSvg = (event) => {
      if (!frame.$el.closest(".media-modal").is(":visible")) {
        return;
      }
      const svg = files(event).find(isSvgFile2);
      if (!svg) {
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      if (event.type === "change") {
        event.target.value = "";
      } else {
        frame.modal.$el.trigger("dropzone:leave").removeClass("drag-over");
      }
      svgFile(svg).then((draft) => {
        if (draft) {
          showDraft(draft);
        } else {
          window.dispatchEvent(new CustomEvent("evcert:svg-problem", { detail: (0, import_i18n17.__)("That SVG could not be used: only its paths are read, so shapes and text must be converted to paths first, and it must be a small file.", "events-certificates") }));
        }
      });
    };
    frame.on("open", () => {
      document.addEventListener("drop", takeSvg, true);
      document.addEventListener("change", takeSvg, true);
      const host = document.createElement("div");
      host.className = "evcert-toast-host";
      const box2 = frame.$el.closest(".media-modal");
      box2.append(host);
      mount(host, /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(ClipboardToast, { onPaste: showDraft, modal: box2[0] }));
    });
    frame.on("close", () => {
      document.removeEventListener("drop", takeSvg, true);
      document.removeEventListener("change", takeSvg, true);
      roots.splice(0).forEach((root2) => window.setTimeout(() => root2.unmount(), 0));
      frame.$el.closest(".media-modal").find(".evcert-toast-host").remove();
    });
    frame.open();
  }

  // src/generator/picture-field.tsx
  var import_jsx_runtime26 = __toESM(require_jsx_runtime());
  var addresses = {};
  var pictureSrc = (id) => id ? addresses[id] || "" : "";
  var addressOf = (media) => {
    var _a, _b, _c;
    return ((_c = (_b = (_a = media.media_details) == null ? void 0 : _a.sizes) == null ? void 0 : _b.large) == null ? void 0 : _c.source_url) || media.source_url;
  };
  function ImageRow({ image, vector, label, title, global, kind = "logo", onChange }) {
    const [open, setOpen] = (0, import_element10.useState)(false);
    const [drawing2, setDrawing] = (0, import_element10.useState)(false);
    const [error, setError] = (0, import_element10.useState)("");
    const input = (0, import_element10.useRef)(null);
    const drawn = readVector(vector);
    const [, refresh] = (0, import_element10.useState)(0);
    const shown2 = pictureSrc(image);
    const has = !!image || drawn.paths.some((p) => p.d);
    (0, import_element10.useEffect)(() => {
      if (image && !addresses[image]) {
        (0, import_api_fetch2.default)({ path: `/wp/v2/media/${image}?_fields=id,source_url,media_details` }).then((media) => {
          addresses[image] = addressOf(media);
          refresh((n) => n + 1);
        }).catch(() => void 0);
      }
    }, [image]);
    const done = (id, svg) => {
      onChange(id, svg);
      setOpen(false);
      setError("");
    };
    const fromFile = async (file) => {
      try {
        if (/^image\/svg/i.test(file.type) || /\.svg$/i.test(file.name)) {
          throw new Error("svg");
        }
        const body = new FormData();
        body.append("file", file, file.name);
        const made = await (0, import_api_fetch2.default)({ path: "/wp/v2/media", method: "POST", body });
        addresses[String(made.id)] = addressOf(made);
        done(String(made.id), "");
      } catch (e) {
        setError((0, import_i18n18.__)("That picture could not be uploaded. Use a PNG, JPEG, GIF or WebP; for a drawing, insert SVG paths.", "events-certificates"));
      }
    };
    const svgEl = { id: "picture", type: "svg", name: title, x: 0, y: 0, w: 120, h: 44, vw: drawn.vw, vh: drawn.vh, paths: drawn.paths, color: "$text" };
    return /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "evcert-image", children: [
      /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)(
        import_components13.Button,
        {
          variant: "secondary",
          className: "evcert-image__button",
          onClick: () => {
            if (!hasMedia()) {
              setOpen(true);
              return;
            }
            openMediaChooser({
              title: "logo" === kind ? (0, import_i18n18.__)("Choose a community logo", "events-certificates") : (0, import_i18n18.__)("Choose a signature image", "events-certificates"),
              button: "logo" === kind ? (0, import_i18n18.__)("Set as community logo", "events-certificates") : (0, import_i18n18.__)("Set as signature image", "events-certificates"),
              suggested: "logo" === kind ? [600, 200] : [600, 220],
              start: drawn.paths.length ? { title: "", vw: drawn.vw, vh: drawn.vh, w: drawn.w, h: drawn.h, paths: drawn.paths } : { title: "", vw: 120, vh: 44, paths: [] },
              onChoose: (choice) => {
                if (choice.attachment) {
                  addresses[String(choice.attachment)] = choice.image;
                }
                onChange(choice.attachment ? String(choice.attachment) : "", choice.json);
              }
            });
          },
          children: [
            shown2 && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("img", { className: "evcert-image__preview", src: shown2, alt: "" }),
            !shown2 && drawn.paths.some((p) => p.d) && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("svg", { className: "evcert-image__preview", viewBox: `0 0 ${drawn.vw} ${drawn.vh}`, "aria-hidden": "true", children: drawn.paths.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("path", { d: p.d, fill: p.fill && !p.fill.startsWith("$") ? p.fill : "currentColor", fillRule: p.rule }, i)) }),
            has ? (0, import_i18n18.__)("Replace", "events-certificates") : label
          ]
        }
      ),
      has && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(import_components13.Button, { variant: "link", isDestructive: true, onClick: () => onChange("", ""), children: (0, import_i18n18.__)("Remove", "events-certificates") }),
      open && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(import_components13.Modal, { title, size: "small", onRequestClose: () => setOpen(false), children: /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)(import_components13.__experimentalVStack, { spacing: 3, children: [
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(import_components13.Button, { variant: "secondary", onClick: () => {
          var _a;
          return (_a = input.current) == null ? void 0 : _a.click();
        }, children: (0, import_i18n18.__)("Upload an image", "events-certificates") }),
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("input", { type: "file", ref: input, accept: "image/png,image/jpeg,image/gif,image/webp", hidden: true, onChange: (e) => {
          var _a;
          const first = (_a = e.target.files) == null ? void 0 : _a[0];
          if (first) {
            fromFile(first);
          }
          e.target.value = "";
        } }),
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
          import_components13.Button,
          {
            variant: "secondary",
            onClick: () => {
              setOpen(false);
              setDrawing(true);
            },
            children: (0, import_i18n18.__)("Insert SVG paths", "events-certificates")
          }
        ),
        global && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(import_components13.Button, { variant: "tertiary", onClick: () => done("", ""), children: (0, import_i18n18.__)("Use the one of Settings", "events-certificates") }),
        error && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("p", { className: "evcert-image__error", role: "alert", children: error })
      ] }) }),
      drawing2 && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
        SvgEditor,
        {
          el: svgEl,
          design: PATH_DESIGN,
          mode: "light",
          preferred: { w: drawn.w, h: drawn.h },
          onApply: () => void 0,
          onApplyDrawing: (draft) => onChange("", draft.paths.length ? drawingJson(draft, draft.paths) : ""),
          onClose: () => setDrawing(false)
        }
      )
    ] });
  }

  // src/quick-generator/design.ts
  var PT = 0.3528;
  var VOUCHING = ["authenticity", "code", "verify"];
  var SERIF = /serif|lora|georgia|times|garamond/i;
  function fontOf(b, el) {
    const family = (el.font || "").replace(/['"]/g, "").split(",")[0].trim();
    const want = el.weight || 400;
    const weight = [400, 500, 600].reduce((best, w) => Math.abs(w - want) < Math.abs(best - want) ? w : best, 400);
    const face = `${family}:${weight}`;
    if (b.fonts.includes(face)) {
      return face;
    }
    return SERIF.test(family) && !/sans/i.test(family) ? "CertSerif:400" : want >= 600 ? "CertSans:600" : "CertSans:400";
  }
  function cssFont(face, px) {
    const [family, weight] = face.split(":");
    return `${weight} ${px}px "${family}", ${SERIF.test(family) && !/sans/i.test(family) ? "Georgia, serif" : "system-ui, sans-serif"}`;
  }
  var METRICS = {};
  function metricsOf(face) {
    if (METRICS[face]) {
      return METRICS[face];
    }
    let found = { ascent: SERIF.test(face) ? 0.99 : 1.025, descent: SERIF.test(face) ? 0.31 : 0.275 };
    if (typeof document !== "undefined") {
      const ctx = document.createElement("canvas").getContext("2d");
      if (ctx) {
        ctx.font = cssFont(face, 100);
        const m = ctx.measureText("Hg");
        if (m.fontBoundingBoxAscent) {
          found = { ascent: m.fontBoundingBoxAscent / 100, descent: m.fontBoundingBoxDescent / 100 };
          if (document.fonts && document.fonts.check(cssFont(face, 16))) {
            METRICS[face] = found;
          }
        }
      }
    }
    return found;
  }
  function fontsUsed(design, shipped) {
    const probe = { fonts: shipped };
    const faces = /* @__PURE__ */ new Set(["CertSerif:400", "CertSans:400", "CertSans:600"]);
    design.elements.forEach((raw) => {
      const el = resolve2(raw, design.page);
      if ("text" === el.type) {
        faces.add(fontOf(probe, el));
      }
    });
    return [...faces].filter((face) => shipped.includes(face));
  }
  function textOf(runs, value) {
    return (runs || []).map((run) => "field" in run ? value(run.field, run.format) : run.text).join("");
  }
  function orphanLabels(design, value) {
    const texts = /* @__PURE__ */ new Map();
    design.elements.forEach((raw) => {
      const el = resolve2(raw, design.page);
      if ("text" === el.type && el.id) {
        texts.set(el.id, el);
      }
    });
    const orphans = /* @__PURE__ */ new Set();
    texts.forEach((_el, id) => {
      const pair = id.endsWith("-label") ? texts.get(id.slice(0, -6) + "-value") : void 0;
      if (pair && !pair.hidden && "" === textOf(pair.runs, value).trim()) {
        orphans.add(id);
      }
    });
    return orphans;
  }
  function wrap(b, text2, font, size, max, spacing) {
    const lines = [];
    text2.split("\n").forEach((paragraph) => {
      let line2 = "";
      paragraph.split(/\s+/).filter(Boolean).forEach((word) => {
        const attempt = line2 ? line2 + " " + word : word;
        if (!line2 || b.measure(attempt, font, size, spacing) <= max) {
          line2 = attempt;
        } else {
          lines.push(line2);
          line2 = word;
        }
      });
      lines.push(line2);
    });
    return lines;
  }
  function isFilled(value) {
    return !!value && "none" !== value && "transparent" !== value;
  }
  function drawText(b, design, el, value, locale) {
    let text2 = textOf(runsIn(el, locale), value);
    if (el.upper) {
      text2 = text2.toLocaleUpperCase(locale);
    }
    if ("" === text2.trim()) {
      return;
    }
    const font = fontOf(b, el);
    const spacing = (el.ls || 0) * PT;
    const width = el.w * PT;
    let size = el.size || 14;
    if (el.fit) {
      const natural = b.measure(text2.replace(/\n/g, " "), font, size, spacing);
      if (natural > width && natural > 0) {
        size = Math.max(el.min || 8, size * width / natural);
      }
    }
    const lh = el.lh || 1.2;
    const lines = el.fit ? [text2.replace(/\n/g, " ")] : wrap(b, text2, font, size, width, spacing);
    const m = metricsOf(font);
    const base = size * ((lh - (m.ascent + m.descent)) / 2 + m.ascent) * PT;
    const pitch = size * lh * PT;
    const left2 = el.x * PT;
    const top = el.y * PT;
    const cx = left2 + width / 2;
    const cy = top + el.h * PT / 2;
    const turn = (el.rotation || 0) * Math.PI / 180;
    const ink = color(design, el.color || "$text", "light");
    lines.forEach((line2, i) => {
      const w = b.measure(line2, font, size, spacing);
      const x = "center" === el.align ? left2 + (width - w) / 2 : "right" === el.align ? left2 + width - w : left2;
      const y = top + base + i * pitch;
      if (!turn) {
        b.text(line2, x, y, { font, size, color: ink, cs: spacing });
        return;
      }
      const dx = x - cx;
      const dy = y - cy;
      b.text(line2, cx + dx * Math.cos(turn) - dy * Math.sin(turn), cy + dx * Math.sin(turn) + dy * Math.cos(turn), { font, size, color: ink, cs: spacing, angle: -(el.rotation || 0) });
    });
  }
  function artOf(design, el) {
    const fill = (value) => color(design, value, "light");
    if (el.type === "svg") {
      const paths = (el.paths || []).map((p) => `<path d="${p.d}" fill="${isFilled(fill(p.fill)) ? fill(p.fill) : fill(el.color || "$text")}"${"evenodd" === p.rule ? ' fill-rule="evenodd"' : ""}/>`).join("");
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.vw} ${el.vh}" width="${el.w}" height="${el.h}">${paths}</svg>`, w: el.w, h: el.h };
    }
    if (el.type === "path") {
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.vw} ${el.vh}" width="${el.w}" height="${el.h}"><path d="${el.d}" fill="${fill(el.fill)}" stroke="${fill(el.stroke)}" stroke-width="${el.strokeWidth || 0}"/></svg>`, w: el.w, h: el.h };
    }
    if (el.type === "ellipse") {
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${el.w} ${el.h}" width="${el.w}" height="${el.h}"><ellipse cx="${el.w / 2}" cy="${el.h / 2}" rx="${el.w / 2}" ry="${el.h / 2}" fill="${fill(el.fill)}"/></svg>`, w: el.w, h: el.h };
    }
    if (el.type === "rect" && (el.radius && el.radius.some(Boolean) || el.rotation)) {
      const sw = el.strokeWidth || 0;
      return { svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${-sw / 2} ${-sw / 2} ${el.w + sw} ${el.h + sw}" width="${el.w + sw}" height="${el.h + sw}"><path d="${rectPath(0, 0, el.w, el.h, el.radius, el.corner)}" fill="${fill(el.fill)}" stroke="${fill(el.stroke)}" stroke-width="${sw}"/></svg>`, w: el.w + sw, h: el.h + sw };
    }
    return null;
  }
  function rasterize(svg, w, h, alias) {
    return new Promise((resolveImage, reject) => {
      const img = new Image();
      img.onload = () => {
        var _a;
        const scale = 4;
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(w * scale));
        canvas.height = Math.max(1, Math.round(h * scale));
        (_a = canvas.getContext("2d")) == null ? void 0 : _a.drawImage(img, 0, 0, canvas.width, canvas.height);
        const src = canvas.toDataURL("image/png");
        const png = new Image();
        png.onload = () => resolveImage({ src, img: png, ratio: w / h, alias });
        png.src = src;
      };
      img.onerror = reject;
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
    });
  }
  function rotated(pic, angle, w, h) {
    return new Promise((resolveImage) => {
      const img = pic.img;
      if (!img) {
        resolveImage(pic);
        return;
      }
      const rad = angle * Math.PI / 180;
      const cos = Math.abs(Math.cos(rad));
      const sin = Math.abs(Math.sin(rad));
      const bw = w * cos + h * sin;
      const bh = w * sin + h * cos;
      const scale = img.naturalWidth / w;
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(bw * scale));
      canvas.height = Math.max(1, Math.round(bh * scale));
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(rad);
        ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
      }
      const src = canvas.toDataURL("image/png");
      const png = new Image();
      png.onload = () => resolveImage({ src, img: png, ratio: bw / bh, alias: pic.alias + "-r", rot: { w: bw, h: bh } });
      png.src = src;
    });
  }
  async function prepare(design) {
    const art2 = {};
    for (const raw of design.elements) {
      const el = resolve2(raw, design.page);
      if (el.hidden || "signature" === el.type) {
        continue;
      }
      const found = artOf(design, el);
      if (found) {
        try {
          const flat = await rasterize(found.svg, found.w, found.h, "art-" + el.id);
          art2[el.id] = el.rotation ? await rotated(flat, el.rotation, found.w, found.h) : flat;
        } catch (e) {
        }
      }
    }
    return art2;
  }
  function draw(b, design, value, pictures, locale) {
    const page = design.page;
    const bg = color(design, pageBg(page, "light"), "light");
    const fill = isFilled(bg) ? bg : "#ffffff";
    if (!(b.skipWhitePage && isWhite(fill))) {
      b.rect(0, 0, page.w * PT, page.h * PT, fill);
    }
    let logoDrawn = false;
    const orphans = orphanLabels(design, value);
    for (const raw of design.elements) {
      const el = resolve2(raw, page);
      if (el.hidden || el.type === "verification" || VOUCHING.includes(el.slot || "") || orphans.has(el.id)) {
        continue;
      }
      b.alpha(el.opacity === void 0 ? 1 : el.opacity);
      const art2 = pictures.art && pictures.art[el.id];
      if (art2) {
        const at = box(el);
        if (art2.rot) {
          const cx = at.x + at.w / 2;
          const cy = at.y + at.h / 2;
          b.image(art2, (cx - art2.rot.w / 2) * PT, (cy - art2.rot.h / 2) * PT, art2.rot.w * PT, art2.rot.h * PT);
        } else {
          b.image(art2, at.x * PT, at.y * PT, at.w * PT, at.h * PT);
        }
        continue;
      }
      switch (el.type) {
        case "text":
          drawText(b, design, el, value, locale);
          break;
        case "rect": {
          const fill2 = color(design, el.fill, "light");
          if (isFilled(fill2)) {
            b.rect(el.x * PT, el.y * PT, el.w * PT, el.h * PT, fill2);
          }
          const stroke2 = color(design, el.stroke, "light");
          if (isFilled(stroke2) && (el.strokeWidth || 0) > 0) {
            const [x, y, w, h] = [el.x * PT, el.y * PT, el.w * PT, el.h * PT];
            const width = (el.strokeWidth || 0) * PT;
            [[x, y, x + w, y], [x + w, y, x + w, y + h], [x + w, y + h, x, y + h], [x, y + h, x, y]].forEach(([x1, y1, x2, y2]) => b.line(x1, y1, x2, y2, stroke2, width));
          }
          break;
        }
        case "line":
          b.line(el.x1 * PT, el.y1 * PT, el.x2 * PT, el.y2 * PT, color(design, el.stroke || "$line", "light"), (el.strokeWidth || 1) * PT);
          break;
        case "signature":
          if (pictures.signature) {
            const w = Math.min(el.w, el.h * pictures.signature.ratio) * PT;
            const h = w / pictures.signature.ratio;
            b.image(pictures.signature, el.x * PT, (el.y + el.h) * PT - h, w, h);
          }
          break;
        case "image":
          if (("logo" === el.slot || "logo" === el.id) && pictures.logo) {
            const ratio = pictures.logo.ratio;
            const w = Math.min(el.w * PT, el.h * PT * ratio);
            const h = w / ratio;
            b.image(pictures.logo, (el.x + el.w) * PT - w, el.y * PT + (el.h * PT - h) / 2, w, h);
            logoDrawn = true;
          }
          break;
        default:
          break;
      }
    }
    b.alpha(1);
    if (pictures.logo && !logoDrawn) {
      const found = design.elements.map((e) => resolve2(e, page)).find((e) => "title" === e.id || "title" === e.slot);
      const title = found ? box(found) : null;
      const right = (title ? title.x + title.w : page.w - (page.safe || 28)) * PT;
      let w = 62;
      let h = w / pictures.logo.ratio;
      if (h > 18) {
        h = 18;
        w = h * pictures.logo.ratio;
      }
      b.image(pictures.logo, right - w, 20 + (18 - h) / 2, w, h);
    }
  }
  window.evcertDesign = { draw, prepare, css: cssFont, fontsUsed };

  // src/quick-generator/preview.ts
  var PT2 = 0.3528;
  function fmt(text2, ...args) {
    let next = 0;
    return String(text2).replace(/%(?:(\d+)\$)?(0?)(\d*)[sd]/g, (_match, position, zero, width) => {
      let value = String(args[position ? Number(position) - 1 : next++]);
      if (width) {
        value = value.padStart(Number(width), zero ? "0" : " ");
      }
      return value;
    });
  }
  function phpDate(format, d, locale) {
    const pad2 = (n) => String(n).padStart(2, "0");
    const name = (options) => new Intl.DateTimeFormat(locale, options).format(d);
    const hours12 = d.getHours() % 12 || 12;
    const period = () => {
      const part = new Intl.DateTimeFormat(locale, { hour: "numeric", hour12: true }).formatToParts(d).find((p) => "dayPeriod" === p.type);
      return part ? part.value : d.getHours() < 12 ? "AM" : "PM";
    };
    let out = "";
    for (let i = 0; i < format.length; i++) {
      const c = format[i];
      switch (c) {
        case "\\":
          out += format[++i] || "";
          break;
        case "d":
          out += pad2(d.getDate());
          break;
        case "j":
          out += d.getDate();
          break;
        case "D":
          out += name({ weekday: "short" });
          break;
        case "l":
          out += name({ weekday: "long" });
          break;
        case "m":
          out += pad2(d.getMonth() + 1);
          break;
        case "n":
          out += d.getMonth() + 1;
          break;
        case "M":
          out += name({ month: "short" });
          break;
        case "F":
          out += name({ month: "long" });
          break;
        case "Y":
          out += d.getFullYear();
          break;
        case "y":
          out += pad2(d.getFullYear() % 100);
          break;
        case "H":
          out += pad2(d.getHours());
          break;
        case "G":
          out += d.getHours();
          break;
        case "h":
          out += pad2(hours12);
          break;
        case "g":
          out += hours12;
          break;
        case "i":
          out += pad2(d.getMinutes());
          break;
        case "s":
          out += pad2(d.getSeconds());
          break;
        case "a":
          out += period().toLowerCase();
          break;
        case "A":
          out += period().toUpperCase();
          break;
        default:
          out += c;
      }
    }
    return out;
  }
  function dateText(cfg, iso, format) {
    if (!iso) {
      return "";
    }
    const [y, m, d] = iso.split("-").map(Number);
    const date = new Date(y, m - 1, d);
    if ("iso" === format) {
      return iso;
    }
    if ("month" === format) {
      return new Intl.DateTimeFormat(cfg.locale, { month: "long", year: "numeric" }).format(date);
    }
    if ("long" === format || "medium" === format || "short" === format) {
      return new Intl.DateTimeFormat(cfg.locale, { dateStyle: format }).format(date);
    }
    return phpDate(cfg.dateFormat, date, cfg.locale);
  }
  var timeText = (cfg, hhmm) => {
    const [h, m] = hhmm.split(":").map(Number);
    return phpDate(cfg.timeFormat, new Date(2e3, 0, 1, h, m), cfg.locale);
  };
  function duration(cfg, from, to) {
    const t = cfg.i18n;
    const minutes = (hhmm) => {
      const [h2, m2] = hhmm.split(":").map(Number);
      return h2 * 60 + m2;
    };
    let total = minutes(to) - minutes(from);
    if (total <= 0) {
      total += 24 * 60;
    }
    const h = Math.floor(total / 60);
    const m = total % 60;
    if (!m) {
      return 1 === h ? t.oneHour : fmt(t.nHours, h);
    }
    return h ? fmt(t.hoursMinutes, h, m) : fmt(t.nMinutes, m);
  }
  var shortLink = (url) => (url || "").replace(/^https?:\/\/(www\.)?/, "").replace(/\?.*$/, "").replace(/\/$/, "");
  function valueOf(cfg, ev, name) {
    const t = cfg.i18n;
    const today = (/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE");
    const many = /,|;/.test(ev.speakers) || new RegExp("\\s" + t.and + "\\s", "i").test(ev.speakers);
    let time = "";
    if (ev.start) {
      time = ev.end ? fmt(t.fromTo, timeText(cfg, ev.start), timeText(cfg, ev.end)) : fmt(t.startingAt, timeText(cfg, ev.start));
      if (ev.showHours && ev.end) {
        time = fmt(t.withSpan, time, duration(cfg, ev.start, ev.end));
      }
    }
    const fields2 = {
      ...cfg.phrases,
      name: name || t.participantName,
      event: ev.title || t.meetupTitle,
      community: ev.community,
      location: [ev.venue, ev.city].filter(Boolean).join(", "),
      speakers: ev.speakers,
      speakers_label: ev.speakers.trim() ? many ? t.speakers : t.speaker : "",
      event_time: time,
      event_link: shortLink(ev.link),
      issued_on: fmt(t.issuedOn, dateText(cfg, today, "long")),
      signer_name: ev.signName,
      signer_role: ev.signRole
    };
    return (field2, format) => {
      if ("event_date" === field2) {
        return dateText(cfg, ev.date || today, format);
      }
      if ("issued_date" === field2) {
        return dateText(cfg, today, format);
      }
      return fields2[field2] || "";
    };
  }
  function canvasBackend(ctx, scale, faces) {
    const font = (face, size) => cssFont(face, size * PT2 * scale);
    return {
      fonts: faces,
      alpha(a) {
        ctx.globalAlpha = a;
      },
      rect(x, y, w, h, c) {
        const left2 = Math.round(x * scale);
        const top = Math.round(y * scale);
        ctx.fillStyle = c;
        ctx.fillRect(left2, top, Math.round((x + w) * scale) - left2, Math.round((y + h) * scale) - top);
      },
      line(x1, y1, x2, y2, c, width) {
        ctx.strokeStyle = c;
        ctx.lineWidth = Math.max(1, width * scale);
        ctx.beginPath();
        ctx.moveTo(x1 * scale, y1 * scale);
        ctx.lineTo(x2 * scale, y2 * scale);
        ctx.stroke();
      },
      measure(text2, f, size, spacing = 0) {
        ctx.font = font(f, size);
        ctx.letterSpacing = "0px";
        return ctx.measureText(text2).width / scale + spacing * text2.length;
      },
      text(text2, x, y, o) {
        ctx.save();
        ctx.font = font(o.font, o.size);
        ctx.fillStyle = o.color;
        ctx.textBaseline = "alphabetic";
        ctx.letterSpacing = (o.cs || 0) * scale + "px";
        ctx.translate(x * scale, o.angle ? y * scale : Math.round(y * scale));
        if (o.angle) {
          ctx.rotate(-o.angle * Math.PI / 180);
        }
        ctx.fillText(text2, 0, 0);
        ctx.restore();
      },
      image(pic, x, y, w, h) {
        if (pic.img) {
          const left2 = Math.round(x * scale);
          const top = Math.round(y * scale);
          ctx.drawImage(pic.img, left2, top, Math.max(1, Math.round((x + w) * scale) - left2), Math.max(1, Math.round((y + h) * scale) - top));
        }
      }
    };
  }
  var pics = /* @__PURE__ */ new Map();
  function picture2(src) {
    if (!src) {
      return Promise.resolve(null);
    }
    let found = pics.get(src);
    if (!found) {
      found = new Promise((resolve3) => {
        const img = new Image();
        img.onload = () => resolve3({ src, img, ratio: (img.naturalWidth || 1) / (img.naturalHeight || 1), alias: "pic" + pics.size });
        img.onerror = () => resolve3(null);
        img.src = src;
      });
      pics.set(src, found);
    }
    return found;
  }
  function drawingSrc(json) {
    try {
      const d = JSON.parse(json);
      if (!d || !(d.vw > 0) || !(d.vh > 0) || !Array.isArray(d.paths)) {
        return "";
      }
      const paths = d.paths.map((p) => `<path d="${String(p.d).replace(/"/g, "")}" fill="${p.fill && !p.fill.startsWith("$") ? p.fill : "#1e1e1e"}"${p.rule === "evenodd" ? ' fill-rule="evenodd"' : ""}/>`).join("");
      const [sw, sh] = d.w > 0 && d.h > 0 ? [d.w, d.h] : [d.vw, d.vh];
      const k = Math.min(8, 1200 / Math.max(sw, sh));
      return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${sw * k}" height="${sh * k}" viewBox="0 0 ${d.vw} ${d.vh}">${paths}</svg>`);
    } catch (e) {
      return "";
    }
  }
  var art = null;
  async function drawPreview(canvas, cfg, ev, name, pictures) {
    const faces = Object.keys(cfg.fonts || {});
    art = art || prepare(cfg.design);
    const [shapes, logo2, signature2] = await Promise.all([art, picture2(pictures.logo), picture2(pictures.signature)]);
    if (document.fonts && faces.length) {
      await Promise.all(faces.map((face) => document.fonts.load(cssFont(face, 16)).catch(() => [])));
    }
    const W = cfg.design.page.w * PT2;
    const scale = canvas.width / W;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return;
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    draw(canvasBackend(ctx, scale, faces), cfg.design, valueOf(cfg, ev, name), { signature: signature2, logo: logo2, art: shapes }, cfg.locale);
  }

  // src/generator/people.ts
  var same = (a, b) => a.trim().toLowerCase() === b.trim().toLowerCase();
  function mergePeople(list, incoming, nextId) {
    const people = [...list];
    let added = 0;
    for (const one of incoming) {
      const name = (one.name || "").trim();
      if ("" === name || people.some((p) => same(p.name, name))) {
        continue;
      }
      const status = "no_show" === one.status ? "no_show" : "attended";
      people.push({
        id: nextId++,
        name,
        email: one.email || "",
        roles: one.roles || [],
        roleLabels: one.role_labels || [],
        status,
        on: "attended" === status
      });
      added++;
    }
    return { people, added, nextId };
  }
  var setAll = (list, on) => list.map((p) => ({ ...p, on }));
  var countSelected = (list) => list.filter((p) => p.on).length;
  var selectedPeople = (list) => list.filter((p) => p.on);
  function whatIsMissing(values, selected, hasCurrent, justOne) {
    const missing = [];
    if ("" === (values.title || "").trim()) {
      missing.push("title");
    }
    if ("" === (values.date || "").trim()) {
      missing.push("date");
    }
    if (justOne ? !hasCurrent : selected < 1) {
      missing.push(justOne ? "current" : "people");
    }
    return missing;
  }

  // src/generator/index.tsx
  var import_jsx_runtime27 = __toESM(require_jsx_runtime());
  var config = window.evcertGenerator || {};
  var field = { __next40pxDefaultSize: true, __nextHasNoMarginBottom: true };
  function Hidden({ name, value }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("input", { type: "hidden", name, value });
  }
  var openHelp = () => window.dispatchEvent(new Event("evcert:open-help"));
  var actionsRoot = document.getElementById("evcert-generator-actions");
  var OpenRow = (0, import_element11.createContext)({ open: "", setOpen: () => {
  } });
  function SummaryRow({
    label,
    value,
    placeholder,
    action,
    disabled,
    children
  }) {
    const [anchor, setAnchor] = (0, import_element11.useState)(null);
    const rows = (0, import_element11.useContext)(OpenRow);
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-summary__row", ref: setAnchor, children: [
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { className: "evcert-summary__label", children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
        import_components14.Dropdown,
        {
          className: "evcert-summary__dropdown",
          popoverProps: { anchor, "aria-label": label, placement: "left-start", offset: 36, shift: true },
          focusOnMount: true,
          open: rows.open === label,
          onToggle: (opening) => rows.setOpen(opening ? label : rows.open === label ? "" : rows.open),
          renderToggle: ({ isOpen, onToggle }) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
            import_components14.Button,
            {
              variant: "tertiary",
              size: "compact",
              className: "evcert-summary__value",
              onClick: onToggle,
              "aria-expanded": isOpen,
              disabled: !!disabled,
              label: disabled || void 0,
              showTooltip: !!disabled,
              "aria-label": (0, import_i18n19.sprintf)(
                /* translators: 1: a field's name, 2: its value. */
                (0, import_i18n19.__)("%1$s: %2$s", "events-certificates"),
                label,
                value || placeholder || ""
              ),
              children: value ? value : /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { className: "evcert-summary__empty", children: placeholder || "\u2014" })
            }
          ),
          renderContent: ({ onClose }) => /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-summary__editor", children: [
            /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.__experimentalHStack, { className: "evcert-summary__editor-header", alignment: "center", children: [
              /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("h2", { className: "evcert-summary__editor-title", children: label }),
              action && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { size: "small", variant: "tertiary", onClick: action.onClick, children: action.label }),
              /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { size: "small", icon: close_small_default, label: (0, import_i18n19.__)("Close"), onClick: onClose })
            ] }),
            "function" === typeof children ? children(onClose) : children
          ] })
        }
      )
    ] });
  }
  function CsvField({ file, busy, onFile }) {
    const input = (0, import_element11.useRef)(null);
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      import_components14.BaseControl,
      {
        ...field,
        id: "evcert-csv",
        label: (0, import_i18n19.__)("Participant list file", "events-certificates"),
        help: (0, import_element11.createInterpolateElement)(
          (0, import_i18n19.__)("Not sure where to download the list? <a>See the step by step on Meetup</a>.", "events-certificates"),
          { a: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "link", onClick: openHelp }) }
        ),
        children: /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-generator__file", children: [
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "secondary", className: "evcert-generator__file-toggle", disabled: busy, onClick: () => {
            var _a;
            return (_a = input.current) == null ? void 0 : _a.click();
          }, children: file ? (0, import_i18n19.__)("Replace the file", "events-certificates") : (0, import_i18n19.__)("Choose a CSV file", "events-certificates") }),
          file && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { className: "evcert-generator__file-name", children: file }),
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.DropZone, { onFilesDrop: (files) => files[0] && onFile(files[0]) }),
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
            "input",
            {
              type: "file",
              id: "evcert-csv",
              ref: input,
              accept: ".csv,text/csv",
              hidden: true,
              onChange: (e) => {
                var _a;
                const first = (_a = e.target.files) == null ? void 0 : _a[0];
                if (first) {
                  onFile(first);
                }
                e.target.value = "";
              }
            }
          )
        ] })
      }
    );
  }
  function TutorialPanel({ tutorial }) {
    const [big, setBig] = (0, import_element11.useState)(null);
    const [open, setOpen] = (0, import_element11.useState)(0);
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-tutorial", children: [
      /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-tutorial__head", children: [
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("h2", { children: tutorial.title }),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { icon: close_small_default, label: (0, import_i18n19.__)("Close"), onClick: () => window.dispatchEvent(new Event("evcert:close-help")) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
        "p",
        {
          className: "evcert-tutorial__intro",
          onClick: (event) => {
            const link = event.target.closest("a[data-evcert-open]");
            if (link) {
              event.preventDefault();
              window.dispatchEvent(new Event("evcert:toggle-people"));
            }
          },
          dangerouslySetInnerHTML: { __html: tutorial.intro }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Panel, { className: "evcert-tutorial__steps", children: tutorial.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.PanelBody, { title: step.title, opened: open === i, onToggle: () => setOpen(open === i ? -1 : i), children: [
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { className: "evcert-tutorial__text", dangerouslySetInnerHTML: { __html: step.text } }),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
          "div",
          {
            className: "evcert-tutorial__shot",
            onClick: (event) => {
              if (event.target.closest(".evcert-tsi__open")) {
                setBig(step.picture);
              }
            },
            dangerouslySetInnerHTML: { __html: step.picture.html }
          }
        )
      ] }, step.title)) }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { className: "evcert-tutorial__hint", children: tutorial.hint }),
      big && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Modal, { title: big.alt, size: "large", className: "evcert-tutorial-zoom", onRequestClose: () => setBig(null), children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { className: "evcert-tutorial-zoom__picture", dangerouslySetInnerHTML: { __html: big.html } }) })
    ] });
  }
  function RenameModal({ title, onSave, onClose }) {
    const [name, setName] = (0, import_element11.useState)(title);
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Modal, { title: title ? (0, import_i18n19.__)("Rename event", "events-certificates") : (0, import_i18n19.__)("Name event", "events-certificates"), size: "small", onRequestClose: onClose, children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
      "form",
      {
        onSubmit: (event) => {
          event.preventDefault();
          onSave(name.trim());
        },
        children: /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.__experimentalVStack, { spacing: 5, children: [
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.TextControl, { ...field, label: (0, import_i18n19.__)("Name"), value: name, placeholder: (0, import_i18n19.__)("Event name\u2026", "events-certificates"), onChange: setName }),
          /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.__experimentalHStack, { justify: "flex-end", children: [
            /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "tertiary", onClick: onClose, children: (0, import_i18n19.__)("Cancel") }),
            /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "primary", type: "submit", children: (0, import_i18n19.__)("Save") })
          ] })
        ] })
      }
    ) });
  }
  var CONTEXT = "root";
  function Commands({ canMany, canOne, helpOpen }) {
    const urls = config.urls || {};
    const go = (key) => ({ close }) => {
      close();
      if (urls[key]) {
        window.location.href = urls[key];
      }
    };
    const send = (format, current = false) => ({ close }) => {
      close();
      window.dispatchEvent(new CustomEvent("evcert:submit", { detail: { format, current } }));
    };
    (0, import_commands.useCommand)({
      name: "evcert/generator-help",
      label: helpOpen ? (0, import_i18n19.__)("Hide how to get participants", "events-certificates") : (0, import_i18n19.__)("Show how to get participants", "events-certificates"),
      icon: help_default,
      category: "command",
      context: CONTEXT,
      callback: ({ close }) => {
        close();
        window.dispatchEvent(new Event(helpOpen ? "evcert:close-help" : "evcert:open-help"));
      }
    });
    (0, import_commands.useCommand)({ name: "evcert/generator-people", label: (0, import_i18n19.__)("Show the participants", "events-certificates"), icon: page_default, category: "command", context: CONTEXT, callback: ({ close }) => {
      close();
      window.dispatchEvent(new Event("evcert:toggle-people"));
    } });
    (0, import_commands.useCommand)({ name: "evcert/generator-current", label: (0, import_i18n19.__)("Download current", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: send("pdf", true), disabled: !canOne });
    (0, import_commands.useCommand)({ name: "evcert/generator-pdf", label: (0, import_i18n19.__)("Download PDF", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: send("pdf"), disabled: !canMany });
    (0, import_commands.useCommand)({ name: "evcert/generator-zip", label: (0, import_i18n19.__)("Download ZIP", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: send("zip"), disabled: !canMany });
    (0, import_commands.useCommand)({ name: "evcert/generator-events", label: (0, import_i18n19.__)("Go to Events", "events-certificates"), icon: calendar_default, category: "command", context: CONTEXT, callback: go("events"), disabled: !urls.events });
    (0, import_commands.useCommand)({ name: "evcert/generator-certificates", label: (0, import_i18n19.__)("Go to Certificates", "events-certificates"), icon: page_default, category: "command", context: CONTEXT, callback: go("certificates"), disabled: !urls.certificates });
    (0, import_commands.useCommand)({ name: "evcert/generator-settings", label: (0, import_i18n19.__)("Go to Settings", "events-certificates"), icon: cog_default, category: "command", context: CONTEXT, callback: go("settings"), disabled: !urls.settings });
    return null;
  }
  var is12HourTime = /a(?!\\)/i.test((0, import_date.getSettings)().formats.time.toLowerCase().replace(/\\\\/g, "").split("").reverse().join(""));
  var pad = (n) => String(n).padStart(2, "0");
  var todayLocal = () => {
    const now = /* @__PURE__ */ new Date();
    return now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate());
  };
  var startText = (day, time) => {
    if (!day) {
      return "";
    }
    const shown2 = /* @__PURE__ */ new Date(day + "T" + (time || "00:00") + ":00");
    if (isNaN(shown2.getTime())) {
      return day;
    }
    return shown2.toLocaleString(document.documentElement.lang || void 0, { dateStyle: "medium", ...time ? { timeStyle: "short" } : {} });
  };
  var addMinutes = (time, minutes) => {
    const [h, m] = time.split(":").map(Number);
    if (isNaN(h) || isNaN(m) || h * 60 + m + minutes >= 24 * 60) {
      return "";
    }
    const total = h * 60 + m + minutes;
    return pad(Math.floor(total / 60)) + ":" + pad(total % 60);
  };
  var LENGTHS = [
    [60, (0, import_i18n19.__)("1 hour", "events-certificates")],
    [90, (0, import_i18n19.__)("1.5 hours", "events-certificates")],
    [120, (0, import_i18n19.__)("2 hours", "events-certificates")],
    [180, (0, import_i18n19.__)("3 hours", "events-certificates")]
  ];
  function Form() {
    const [values, setValues] = (0, import_element11.useState)({
      community: "",
      title: "",
      date: "",
      start_time: "",
      end_time: "",
      logo: "",
      logo_svg: "",
      signature_image: "",
      signature_svg: "",
      venue: "",
      city: "",
      speakers: "",
      link: "",
      signer_name: config.signerName || "",
      signer_role: config.signerRole || "",
      lines: ""
    });
    const [endMode, setEndMode] = (0, import_element11.useState)(120);
    const [showHours, setShowHours] = (0, import_element11.useState)(true);
    const [people, setPeople] = (0, import_element11.useState)([]);
    const [current, setCurrent] = (0, import_element11.useState)(null);
    const [file, setFile] = (0, import_element11.useState)("");
    const [busy, setBusy] = (0, import_element11.useState)(false);
    const [note, setNote] = (0, import_element11.useState)("");
    const [open, setOpen] = (0, import_element11.useState)(true);
    const [tab, setTab] = (0, import_element11.useState)("certificate");
    const [tabNonce, setTabNonce] = (0, import_element11.useState)(0);
    const [openRow, setOpenRow] = (0, import_element11.useState)("");
    const [adding, setAdding] = (0, import_element11.useState)(false);
    const [renaming, setRenaming] = (0, import_element11.useState)(false);
    const [helpOpen, setHelpOpen] = (0, import_element11.useState)(true);
    (0, import_element11.useEffect)(() => {
      const onChange = (e) => {
        var _a;
        return setHelpOpen(!!((_a = e.detail) == null ? void 0 : _a.open));
      };
      window.addEventListener("evcert:help-changed", onChange);
      return () => window.removeEventListener("evcert:help-changed", onChange);
    }, []);
    const [posting, setPosting] = (0, import_element11.useState)(null);
    const nextId = (0, import_element11.useRef)(1);
    const set = (key) => (value) => setValues((old) => ({ ...old, [key]: value }));
    const examples = config.examples || {};
    const currentPerson = people.find((p) => p.id === current) || null;
    const selected = countSelected(people);
    const endTime = "custom" === endMode ? values.end_time : values.start_time ? addMinutes(values.start_time, endMode) : "";
    const missingAll = whatIsMissing(values, selected, !!currentPerson, false);
    const missingOne = whatIsMissing(values, selected, !!currentPerson, true);
    const needText = (missing) => {
      const parts = [...missing.includes("title") ? [(0, import_i18n19.__)("the title", "events-certificates")] : [], ...missing.includes("date") ? [(0, import_i18n19.__)("the date", "events-certificates")] : []];
      const sentences = [];
      if (parts.length) {
        sentences.push((0, import_i18n19.sprintf)((0, import_i18n19.__)("Fill in %s of the meetup before generating.", "events-certificates"), parts.join(" " + (0, import_i18n19.__)("and", "events-certificates") + " ")));
      }
      if (missing.includes("people") || missing.includes("current")) {
        sentences.push((0, import_i18n19.__)("Select at least one person.", "events-certificates"));
      }
      return sentences.join(" ");
    };
    const update = (id, change) => setPeople((list) => list.map((p) => p.id === id ? { ...p, ...change } : p));
    const addPeople = async (lines, csv) => {
      const body = new FormData();
      body.append("lines", lines);
      if (csv) {
        body.append("csv", csv);
      }
      setBusy(true);
      try {
        const answer = await (0, import_api_fetch3.default)({ path: "/evcert/v1/generator/people", method: "POST", body });
        const merged = mergePeople(people, answer.people, nextId.current);
        nextId.current = merged.nextId;
        setPeople(merged.people);
        if (!currentPerson && merged.people.length) {
          setCurrent(merged.people[0].id);
        }
        if (csv) {
          setFile(csv.name);
        } else {
          set("lines")("");
        }
        const said = [csv ? (0, import_i18n19.sprintf)((0, import_i18n19.__)("%d people imported", "events-certificates"), merged.added) : (0, import_i18n19.sprintf)((0, import_i18n19.__)("%d name(s) added.", "events-certificates"), merged.added)];
        if (answer.info.rsvp_no) {
          said.push((0, import_i18n19.sprintf)((0, import_i18n19.__)('%d with RSVP "No" left out', "events-certificates"), answer.info.rsvp_no));
        }
        if (answer.info.absent) {
          said.push((0, import_i18n19.sprintf)((0, import_i18n19.__)("%d marked as absent were left unchecked", "events-certificates"), answer.info.absent));
        }
        if (!merged.added && !answer.people.length) {
          said.push(csv ? (0, import_i18n19.__)("No names found in that file. Check that it is the Meetup attendee list.", "events-certificates") : (0, import_i18n19.__)("Add at least one name, or a CSV file with the participants.", "events-certificates"));
        }
        setNote(said.join(" "));
        (0, import_a11y.speak)(said.join(" "));
      } catch (error) {
        const message = error.message || (0, import_i18n19.__)("Could not read that file. Export it from Meetup again, or save it as .csv.", "events-certificates");
        setNote(message);
        (0, import_a11y.speak)(message, "assertive");
      } finally {
        setBusy(false);
      }
    };
    const submit = (format, rows, justOne) => {
      const missing = whatIsMissing(values, countSelected(rows.map((p) => ({ ...p, on: true }))), rows.length > 0, justOne);
      if (missing.length || !rows.length) {
        const text2 = needText(missing.length ? missing : ["people"]);
        setNote(text2);
        (0, import_a11y.speak)(text2, "assertive");
        return;
      }
      setPosting({ format, rows });
    };
    const latest = (0, import_element11.useRef)({ submit, people, currentPerson });
    latest.current = { submit, people, currentPerson };
    (0, import_element11.useEffect)(() => {
      var _a;
      if (!posting) {
        return;
      }
      (_a = document.getElementById("evcert-generator-form")) == null ? void 0 : _a.requestSubmit();
      const timer = window.setTimeout(() => setPosting(null), 2500);
      return () => window.clearTimeout(timer);
    }, [posting]);
    (0, import_element11.useEffect)(() => {
      const settings = document.getElementById("evcert-generator-settings");
      const onSettings = () => setOpen((now) => !now);
      const onPeople = () => {
        setTab("people");
        setTabNonce((n) => n + 1);
        setOpen(true);
      };
      settings == null ? void 0 : settings.addEventListener("click", onSettings);
      window.addEventListener("evcert:toggle-people", onPeople);
      return () => {
        settings == null ? void 0 : settings.removeEventListener("click", onSettings);
        window.removeEventListener("evcert:toggle-people", onPeople);
      };
    }, []);
    (0, import_element11.useEffect)(() => {
      var _a, _b;
      (_a = document.getElementById("evcert-generator-settings")) == null ? void 0 : _a.setAttribute("aria-pressed", open ? "true" : "false");
      (_b = document.getElementById("evcert-generator-sidebar")) == null ? void 0 : _b.classList.toggle("is-closed", !open);
    }, [open]);
    (0, import_element11.useEffect)(() => {
      const onSubmit = (e) => {
        const { submit: send, people: list, currentPerson: one } = latest.current;
        const { format, current: current2 } = e.detail;
        send(format, current2 ? one ? [one] : [] : selectedPeople(list), !!current2);
      };
      window.addEventListener("evcert:submit", onSubmit);
      return () => window.removeEventListener("evcert:submit", onSubmit);
    }, []);
    const canvasRef = (0, import_element11.useRef)(null);
    const draw2 = (0, import_element11.useRef)(() => {
    });
    draw2.current = () => {
      var _a;
      const canvas = canvasRef.current;
      if (!canvas || !config.quick) {
        return;
      }
      const wide = ((_a = canvas.parentElement) == null ? void 0 : _a.clientWidth) || 800;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const page = config.quick.design.page;
      canvas.width = Math.round(wide * dpr);
      canvas.height = Math.round(wide * dpr * page.h / page.w);
      const signature2 = values.signature_svg ? drawingSrc(values.signature_svg) : pictureSrc(values.signature_image) || (config.signature ? drawingSrc(config.signature) : config.signatureImage || "");
      drawPreview(
        canvas,
        config.quick,
        { title: values.title, community: values.community, venue: values.venue, city: values.city, speakers: values.speakers, link: values.link, date: values.date, start: values.start_time, end: endTime, showHours, signName: values.signer_name || config.signerName || "", signRole: values.signer_role || config.signerRole || "" },
        (currentPerson == null ? void 0 : currentPerson.name) || "",
        { logo: values.logo_svg ? drawingSrc(values.logo_svg) : pictureSrc(values.logo), signature: signature2 }
      );
    };
    (0, import_element11.useEffect)(() => {
      const sheet = document.querySelector(".evcert-generator__sheet");
      if (!sheet || !config.quick) {
        return;
      }
      const canvas = document.createElement("canvas");
      canvas.className = "evcert-generator__canvas-preview";
      canvas.setAttribute("role", "img");
      canvas.setAttribute("aria-label", (0, import_i18n19.__)("Certificate preview", "events-certificates"));
      sheet.replaceChildren(canvas);
      canvasRef.current = canvas;
      const watch = new ResizeObserver(() => draw2.current());
      watch.observe(sheet);
      return () => watch.disconnect();
    }, []);
    (0, import_element11.useEffect)(() => {
      const frame = window.requestAnimationFrame(() => draw2.current());
      return () => window.cancelAnimationFrame(frame);
    }, [values, endTime, showHours, currentPerson == null ? void 0 : currentPerson.name]);
    const row = (key, label, extra = {}, shown2) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(SummaryRow, { label, value: shown2 != null ? shown2 : values[key], placeholder: extra.placeholder || void 0, children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.TextControl, { ...field, label, hideLabelFromVision: true, value: values[key], onChange: set(key), ...extra }) }, key);
    const working = busy || !!posting;
    const need = needText(missingAll);
    const needOne = needText(missingOne);
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(OpenRow.Provider, { value: { open: openRow, setOpen: setOpenRow }, children: /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.Panel, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Commands, { canMany: 0 === missingAll.length, canOne: 0 === missingOne.length, helpOpen }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
        import_components14.TabPanel,
        {
          className: "evcert-generator__tabs",
          initialTabName: tab,
          onSelect: setTab,
          tabs: [
            { name: "certificate", title: (0, import_i18n19.__)("Certificate", "events-certificates") },
            { name: "people", title: (0, import_i18n19.__)("Participants", "events-certificates") }
          ],
          children: (tab2) => {
            var _a, _b, _c, _d, _e, _f;
            return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { className: "evcert-generator__tab-body" + ("people" === tab2.name ? "" : " is-flush"), children: "people" === tab2.name ? /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.__experimentalVStack, { spacing: 4, children: [
              /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(CsvField, { file, busy: working, onFile: (csv) => addPeople("", csv) }),
              /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-people", children: [
                /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-people__bar", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { className: "evcert-people__count", children: (0, import_i18n19.sprintf)((0, import_i18n19.__)("%1$d of %2$d selected", "events-certificates"), selected, people.length) }),
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "link", disabled: !people.length, onClick: () => setPeople(setAll(people, selected !== people.length)), children: selected === people.length && people.length ? (0, import_i18n19.__)("Deselect all", "events-certificates") : (0, import_i18n19.__)("Select all", "events-certificates") })
                ] }),
                !people.length && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { className: "evcert-people__empty", children: (0, import_i18n19.__)("No participants yet. Import the Meetup CSV or add names by hand.", "events-certificates") }),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("ul", { className: "evcert-people__list", hidden: !people.length, children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("li", { className: "evcert-people__row" + (person.id === current ? " is-current" : ""), children: [
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                    "input",
                    {
                      type: "checkbox",
                      id: "evcert-person-on-" + person.id,
                      name: "evcert_person_on_" + person.id,
                      checked: person.on,
                      "aria-label": (0, import_i18n19.sprintf)((0, import_i18n19.__)("Include %s", "events-certificates"), person.name),
                      onChange: (e) => update(person.id, { on: e.target.checked })
                    }
                  ),
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                    import_components14.TextControl,
                    {
                      ...field,
                      className: "evcert-people__name",
                      name: "evcert_person_name_" + person.id,
                      label: (0, import_i18n19.__)("Participant name", "events-certificates"),
                      hideLabelFromVision: true,
                      value: person.name,
                      onFocus: () => setCurrent(person.id),
                      onChange: (name) => update(person.id, { name })
                    }
                  ),
                  person.roleLabels.map((label) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { className: "evcert-people__tag", children: label }, label)),
                  "no_show" === person.status && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { className: "evcert-people__tag", children: (0, import_i18n19.__)("did not attend", "events-certificates") }),
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                    import_components14.Button,
                    {
                      variant: "tertiary",
                      size: "small",
                      disabled: working || missingOne.length > 0,
                      "aria-label": (0, import_i18n19.sprintf)((0, import_i18n19.__)("Download the certificate of %s", "events-certificates"), person.name),
                      onClick: () => {
                        setCurrent(person.id);
                        submit("pdf", [person], true);
                      },
                      children: "PDF"
                    }
                  )
                ] }, person.id)) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-people__add", children: [
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "link", "aria-expanded": adding, onClick: () => setAdding(!adding), children: (0, import_i18n19.__)("Add names", "events-certificates") }),
                adding && /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.__experimentalVStack, { spacing: 3, children: [
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                    import_components14.TextareaControl,
                    {
                      ...field,
                      label: (0, import_i18n19.__)("Or add names by hand, one per line", "events-certificates"),
                      value: values.lines,
                      rows: 4,
                      help: (0, import_i18n19.__)("One per line: name, and optionally e-mail and role, separated by commas (or pasted from a spreadsheet).", "events-certificates"),
                      onChange: set("lines")
                    }
                  ),
                  /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "secondary", disabled: working || "" === values.lines.trim(), onClick: () => addPeople(values.lines), children: (0, import_i18n19.__)("Add names", "events-certificates") })
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { className: "evcert-generator__need", id: "evcert-generator-need", role: "status", children: working ? (0, import_i18n19.__)("Generating PDF\u2026", "events-certificates") : need || needOne || note })
            ] }) : /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.Panel, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { className: "evcert-generator__event", children: /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-summary", children: [
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { className: "evcert-summary__title", children: values.title ? /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "tertiary", className: "evcert-summary__title-text", onClick: () => setRenaming(true), label: (0, import_i18n19.__)("Rename"), showTooltip: true, children: values.title }) : /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "link", onClick: () => setRenaming(true), children: (0, import_i18n19.__)("Event name\u2026", "events-certificates") }) }),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(ImageRow, { image: values.logo, vector: values.logo_svg, label: (0, import_i18n19.__)("Set community logo", "events-certificates"), title: (0, import_i18n19.__)("Community logo", "events-certificates"), onChange: (image, svg) => setValues((old) => ({ ...old, logo: image, logo_svg: svg })) }),
                row("community", (0, import_i18n19.__)("Community", "events-certificates"), { placeholder: (_a = examples.community) != null ? _a : "" }),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                  SummaryRow,
                  {
                    label: (0, import_i18n19.__)("Start", "events-certificates"),
                    value: startText(values.date, values.start_time),
                    placeholder: (0, import_i18n19.__)("Pick the date and time", "events-certificates"),
                    action: { label: (0, import_i18n19.__)("Now", "events-certificates"), onClick: () => {
                      const now = /* @__PURE__ */ new Date();
                      setValues((old) => ({ ...old, date: now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate()), start_time: pad(now.getHours()) + ":" + pad(now.getMinutes()) }));
                    } },
                    children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                      import_components14.DateTimePicker,
                      {
                        is12Hour: is12HourTime,
                        startOfWeek: (0, import_date.getSettings)().l10n.startOfWeek,
                        currentDate: values.date ? values.date + "T" + (values.start_time || "00:00") + ":00" : null,
                        onChange: (picked) => {
                          if (!picked) {
                            return;
                          }
                          const when = new Date(picked);
                          setValues((old) => ({
                            ...old,
                            date: when.getFullYear() + "-" + pad(when.getMonth() + 1) + "-" + pad(when.getDate()),
                            start_time: pad(when.getHours()) + ":" + pad(when.getMinutes())
                          }));
                        }
                      }
                    )
                  }
                ),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                  SummaryRow,
                  {
                    label: (0, import_i18n19.__)("End", "events-certificates"),
                    value: "custom" === endMode ? startText(values.date, endTime) : ((_c = (_b = LENGTHS.find(([minutes]) => minutes === endMode)) == null ? void 0 : _b[1]) != null ? _c : "") + (endTime ? " (" + endTime + ")" : ""),
                    placeholder: (0, import_i18n19.__)("Set an end time\u2026", "events-certificates"),
                    action: "custom" === endMode ? { label: (0, import_i18n19.__)("Length", "events-certificates"), onClick: () => setEndMode(120) } : void 0,
                    children: (close) => "custom" === endMode ? (
                      // A certificate is one day long, so only the time of the end is kept: the other days cannot be picked.
                      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                        import_components14.DateTimePicker,
                        {
                          is12Hour: is12HourTime,
                          startOfWeek: (0, import_date.getSettings)().l10n.startOfWeek,
                          currentDate: (values.date || todayLocal()) + "T" + (values.end_time || values.start_time || "00:00") + ":00",
                          isInvalidDate: (day) => !!values.date && day.getFullYear() + "-" + pad(day.getMonth() + 1) + "-" + pad(day.getDate()) !== values.date,
                          onChange: (picked) => {
                            if (picked) {
                              const when = new Date(picked);
                              set("end_time")(pad(when.getHours()) + ":" + pad(when.getMinutes()));
                            }
                          }
                        }
                      )
                    ) : /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.MenuGroup, { label: (0, import_i18n19.__)("Length", "events-certificates"), children: [
                      LENGTHS.map(([minutes, label]) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                        import_components14.MenuItem,
                        {
                          role: "menuitemradio",
                          isSelected: endMode === minutes,
                          onClick: () => {
                            setEndMode(minutes);
                            close();
                          },
                          children: label
                        },
                        minutes
                      )),
                      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
                        import_components14.MenuItem,
                        {
                          role: "menuitemradio",
                          isSelected: false,
                          disabled: !values.date,
                          onClick: () => {
                            setValues((old) => ({ ...old, end_time: endTime || old.start_time }));
                            setEndMode("custom");
                          },
                          children: (0, import_i18n19.__)("Set an end time\u2026", "events-certificates")
                        }
                      )
                    ] })
                  }
                ),
                row("venue", (0, import_i18n19.__)("Venue", "events-certificates"), { placeholder: (_d = examples.venue) != null ? _d : "" }),
                row("city", (0, import_i18n19.__)("City", "events-certificates"), { placeholder: (_e = examples.city) != null ? _e : "" }),
                row("speakers", (0, import_i18n19.__)("Speaker(s)", "events-certificates"), { placeholder: (_f = examples.speakers) != null ? _f : "", help: (0, import_i18n19.__)("optional", "events-certificates") }),
                row("link", (0, import_i18n19.__)("Event link", "events-certificates"), { type: "url", placeholder: "https://", help: (0, import_i18n19.__)("optional, goes in the footer", "events-certificates") }),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.ToggleControl, { ...field, label: (0, import_i18n19.__)("Show the workload on the certificate", "events-certificates"), checked: showHours, onChange: setShowHours })
              ] }) }),
              /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_components14.PanelBody, { title: (0, import_i18n19.__)("Signature", "events-certificates"), initialOpen: false, children: [
                /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(ImageRow, { global: true, kind: "signature", image: values.signature_image, vector: values.signature_svg, label: (0, import_i18n19.__)("Set signature image", "events-certificates"), title: (0, import_i18n19.__)("Signature image", "events-certificates"), onChange: (image, svg) => setValues((old) => ({ ...old, signature_image: image, signature_svg: svg })) }),
                /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "evcert-summary", children: [
                  row("signer_name", (0, import_i18n19.__)("Name of who signs", "events-certificates"), { placeholder: config.signerName || (0, import_i18n19.__)("Who signs the certificate", "events-certificates") }),
                  row("signer_role", (0, import_i18n19._x)("Role", "role of who signs, in the generator", "events-certificates"), {
                    placeholder: config.signerRole || (0, import_i18n19._x)("Organizer", "default role of who signs, in the generator", "events-certificates"),
                    help: (0, import_i18n19.__)("Leave empty to use who signs in Settings.", "events-certificates")
                  })
                ] })
              ] })
            ] }) });
          }
        },
        tabNonce
      ),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { className: "evcert-generator__sidebar-close", icon: close_small_default, label: (0, import_i18n19.__)("Close"), onClick: () => setOpen(false) }),
      renaming && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(RenameModal, { title: values.title, onSave: (title) => {
        set("title")(title);
        setRenaming(false);
      }, onClose: () => setRenaming(false) }),
      actionsRoot && (0, import_element11.createPortal)(
        /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_jsx_runtime27.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "tertiary", disabled: working || missingOne.length > 0, title: needOne || (0, import_i18n19.__)("Download just this one", "events-certificates"), "aria-describedby": "evcert-generator-need", onClick: () => currentPerson && submit("pdf", [currentPerson], true), children: (0, import_i18n19.__)("Download current", "events-certificates") }),
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "secondary", disabled: working || missingAll.length > 0, title: need || (0, import_i18n19.__)("Download single PDF", "events-certificates"), "aria-describedby": "evcert-generator-need", onClick: () => submit("pdf", selectedPeople(people), false), children: (0, import_i18n19.__)("Download PDF", "events-certificates") }),
          /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(import_components14.Button, { variant: "primary", disabled: working || missingAll.length > 0, title: need || (0, import_i18n19.__)("Download ZIP (one PDF each)", "events-certificates"), "aria-describedby": "evcert-generator-need", onClick: () => submit("zip", selectedPeople(people), false), children: (0, import_i18n19.__)("Download ZIP", "events-certificates") })
        ] }),
        actionsRoot
      ),
      Object.keys(values).filter((key) => "lines" !== key).map((key) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_" + key, value: "end_time" === key ? endTime : values[key] }, key)),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_show_hours", value: showHours ? "1" : "0" }),
      posting && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_generator_format", value: posting.format }),
      posting == null ? void 0 : posting.rows.map((person, i) => /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("span", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_people[" + i + "][name]", value: person.name }),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_people[" + i + "][email]", value: person.email }),
        person.roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Hidden, { name: "evcert_people[" + i + "][roles][]", value: role }, role))
      ] }, person.id))
    ] }) });
  }
  var help = document.getElementById("evcert-generator-help");
  var left = document.getElementById("evcert-generator-left-panel");
  var setHelp = (open) => {
    left == null ? void 0 : left.classList.toggle("is-open", open);
    left == null ? void 0 : left.setAttribute("aria-hidden", open ? "false" : "true");
    help == null ? void 0 : help.setAttribute("aria-expanded", open ? "true" : "false");
    window.dispatchEvent(new CustomEvent("evcert:help-changed", { detail: { open } }));
  };
  help == null ? void 0 : help.addEventListener("click", () => setHelp(!(left == null ? void 0 : left.classList.contains("is-open"))));
  window.addEventListener("evcert:open-help", () => setHelp(true));
  window.addEventListener("evcert:close-help", () => setHelp(false));
  var docbar = document.getElementById("evcert-generator-docbar");
  docbar == null ? void 0 : docbar.addEventListener("click", () => (0, import_data.dispatch)(import_commands.store).open());
  var leftRoot = document.getElementById("evcert-generator-left-root");
  if (leftRoot && config.tutorial) {
    (0, import_element11.createRoot)(leftRoot).render(/* @__PURE__ */ (0, import_jsx_runtime27.jsx)(TutorialPanel, { tutorial: config.tutorial }));
  }
  var root = document.getElementById("evcert-generator-root");
  if (root) {
    (0, import_element11.createRoot)(root).render(/* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Form, {}));
  }
})();
//# sourceMappingURL=screen.js.map
