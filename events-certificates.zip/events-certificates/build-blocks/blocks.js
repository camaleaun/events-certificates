"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // package-external:@wordpress/block-editor
  var require_block_editor = __commonJS({
    "package-external:@wordpress/block-editor"(exports, module) {
      module.exports = window.wp.blockEditor;
    }
  });

  // package-external:@wordpress/blocks
  var require_blocks = __commonJS({
    "package-external:@wordpress/blocks"(exports, module) {
      module.exports = window.wp.blocks;
    }
  });

  // package-external:@wordpress/components
  var require_components = __commonJS({
    "package-external:@wordpress/components"(exports, module) {
      module.exports = window.wp.components;
    }
  });

  // package-external:@wordpress/i18n
  var require_i18n = __commonJS({
    "package-external:@wordpress/i18n"(exports, module) {
      module.exports = window.wp.i18n;
    }
  });

  // package-external:@wordpress/server-side-render
  var require_server_side_render = __commonJS({
    "package-external:@wordpress/server-side-render"(exports, module) {
      module.exports = window.wp.serverSideRender;
    }
  });

  // vendor-external:react/jsx-runtime
  var require_jsx_runtime = __commonJS({
    "vendor-external:react/jsx-runtime"(exports, module) {
      module.exports = window.ReactJSXRuntime;
    }
  });

  // src/blocks/index.tsx
  var import_block_editor = __toESM(require_block_editor());
  var import_blocks = __toESM(require_blocks());
  var import_components = __toESM(require_components());
  var import_i18n = __toESM(require_i18n());
  var import_server_side_render = __toESM(require_server_side_render());
  var import_jsx_runtime = __toESM(require_jsx_runtime());
  var NAME = "events-certificates/";
  var field = { __next40pxDefaultSize: true, __nextHasNoMarginBottom: true };
  var text = (attribute, label) => ({ attribute, label });
  var community = text("community", (0, import_i18n.__)("Community (default)", "events-certificates"));
  var title = text("title", (0, import_i18n.__)("Event title (default)", "events-certificates"));
  var logo = { attribute: "logo", label: (0, import_i18n.__)("Default logo", "events-certificates"), kind: "logo" };
  var venue = text("venue", (0, import_i18n.__)("Venue (default)", "events-certificates"));
  var city = text("city", (0, import_i18n.__)("City (default)", "events-certificates"));
  var speakers = text("speakers", (0, import_i18n.__)("Speakers (default)", "events-certificates"));
  var link = text("link", (0, import_i18n.__)("Event link (default)", "events-certificates"));
  var showHours = { attribute: "showHours", label: (0, import_i18n.__)("Show the workload by default", "events-certificates"), kind: "toggle" };
  var signName = text("signName", (0, import_i18n.__)("Signer name (default)", "events-certificates"));
  var signRole = text("signRole", (0, import_i18n.__)("Signer role (default)", "events-certificates"));
  var accent = { attribute: "accent", label: (0, import_i18n.__)("Certificate accent color", "events-certificates"), kind: "color" };
  var SETTINGS = {
    "event-info": [community, title, logo],
    "event-schedule": [venue, city],
    "event-attrs": [speakers, link, showHours],
    signature: [signName, signRole],
    preview: [accent],
    "tutorial-step-image": [{ attribute: "step", label: (0, import_i18n.__)("Step", "events-certificates"), kind: "step" }],
    "quick-generator": [community, title, logo, venue, city, speakers, link, showHours, signName, signRole, accent]
  };
  function Control({ setting, props }) {
    const { attribute, label, kind } = setting;
    const set = (value) => props.setAttributes({ [attribute]: value });
    if ("toggle" === kind) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.ToggleControl, { ...field, label, checked: !!props.attributes[attribute], onChange: set });
    }
    if ("step" === kind) {
      const steps = [1, 2, 3, 4].map((n) => ({ value: String(n), label: String(n) }));
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.SelectControl, { ...field, label, value: String(props.attributes[attribute] || 1), options: steps, onChange: (value) => set(Number(value)) });
    }
    if ("color" === kind) {
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: label }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.ColorPalette, { value: props.attributes[attribute], onChange: (value) => set(value || "#3858e9") })
      ] });
    }
    if ("logo" === kind) {
      const url = props.attributes.logoUrl;
      return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_block_editor.MediaUploadCheck, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_block_editor.MediaUpload,
        {
          allowedTypes: ["image"],
          value: props.attributes.logoId,
          onSelect: (media) => props.setAttributes({ logoId: media.id, logoUrl: media.url }),
          render: ({ open }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_components.__experimentalVStack, { spacing: 2, children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.BaseControl.VisualLabel, { children: label }),
            url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.Button, { variant: "secondary", className: "editor-post-featured-image__preview", onClick: open, "aria-label": (0, import_i18n.__)("Replace the logo", "events-certificates"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { className: "editor-post-featured-image__preview-image", src: url, alt: "", style: { objectFit: "contain" } }) }),
              /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.Button, { variant: "secondary", isDestructive: true, onClick: () => props.setAttributes({ logoId: 0, logoUrl: "" }), children: (0, import_i18n.__)("Remove the logo", "events-certificates") })
            ] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.Button, { variant: "secondary", className: "editor-post-featured-image__toggle", style: { minHeight: 90, justifyContent: "center" }, onClick: open, children: (0, import_i18n.__)("Choose a logo", "events-certificates") })
          ] })
        }
      ) });
    }
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.TextControl, { ...field, label, value: props.attributes[attribute] || "", onChange: set });
  }
  function drawn(slug) {
    return function Edit(props) {
      const settings = SETTINGS[slug] || [];
      return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_server_side_render.default, { block: NAME + slug, attributes: props.attributes }),
        settings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_block_editor.InspectorControls, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.PanelBody, { title: (0, import_i18n.__)("Generator settings", "events-certificates"), initialOpen: true, children: settings.map((setting) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, { setting, props }, setting.attribute)) }) })
      ] });
    };
  }
  ["event-info", "event-schedule", "event-attrs", "signature", "people-list", "preview", "tutorial", "tutorial-step-image", "quick-generator"].forEach((slug) => {
    (0, import_blocks.registerBlockType)(NAME + slug, { edit: drawn(slug), save: () => null });
  });
  (0, import_blocks.registerBlockType)(NAME + "event-fields", {
    edit: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ...(0, import_block_editor.useBlockProps)(), children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "panel", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: (0, import_i18n.__)("1 \xB7 Event", "events-certificates") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_block_editor.InnerBlocks,
        {
          allowedBlocks: [NAME + "event-info", NAME + "event-schedule", NAME + "event-attrs"],
          template: [[NAME + "event-info"], [NAME + "event-schedule"], [NAME + "event-attrs"]],
          templateLock: "insert"
        }
      )
    ] }) }),
    save: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_block_editor.InnerBlocks.Content, {})
  });
  (0, import_blocks.registerBlockType)(NAME + "verify", {
    edit: ({ attributes, setAttributes }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { ...(0, import_block_editor.useBlockProps)(), children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_block_editor.InspectorControls, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.PanelBody, { title: (0, import_i18n.__)("Settings", "events-certificates"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_components.TextControl,
        {
          ...field,
          label: (0, import_i18n.__)("Title", "events-certificates"),
          placeholder: (0, import_i18n.__)("Check a certificate", "events-certificates"),
          value: attributes.title,
          onChange: (value) => setAttributes({ title: value })
        }
      ) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ...{ inert: "" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_server_side_render.default, { block: NAME + "verify", attributes }) })
    ] }),
    save: () => null
  });
  (0, import_blocks.registerBlockType)(NAME + "mine", {
    edit: ({ attributes, setAttributes }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { ...(0, import_block_editor.useBlockProps)(), children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_block_editor.InspectorControls, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_components.PanelBody, { title: (0, import_i18n.__)("Settings", "events-certificates"), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_components.TextControl,
        {
          ...field,
          label: (0, import_i18n.__)("Title", "events-certificates"),
          placeholder: (0, import_i18n.__)("Get my certificate", "events-certificates"),
          value: attributes.title,
          onChange: (value) => setAttributes({ title: value })
        }
      ) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ...{ inert: "" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_server_side_render.default, { block: NAME + "mine", attributes }) })
    ] }),
    save: () => null
  });
})();
//# sourceMappingURL=blocks.js.map
