"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // package-external:@wordpress/data
  var require_data = __commonJS({
    "package-external:@wordpress/data"(exports, module) {
      module.exports = window.wp.data;
    }
  });

  // package-external:@wordpress/commands
  var require_commands = __commonJS({
    "package-external:@wordpress/commands"(exports, module) {
      module.exports = window.wp.commands;
    }
  });

  // package-external:@wordpress/element
  var require_element = __commonJS({
    "package-external:@wordpress/element"(exports, module) {
      module.exports = window.wp.element;
    }
  });

  // package-external:@wordpress/i18n
  var require_i18n = __commonJS({
    "package-external:@wordpress/i18n"(exports, module) {
      module.exports = window.wp.i18n;
    }
  });

  // package-external:@wordpress/primitives
  var require_primitives = __commonJS({
    "package-external:@wordpress/primitives"(exports, module) {
      module.exports = window.wp.primitives;
    }
  });

  // vendor-external:react/jsx-runtime
  var require_jsx_runtime = __commonJS({
    "vendor-external:react/jsx-runtime"(exports, module) {
      module.exports = window.ReactJSXRuntime;
    }
  });

  // src/events-generator/index.tsx
  var import_data = __toESM(require_data());
  var import_commands = __toESM(require_commands());
  var import_element = __toESM(require_element());
  var import_i18n = __toESM(require_i18n());

  // node_modules/@wordpress/icons/build-module/library/calendar.mjs
  var import_primitives = __toESM(require_primitives(), 1);
  var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
  var calendar_default = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_primitives.Path, { d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm.5 16c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5V7h15v12zM9 10H7v2h2v-2zm0 4H7v2h2v-2zm4-4h-2v2h2v-2zm4 0h-2v2h2v-2zm-4 4h-2v2h2v-2zm4 0h-2v2h2v-2z" }) });

  // node_modules/@wordpress/icons/build-module/library/cog.mjs
  var import_primitives2 = __toESM(require_primitives(), 1);
  var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
  var cog_default = /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_primitives2.Path, { fillRule: "evenodd", clipRule: "evenodd", d: "M10.289 4.836A1 1 0 0111.275 4h1.306a1 1 0 01.987.836l.244 1.466c.787.26 1.503.679 2.108 1.218l1.393-.522a1 1 0 011.216.437l.653 1.13a1 1 0 01-.23 1.273l-1.148.944a6.025 6.025 0 010 2.435l1.149.946a1 1 0 01.23 1.272l-.653 1.13a1 1 0 01-1.216.437l-1.394-.522c-.605.54-1.32.958-2.108 1.218l-.244 1.466a1 1 0 01-.987.836h-1.306a1 1 0 01-.986-.836l-.244-1.466a5.995 5.995 0 01-2.108-1.218l-1.394.522a1 1 0 01-1.217-.436l-.653-1.131a1 1 0 01.23-1.272l1.149-.946a6.026 6.026 0 010-2.435l-1.148-.944a1 1 0 01-.23-1.272l.653-1.131a1 1 0 011.217-.437l1.393.522a5.994 5.994 0 012.108-1.218l.244-1.466zM14.929 12a3 3 0 11-6 0 3 3 0 016 0z" }) });

  // node_modules/@wordpress/icons/build-module/library/download.mjs
  var import_primitives3 = __toESM(require_primitives(), 1);
  var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
  var download_default = /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_primitives3.Path, { d: "M18 11.3l-1-1.1-4 4V3h-1.5v11.3L7 10.2l-1 1.1 6.2 5.8 5.8-5.8zm.5 3.7v3.5h-13V15H4v5h16v-5h-1.5z" }) });

  // node_modules/@wordpress/icons/build-module/library/page.mjs
  var import_primitives4 = __toESM(require_primitives(), 1);
  var import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
  var page_default = /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_primitives4.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.Path, { d: "M15.5 7.5h-7V9h7V7.5Zm-7 3.5h7v1.5h-7V11Zm7 3.5h-7V16h7v-1.5Z" }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_primitives4.Path, { d: "M17 4H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2ZM7 5.5h10a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-.5.5H7a.5.5 0 0 1-.5-.5V6a.5.5 0 0 1 .5-.5Z" })
  ] });

  // node_modules/@wordpress/icons/build-module/library/pencil.mjs
  var import_primitives5 = __toESM(require_primitives(), 1);
  var import_jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
  var pencil_default = /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.SVG, { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_primitives5.Path, { d: "m19 7-3-3-8.5 8.5-1 4 4-1L19 7Zm-7 11.5H5V20h7v-1.5Z" }) });

  // src/events-generator/index.tsx
  var import_jsx_runtime6 = __toESM(require_jsx_runtime());
  var config = window.evcertEventsGenerator || {};
  var CONTEXT = "root";
  var go = (url) => ({ close }) => {
    close();
    if (url) {
      window.location.href = url;
    }
  };
  var press = (value) => ({ close }) => {
    var _a2;
    close();
    (_a2 = document.querySelector('button[form="evcert-events-generator"][value="' + value + '"]')) == null ? void 0 : _a2.click();
  };
  function Commands() {
    const urls = config.urls || {};
    (0, import_commands.useCommand)({ name: "evcert/eg-current", label: (0, import_i18n.__)("Download current", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: press("current"), disabled: !config.canOne });
    (0, import_commands.useCommand)({ name: "evcert/eg-pdf", label: (0, import_i18n.__)("Download PDF", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: press("pdf"), disabled: !config.canMany });
    (0, import_commands.useCommand)({ name: "evcert/eg-zip", label: (0, import_i18n.__)("Download ZIP", "events-certificates"), icon: download_default, category: "command", context: CONTEXT, callback: press("zip"), disabled: !config.canMany });
    (0, import_commands.useCommand)({ name: "evcert/eg-edit", label: (0, import_i18n.__)("Edit the event", "events-certificates"), icon: pencil_default, category: "command", context: CONTEXT, callback: go(urls.edit), disabled: !urls.edit });
    (0, import_commands.useCommand)({ name: "evcert/eg-participants", label: (0, import_i18n.__)("Manage participants", "events-certificates"), icon: page_default, category: "command", context: CONTEXT, callback: go(urls.participants), disabled: !urls.participants });
    (0, import_commands.useCommand)({ name: "evcert/eg-events", label: (0, import_i18n.__)("Go to Events", "events-certificates"), icon: calendar_default, category: "command", context: CONTEXT, callback: go(urls.events), disabled: !urls.events });
    (0, import_commands.useCommand)({ name: "evcert/eg-certificates", label: (0, import_i18n.__)("Go to Certificates", "events-certificates"), icon: page_default, category: "command", context: CONTEXT, callback: go(urls.certificates), disabled: !urls.certificates });
    (0, import_commands.useCommand)({ name: "evcert/eg-settings", label: (0, import_i18n.__)("Go to Settings", "events-certificates"), icon: cog_default, category: "command", context: CONTEXT, callback: go(urls.settings), disabled: !urls.settings });
    (0, import_commands.useCommands)(
      (config.events || []).filter((event) => event.id !== config.current).map((event) => ({
        name: "evcert/eg-event-" + event.id,
        /* translators: %s: an event's name. */
        label: (0, import_i18n.sprintf)((0, import_i18n.__)("Generate certificates for %s", "events-certificates"), event.title),
        icon: calendar_default,
        category: "command",
        context: CONTEXT,
        callback: go(event.url)
      }))
    );
    return null;
  }
  var _a;
  (_a = document.getElementById("evcert-generator-docbar")) == null ? void 0 : _a.addEventListener("click", () => (0, import_data.dispatch)(import_commands.store).open());
  var root = document.getElementById("evcert-eg-commands");
  if (root) {
    (0, import_element.createRoot)(root).render(/* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Commands, {}));
  }
})();
//# sourceMappingURL=events-generator.js.map
